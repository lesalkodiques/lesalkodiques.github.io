root_list = [
	{'name': 32028, 'iconImage': 'movies.png', 'mode': 'navigator.main', 'action': 'MovieList'},
	{'name': 32029, 'iconImage': 'tv.png', 'mode': 'navigator.main', 'action': 'TVShowList'},
	{'name': 'Enfants & Famille', 'iconImage': 'genre_family.png', 'mode': 'navigator.main', 'action': 'FamilyList'},
	{'name': 'Animés japonais', 'iconImage': 'anime.png', 'mode': 'navigator.main', 'action': 'AnimeList'},
#	{'name': 32452, 'iconImage': 'people.png', 'mode': 'build_popular_people', 'isFolder': 'false'},
	{'name': 32451, 'iconImage': 'discover.png', 'mode': 'navigator.discover_main'},
	{'name': 32450, 'iconImage': 'search.png', 'mode': 'navigator.search'},
	{'name': 32453, 'iconImage': 'favourites.png', 'mode': 'navigator.favourites'},
	{'name': 32454, 'iconImage': 'lists.png', 'mode': 'navigator.my_content'},
	{'name': 32455, 'iconImage': 'premium.png', 'mode': 'navigator.premium'},
#	{'name': 32456, 'iconImage': 'tools.png', 'mode': 'navigator.tools'},
	{'name': 32247, 'iconImage': 'settings.png', 'mode': 'navigator.settings'}
]

movie_list = [
	{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_popular'},
	{'name': 'Tendances', 'iconImage': 'trending.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_trending'},
	{'name': 'Les mieux notés', 'iconImage': 'most_voted.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_top_rated'},
	{'name': 'Nouveautés numériques', 'iconImage': 'dvd.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_latest_releases'},
	{'name': 'Sorties cinéma récentes', 'iconImage': 'fresh.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_premieres'},
	{'name': 'À venir', 'iconImage': 'lists.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_upcoming'},
	{'name': 'Blockbusters', 'iconImage': 'most_watched.png', 'mode': 'build_movie_list', 'action': 'tmdb_movies_blockbusters'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'navigator.genres', 'menu_type': 'movie'},
	{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'movie'},
	{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'movie'},
	{'name': 'Par plateforme', 'iconImage': 'networks.png', 'mode': 'catalogue.native_providers', 'native_type': 'movie'},
	{'name': 'Amazon Channels', 'iconImage': 'networks.png', 'mode': 'catalogue.amazon_channels', 'native_type': 'movie'},
	{'name': 32475, 'iconImage': 'watched.png', 'mode': 'build_movie_list', 'action': 'watched_movies'},
	{'name': 32476, 'iconImage': 'player.png', 'mode': 'build_movie_list', 'action': 'in_progress_movies'}
]

tvshow_list = [
	{'name': 'Populaires', 'iconImage': 'popular.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_popular'},
	{'name': 'Tendances', 'iconImage': 'trending.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_trending'},
	{'name': 'Les mieux notées', 'iconImage': 'most_voted.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_top_rated'},
	{'name': 'Diffusées aujourd’hui', 'iconImage': 'fresh.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_airing_today'},
	{'name': 'En diffusion cette semaine', 'iconImage': 'calender.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_airing_this_week'},
	{'name': 'Nouveautés', 'iconImage': 'tv.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_premieres'},
	{'name': 'À venir', 'iconImage': 'lists.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tv_upcoming'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'navigator.genres', 'menu_type': 'tvshow'},
	{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.native_years', 'native_type': 'series'},
	{'name': 'Par langue', 'iconImage': 'languages.png', 'mode': 'catalogue.native_languages', 'native_type': 'series'},
	{'name': 'Par plateforme', 'iconImage': 'networks.png', 'mode': 'catalogue.native_providers', 'native_type': 'series'},
	{'name': 'Amazon Channels', 'iconImage': 'networks.png', 'mode': 'catalogue.amazon_channels', 'native_type': 'series'},
	{'name': 32475, 'iconImage': 'watched.png', 'mode': 'build_tvshow_list', 'action': 'watched_tvshows'},
	{'name': 32481, 'iconImage': 'recent.png', 'mode': 'build_tvshow_list', 'action': 'in_progress_tvshows'},
	{'name': 33122, 'iconImage': 'in_progress_tvshow.png', 'mode': 'build_tvshow_list', 'action': 'trakt_in_progress_tvshows', 'hide_watched_items': 'true'},
	{'name': 32482, 'iconImage': 'player.png', 'mode': 'build_in_progress_episode'},
	{'name': 32483, 'iconImage': 'next_episode.png', 'mode': 'build_next_episode'}
]

family_list = [
	{'name': 'Films familiaux', 'iconImage': 'movies.png', 'mode': 'catalogue.family_section', 'family_type': 'movie_family'},
	{'name': 'Séries familiales', 'iconImage': 'tv.png', 'mode': 'catalogue.family_section', 'family_type': 'series_family'},
	{'name': 'Dessins animés', 'iconImage': 'genre_animation.png', 'mode': 'catalogue.family_animation_root'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'catalogue.family_genre_groups'},
	{'name': 'Par plateforme', 'iconImage': 'networks.png', 'mode': 'catalogue.family_provider_groups'},
	{'name': 'Amazon Channels jeunesse', 'iconImage': 'networks.png', 'mode': 'catalogue.family_amazon_channel_groups'},
	{'name': 'Chaînes jeunesse', 'iconImage': 'networks.png', 'mode': 'catalogue.family_kids_networks'}
]

anime_list = [
	{'name': 'Séries animées japonaises', 'iconImage': 'tv.png', 'mode': 'catalogue.native_anime', 'native_type': 'anime_series'},
	{'name': 'Films animés japonais', 'iconImage': 'movies.png', 'mode': 'catalogue.native_anime', 'native_type': 'anime_movie'},
	{'name': 33155, 'iconImage': 'trakt.png', 'mode': 'build_anime_calendar'},
	{'name': 'Séries populaires', 'iconImage': 'popular.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tvanime_popular'},
	{'name': 'Séries récentes', 'iconImage': 'fresh.png', 'mode': 'build_tvshow_list', 'action': 'tmdb_tvanime_premieres'},
	{'name': 'Films populaires', 'iconImage': 'popular.png', 'mode': 'build_movie_list', 'action': 'tmdb_moviesanime_popular'},
	{'name': 'Dernières sorties films', 'iconImage': 'dvd.png', 'mode': 'build_movie_list', 'action': 'tmdb_moviesanime_latest_releases'},
	{'name': 'Par genre', 'iconImage': 'genres.png', 'mode': 'catalogue.native_anime_groups'},
	{'name': 'Par année', 'iconImage': 'calender.png', 'mode': 'catalogue.native_anime_year_groups'},
	{'name': 'Par plateforme', 'iconImage': 'networks.png', 'mode': 'catalogue.native_anime_provider_groups'}
]

main_menu_items, main_menus, default_menu_items = {
	'RootList': {'name': 32457, 'iconImage': 'alkoflix.png', 'mode': 'navigator.main', 'action': 'RootList'},
	'MovieList': root_list[0],
	'TVShowList': root_list[1],
	'FamilyList': root_list[2],
	'AnimeList': root_list[3]
}, {
	'RootList': root_list,
	'MovieList': movie_list,
	'TVShowList': tvshow_list,
	'FamilyList': family_list,
	'AnimeList': anime_list
}, (
	'RootList',
	'MovieList',
	'TVShowList',
	'FamilyList',
	'AnimeList'
)

