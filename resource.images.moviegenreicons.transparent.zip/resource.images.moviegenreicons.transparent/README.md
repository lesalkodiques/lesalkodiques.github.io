# resource.images.moviegenreicons.transparent

## Icônes de genres multilingues (français et anglais) 

- Icones de genres pris en charge par défaut avec le skin Arctic Horizon

## 🔗 TÉLÉCHARGER: https://lesalkodiques.com/repo/
