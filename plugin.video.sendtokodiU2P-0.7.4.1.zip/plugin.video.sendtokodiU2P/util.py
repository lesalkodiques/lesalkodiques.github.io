import requests
from urllib.parse import urlencode, quote_plus, quote, unquote
import os
import re
import time
import sys
import unicodedata 
import json
import sqlite3
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
KEYTMDB = ADDON.getSetting("apikey")
HANDLE = int(sys.argv[1])
BDBOOKMARK = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmarkUptobox.db')
NBMEDIA = 30


def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def createListItemFromVideo(video):
    url = video['url']
    title = video['title']
    list_item = xbmcgui.ListItem(title, path=url)
    if "episode" in video.keys():
        list_item.setInfo(type='Video', infoLabels={'Title': title, "episode": video['episode'], "season": video['season']})
    else:
        list_item.setInfo(type='Video', infoLabels={'Title': title})
    return list_item

def normalizeNum(num):
    s, e = num.split("E")
    e = "%s%s" %("0" * (4 - len(e)), e)
    return s + "E" + e

def showInfoNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message, xbmcgui.NOTIFICATION_INFO, 5000)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("U2Pplay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
