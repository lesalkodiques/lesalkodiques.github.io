import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib
import re
import os
import json


# Code to map the old translatePath
try:
    translatePath = xbmcvfs.translatePath
except AttributeError:
    translatePath = xbmc.translatePath

thumbnailPath = translatePath('special://thumbnails');
cachePath = os.path.join(translatePath('special://home'), 'cache')
tempPath = translatePath('special://temp')
addonPath = os.path.join(os.path.join(translatePath('special://home'), 'addons'),'script.ezmaintenance')

mediaPath = os.path.join(addonPath, 'media')
databasePath = translatePath('special://database')
THUMBS    =  translatePath(os.path.join('special://home/userdata/Thumbnails',''))

addon_id = 'script.ezmaintenanceplus'
fanart = translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
iconpath = translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))

#addonTMDBHelperPath = os.path.join(os.path.join(translatePath('special://home'), 'addons'),'script.ezmaintenance')
# userdata/addon_data/plugin.video.themoviedb.helper

tmdbTempCropDirPath = translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.themoviedb.helper','crop'))

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5 # not used
def timeIt(func):
	# Thanks to 123Venom
	import time
	fnc_name = func.__name__
	def wrap(*args, **kwargs):
		started_at = time.time()
		result = func(*args, **kwargs)
		logger('%s.%s' % (__name__ , fnc_name), (time.time() - started_at))
		return result
	return wrap

def logger(heading, function, level=LOGERROR):
	xbmc.log('###%s###: %s' % (heading, function), level)

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

def clearCache(mode='verbose'):
    if os.path.exists(cachePath)==True:
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            if (d == "archive_cache" or d == "temp"): continue
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass

            else:
                pass
    if os.path.exists(tempPath)==True:
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    try:
                        if (f == "xbmc.log" or f == "xbmc.old.log" or f == "kodi.log" or f == "kodi.old.log" or f == "archive_cache" or f == "commoncache.db" or f == "commoncache.socket" or f == "temp"): continue
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        if (d == "archive_cache" or d == "temp"): continue
                        shutil.rmtree(os.path.join(root, d))
                    except:
                        pass

            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')

        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')

        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)

            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
            else:
                pass

    cacheEntries = []

    for entry in cacheEntries:
        clear_cache_path = translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                else:
                    pass

    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Completed' , '3000', iconpath))

def deleteThumbnails(mode='verbose'):

    if os.path.exists(thumbnailPath)==True:
            # dialog = xbmcgui.Dialog()
            # if dialog.yesno("Delete Thumbnails", "This option deletes all thumbnails" + '\n' + "Are you sure you want to do this?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass


    if os.path.exists(THUMBS):
        try:
            for root, dirs, files in os.walk(THUMBS):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
        except:
            pass

    try:
        text13 = os.path.join(databasePath,"Textures13.db")
        os.unlink(text13)
    except:
        pass
    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Thumbs Completed' , '3000', iconpath))

def purgePackages(mode='verbose'):

    purgePath = translatePath('special://home/addons/packages')
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
    # if dialog.yesno("Delete Package Cache Files", "%d packages found."%file_count + '\n' + "Delete Them?"):
    for root, dirs, files in os.walk(purgePath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
            # dialog = xbmcgui.Dialog()
            # dialog.ok("Maintenance", "Deleting Packages all done")
    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean Packages Completed' , '3000', iconpath))


def deleteTMDBHelperFiles(mode='verbose', user_confirmation=False):
  if os.path.exists(tmdbTempCropDirPath)==True:
    dialog = xbmcgui.Dialog()
    file_count = 0
    for root, dirs, files in os.walk(tmdbTempCropDirPath):
        file_count += len(files)
    if user_confirmation:
        if not dialog.yesno("Delete TMDB Temp Crop Files", "%d temp crop files found."%file_count + '\n' + "Delete Them?"):
            return
    for root, dirs, files in os.walk(tmdbTempCropDirPath):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                try:
                    if (f.startswith('temp_cropped-')):
                        os.unlink(os.path.join(root, f))
                except:
                    pass
        #    if user_confirmation:
        #        dialog = xbmcgui.Dialog()
        #        dialog.ok("Maintenance", "Deleting TMDB Temp Crops all done")
    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Clean TMDB crop directory completed' , '3000', iconpath))


# TODO: Further work on addon reuselanginvoker switching..
def get_list_providers_enabled():
    results = []
    list_providers = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", '
                                               '"method": "Addons.GetAddons", '
                                               '"id": 1, '
                                               '"params": {"type" : "xbmc.python.script", '
                                               '"properties": ["enabled", "name"]}}'))
    for one_provider in list_providers["result"]["addons"]:
        # if one_provider['addonid'].startswith('script.magnetic.') and \
        if one_provider['enabled']:
            results.append(one_provider['addonid'])
    return results


def get_profile():
    results = []
    list_profile = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", '
                                                    '"method": "Profiles.GetCurrentProfile", '
                                                    '"id": 1'
                                                    '}'
                                                    ))
    # returns {"id":1,"jsonrpc":"2.0","result":{"label":"Master user"}
    profile = "Master user"
    if list_profile["result"]["label"]:
        profile = list_profile["result"]["label"]
    return results

def get_video_addons(video_addons_only=True):
    if video_addons_only:
        addon_type = "xbmc.addon.video"
    else:
        addon_type = ""
    request = {'jsonrpc': '2.0',
               'method': 'Addons.GetAddons',
               'params': {'type': addon_type,
#                          'content': 'video',
#                          'enabled': True,
#                          'properties': ['name', 'addonid', 'path', 'enabled']},
                          },
                'id': 1
               }
    response = xbmc.executeJSONRPC(json.dumps(request))

    j = json.loads(response)
    result = j.get('result')
    if result:
        addons = result.get('addons', [])
    else:
        addons = []

    return addons



def UpdateLocalAddons(self):
    return xbmc.executebuiltin("UpdateLocalAddons")

def log_info(log_string):
    logger('EZMAINTENANCE+TMDB', log_string, LOGINFO)

def disable_language_invoker(mode='verbose', enable=False, check_only=False, video_addons_only=True):
    import xml.etree.ElementTree as ET
#    close_all_dialog()
#    sleep(100)
#    addon_xml = translate_path('special://home/addons/plugin.video.fen/addon.xml')
#    current_addon_setting = get_setting('reuse_language_invoker', 'true')
#    new_value = 'false' if current_addon_setting == 'true' else 'true'
#    if not confirm_dialog(text=local_string(33018) % (current_addon_setting.upper(), new_value.upper()), top_space=False): return
#    if new_value == 'true' and not confirm_dialog(text=33019): return

    #addon = xbmcaddon.Addon()
    #addon_path    = addon.getAddonInfo('path')
    #addonID = addon.getAddonInfo('id')
    #addonUserDataFolder = xbmc.translatePath("special://profile/addon_data/" + addonID)

    log_info("Starting ReuseLanguageInvoker modification routine.")
    addons_list = get_video_addons(video_addons_only=video_addons_only)
    log_info("Addons List : video only=" + str(video_addons_only))
    log_info(addons_list)
    for add in addons_list:
        addon_xml = translatePath('special://home/addons/' + add['addonid'] + '/addon.xml')
        if not os.path.exists(addon_xml):
            # skip addons that are not able to be modified
            continue
        log_info("Addon_xml path=" + addon_xml)
        if enable:
            new_value = 'true'
        else:
            new_value = 'false'
        tree = ET.parse(addon_xml)
        root = tree.getroot()
        for item in root.iter('reuselanguageinvoker'):
            log_info("Addon id: " + add['addonid'] + " - current reuselanguageinvoker value: " + item.text)
            if not item.text == new_value:
                if check_only:
                    log_info("Skipping modification of " + addon_xml + ". Update this file manually if needed.")
                else:
                    item.text = new_value
                    tree.write(addon_xml)
                    log_info("Addon id " + add['addonid'] + " modified reuselanginvoker to " + new_value)
            break

    #print("Go Home Window")
    #xbmc.executebuiltin("ActivateWindow(Home)")
    if not check_only:
        log_info("Updating local addons")
        xbmc.executebuiltin("UpdateLocalAddons")


    if mode == 'verbose': xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('Maintenance' , 'Completed ReuseLaguageInvoker loop (check logs)' , '3000', iconpath))
