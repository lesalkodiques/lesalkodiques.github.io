# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/indexers/subtitles.py
#
# Gestion des sous-titres pour alkoFlix.
#
# Ce module suit un ordre simple :
#   1. Prioriser un sous-titre local/intégré correspondant à la langue choisie.
#   2. Réutiliser un sous-titre Wyzie déjà téléchargé dans special://temp/.
#   3. Interroger l’API Wyzie pour proposer/télécharger un sous-titre externe.
#
# Les sous-titres téléchargés restent dans special://temp/.
# alkoFlix nettoie ce dossier au démarrage afin d’éviter l’accumulation de fichiers .srt.

import json
import os
import requests
from datetime import timedelta
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from caches.main_cache import MainCache
from modules.meta_lists import language_choices
from modules import kodi_utils
# from modules.kodi_utils import logger

ls, get_setting = kodi_utils.local_string, kodi_utils.get_setting
logger = kodi_utils.logger
# Icône utilisée pour les notifications du module sous-titres.
# On utilise le logo alkoFlix plutôt que la pochette du média, car certains skins
# arrondissent ou déforment les jaquettes dans les notifications.
addon_icon = 'special://home/addons/plugin.video.alkoflix/alkoflix.png'

# Point d’entrée utilisé pour rechercher les sous-titres via Wyzie.
search_url = 'https://sub.wyzie.io/search'

# Log dédié aux sous-titres. Tous les messages passent par “alkoFlix Subtitles”
# pour être faciles à repérer dans kodi.log.
def _sub_log(message):
	try: logger('alkoFlix Subtitles', message)
	except: pass

# Masque les clés/API tokens avant d’écrire une URL dans le log.
# Important : la clé Wyzie ne doit jamais apparaître en clair dans kodi.log.
def _sanitize_url(url):
	try:
		parts = urlsplit(url)
		query = []
		for key, value in parse_qsl(parts.query, keep_blank_values=True):
			if key.lower() in ('key', 'apikey', 'api_key', 'token'):
				value = '***'
			query.append((key, value))
		return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))
	except: return url

# Masque les paramètres sensibles avant journalisation.
# On indique seulement si la clé est présente ou absente.
def _sanitize_params(params):
	try:
		safe = dict(params or {})
		for key in ('key', 'apikey', 'api_key', 'token'):
			if key in safe:
				safe[key] = 'présente' if safe.get(key) else 'absente'
		return safe
	except: return {}

# Timeout réseau pour Wyzie et les téléchargements de sous-titres.
# 20 secondes évite les faux échecs lorsque certaines sources répondent lentement.
timeout = 20.0
# Sources demandées à Wyzie. Wyzie agrège plusieurs fournisseurs de sous-titres.
api_sources = ('opensubtitles', 'subdl', 'subf2m', 'gestdown', 'yify')

# Wrapper HTTP commun : centralise requests.get(), les logs,
# le masquage des données sensibles et le retry simple en cas de 403/429.
def _get(url, params=None, stream=False, retry=False):
	_sub_log('HTTP GET -> %s | params=%s | stream=%s | retry=%s' % (_sanitize_url(url), _sanitize_params(params), stream, retry))
	try:
		response = requests.get(url, params=params, stream=stream, timeout=timeout)
	except Exception as e:
		_sub_log('HTTP GET exception -> %s: %s' % (type(e).__name__, e))
		raise
	_sub_log('HTTP GET <- status=%s | reason=%s | url=%s' % (response.status_code, response.reason, _sanitize_url(getattr(response, 'url', url))))
	if retry and response.status_code in (403, 429):
		_sub_log('HTTP GET rate/permission response -> pause 10s before retry')
		kodi_utils.notification(32740, icon=addon_icon)
		kodi_utils.sleep(10000)
		return _get(url, params=params, stream=stream)
	return response

# Télécharge le sous-titre choisi. Retourne soit la réponse HTTP,
# soit un texte d’erreur si le téléchargement échoue.
def subtitles_download(url):
	_sub_log('Download subtitle requested -> %s' % _sanitize_url(url))
	response = _get(url, stream=True, retry=True)
	if not response.ok:
		_sub_log('Download subtitle failed -> %s %s' % (response.status_code, response.reason))
		return response.reason
	_sub_log('Download subtitle OK -> bytes=%s' % len(getattr(response, 'content', b'')))
	return response

# Recherche des sous-titres via Wyzie.
# imdb_id est obligatoire. Pour les séries, season/episode ciblent le bon épisode.
def subtitles_search(imdb_id, season=None, episode=None, apikey='', wanted_language=''):
	_sub_log('Wyzie search requested -> imdb_id=%s | season=%s | episode=%s | wanted_language=%s | api_key=%s' % (imdb_id, season, episode, wanted_language, 'présente' if apikey else 'absente'))
	if not imdb_id:
		_sub_log('Wyzie search aborted -> imdb_id manquant')
		return []
	cache_name = 'subtitles_wyzie_%s' % imdb_id
	params = {
		'encoding': 'utf-8',
		'format': 'srt',

		# Pendant la bêta, on demande à Wyzie d’interroger toutes les sources
		# disponibles plutôt que seulement une liste limitée.
		# Cela augmente les chances de récupérer les sous-titres FR lorsqu’ils
		# sont présents chez un fournisseur non inclus dans api_sources.
		'source': 'all',

		# Demande à Wyzie de contourner son cache serveur afin de récupérer
		# des résultats frais. Utile lorsque les résultats varient pour un même média.
		'refresh': 'true',

		'key': apikey,
		'id': imdb_id
	}
	if season:
		cache_name += '_%s_%s' % (season, episode)
		params.update({'season': season, 'episode': episode})
	# Cache positif uniquement :
	# - si une recherche Wyzie retourne au moins un sous-titre dans la langue choisie,
	#   on conserve temporairement cette bonne réponse;
	# - si Wyzie ne retourne rien, seulement de l’anglais/autres langues, une erreur
	#   ou un timeout, rien n’est conservé.
	#
	# Cela évite de bloquer l’addon avec un “mauvais cache”, tout en gardant les bons
	# résultats FR lorsque Wyzie les retourne une fois puis devient capricieux ensuite.
	wanted_language = (wanted_language or '').lower()
	wanted_short = (kodi_utils.convert_language(wanted_language, format='short') or '').lower()
	cache_lang = wanted_language or wanted_short or 'default'
	cache_name = '%s_%s' % (cache_name, cache_lang)
	maincache = MainCache()
	cache = maincache.get(cache_name)
	if cache:
		_sub_log('Wyzie positive cache hit -> cache_name=%s | results=%s' % (cache_name, len(cache) if isinstance(cache, list) else 'inconnu'))
		return cache
	_sub_log('Wyzie positive cache miss -> live API search | cache_name=%s' % cache_name)
	response = _get(search_url, params=params, retry=True)
	if not response.ok:
		try: preview = response.text[:300]
		except: preview = ''
		_sub_log('Wyzie HTTP error -> status=%s | reason=%s | body=%s' % (response.status_code, response.reason, preview))
		return response.reason
	try:
		response = response.json()
	except Exception as e:
		_sub_log('Wyzie JSON error -> %s: %s' % (type(e).__name__, e))
		return 'Invalid JSON'
	if isinstance(response, dict):
		_sub_log('Wyzie returned dict -> %s' % response)
		message = response.get('message') or response.get('error') or response.get('detail') or 'Réponse Wyzie inattendue'
		return message
	_sub_log('Wyzie API results -> %s résultat(s)' % (len(response) if isinstance(response, list) else 'type inattendu'))

	def _positive_lang_match(item):
		lang = (item.get('language') or '').lower() if isinstance(item, dict) else ''
		if not lang: return False
		candidates = {wanted_language, wanted_short}
		if wanted_short == 'fr' or wanted_language in ('fre', 'fra'):
			candidates.update(('fr', 'fre', 'fra'))
		elif wanted_short == 'en' or wanted_language == 'eng':
			candidates.update(('en', 'eng'))
		elif wanted_short == 'es' or wanted_language == 'spa':
			candidates.update(('es', 'spa'))
		elif wanted_short == 'pt' or wanted_language in ('por', 'pob'):
			candidates.update(('pt', 'por', 'pob', 'pt-br', 'pt_br', 'ptbr'))
		candidates = {i for i in candidates if i}
		return lang in candidates

	if isinstance(response, list) and any(_positive_lang_match(i) for i in response):
		_sub_log('Wyzie positive cache set -> cache_name=%s | expiration=24h' % cache_name)
		maincache.set(cache_name, response, expiration=timedelta(hours=24))
	else:
		_sub_log('Wyzie positive cache skipped -> no subtitle matched wanted_language=%s/%s' % (wanted_language, wanted_short))
	return response

# Résout la langue configurée dans alkoFlix.
# Kodi peut retourner un libellé (“French”) ou un index numérique (“20”).
# Cette fonction convertit toujours vers le code attendu par le module.
def _resolve_language_setting():
	raw_value = get_setting('subtitles.language') or 'French'
	try:
		if raw_value in language_choices:
			return language_choices[raw_value], raw_value, raw_value

		if str(raw_value).isdigit():
			index = int(raw_value)
			keys = list(language_choices.keys())

			# Le setting Kodi "select" stocke un index numérique basé sur les lvalues.
			# Cette liste ne contient pas l'entrée "None", alors que language_choices la contient.
			if keys and keys[0] == 'None':
				index += 1

			if 0 <= index < len(keys):
				key = keys[index]
				return language_choices[key], key, raw_value

		_sub_log('Language setting fallback -> valeur inattendue=%s' % raw_value)
	except Exception as e:
		_sub_log('Language setting fallback exception -> %s: %s' % (type(e).__name__, e))

	return language_choices.get('French', 'fre'), 'French', raw_value

# Classe principale appelée pendant la lecture.
# Elle gère les pistes locales, les fichiers déjà téléchargés et la recherche Wyzie.
class Subtitles(kodi_utils.xbmc_player):
	# Initialise les réglages liés aux sous-titres : clé API, action choisie,
	# activation automatique des pistes locales et langue cible.
	def __init__(self):
		kodi_utils.xbmc_player.__init__(self)
		self.apikey = get_setting('subtitles.apikey')
		self.auto_enable = get_setting('subtitles.auto_enable')
		self.subs_action = {'0': 'auto', '1': 'select', '2': 'off'}[get_setting('subtitles.subs_action', '2')]
		self.language1, self.language_label, self.language_setting = _resolve_language_setting()
		# Mémorise si la dernière piste locale sélectionnée est une piste forcée.
		# Cette information permet d’activer automatiquement les sous-titres forcés
		# même lorsque l’option générale d’activation automatique est désactivée.
		self._last_selected_embedded_is_forced = False
		_sub_log('Init -> subs_action=%s | auto_enable=%s | language=%s (%s) | setting=%s | api_key=%s' % (self.subs_action, self.auto_enable, self.language1, self.language_label, self.language_setting, 'présente' if self.apikey else 'absente'))

	# Vérifie une seule fois les sous-titres locaux/intégrés exposés par Kodi.
	# Si une piste correspond à la langue choisie, elle est sélectionnée.
	def _select_embedded_subtitle_once(self):
		_sub_log('Local subtitle check -> start')
		self._last_selected_embedded_is_forced = False
		# Helpers pour distinguer les variantes portugaises lorsque c’est possible.
		# Exemple : portugais Portugal vs portugais Brésil.
		def _is_brazil_text(text):
			return any(i in text for i in ('brazil', 'brasil', 'brazilian', 'pt-br', 'ptbr', 'pt_br'))
		def _is_portugal_text(text):
			return any(i in text for i in ('portugal', 'iberian', 'european', 'pt-pt', 'ptpt', 'pt_pt'))
		try:
			# Récupération du lecteur vidéo actif via JSON-RPC Kodi.
			player_query = {"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}
			player_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(player_query)))
			player_id = next((p.get('playerid') for p in player_resp.get('result', []) if p.get('type') == 'video'), None)
			if player_id is None:
				_sub_log('Local subtitle check -> no active video player')
				return False
			# Récupération des pistes de sous-titres disponibles,
			# de la piste courante et de l’état d’affichage.
			props_query = {
				"jsonrpc": "2.0",
				"method": "Player.GetProperties",
				"params": {"playerid": player_id, "properties": ["subtitles", "currentsubtitle", "subtitleenabled"]},
				"id": 1
			}
			props_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(props_query)))
			props = props_resp.get('result', {})
			subtitles = props.get('subtitles') or []
			_sub_log('Local subtitle check -> %s subtitle track(s) detected | enabled=%s | current=%s' % (len(subtitles), props.get('subtitleenabled'), props.get('currentsubtitle')))
			if not subtitles:
				_sub_log('Local subtitle check -> no local/embedded subtitles found')
				return False
			# Conversion vers le format court utilisé par Kodi afin de comparer les langues.
			search_lang = (kodi_utils.convert_language(self.language1, format='short') or '').lower()
			def _sub_text(sub):
				lang = (sub.get('language') or '')
				name = (sub.get('name') or '')
				return ('%s %s' % (lang, name)).lower()
			def _lang_matches(sub):
				lang = (sub.get('language') or '').lower()
				if lang:
					candidates = {search_lang, (self.language1 or '').lower()}
					if search_lang == 'pt' or (self.language1 or '') in ('por', 'pob'):
						candidates.update(('pt', 'por', 'pob', 'pt-br', 'pt_br', 'ptbr'))
					return lang in candidates
				return 'portuguese' in _sub_text(sub)
			if self.language1 in ('por', 'pob') or search_lang == 'pt':
				if self.language1 == 'por':
					idx = next((s.get('index') for s in subtitles if _lang_matches(s) and _is_portugal_text(_sub_text(s))), None)
					if idx is None:
						idx = next((s.get('index') for s in subtitles if _lang_matches(s) and not _is_brazil_text(_sub_text(s))), None)
				elif self.language1 == 'pob':
					idx = next((s.get('index') for s in subtitles if _lang_matches(s) and _is_brazil_text(_sub_text(s))), None)
				else:
					idx = next((s.get('index') for s in subtitles if _lang_matches(s)), None)
			else:
				idx = next((s.get('index') for s in subtitles if _lang_matches(s)), None)
			if idx is None:
				_sub_log('Local subtitle check -> no matching track for language=%s' % self.language1)
				return False

			# Identifie la piste sélectionnée afin de savoir si elle est marquée “forced”.
			# Kodi expose parfois ce statut via isforced=True, et parfois seulement
			# dans le nom de la piste. On tient compte des deux cas.
			selected_track = next((s for s in subtitles if s.get('index') == idx), {})
			selected_text = _sub_text(selected_track)
			self._last_selected_embedded_is_forced = bool(selected_track.get('isforced')) or 'forced' in selected_text or 'forcé' in selected_text or 'forces' in selected_text
			_sub_log('Local subtitle check -> selected track forced=%s | track=%s' % (self._last_selected_embedded_is_forced, selected_track))

			current = props.get('currentsubtitle')
			if isinstance(current, dict) and current.get('index') == idx:
				_sub_log('Local subtitle check -> matching track already selected index=%s' % idx)
				return True
			set_query = {"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": player_id, "subtitle": idx}, "id": 1}
			kodi_utils.execJSONRPC(json.dumps(set_query))
			_sub_log('Local subtitle check -> selected local track index=%s' % idx)
			return True
		except Exception as e:
			_sub_log('Local subtitle check exception -> %s: %s' % (type(e).__name__, e))
			return False

	# Sélection locale avec retries optionnels.
	# Utile car Kodi peut mettre un court délai avant d’exposer les pistes.
	def select_embedded_subtitle(self, retries=0, sleep_ms=0):
		retries = max(retries, 0)
		_sub_log('Local subtitle selection -> retries=%s | sleep_ms=%s | auto_enable=%s' % (retries, sleep_ms, self.auto_enable))
		for attempt in range(retries + 1):
			_sub_log('Local subtitle selection -> attempt %s/%s' % (attempt + 1, retries + 1))

			# Si la piste audio courante correspond déjà à la langue choisie,
			# on ne touche pas aux sous-titres locaux.
			#
			# Exemple : fichier MULTi avec audio français sélectionné automatiquement.
			# Dans ce cas, Kodi doit garder la main sur ses préférences,
			# notamment “sous-titres forcés seulement”.
			if self._current_audio_matches_language():
				_sub_log('Local subtitle selection skipped -> audio already matches selected language, Kodi keeps subtitle preferences')
				return True

			if self._select_embedded_subtitle_once():
				# Activation automatique uniquement dans deux cas :
				#   1. l’utilisateur a activé l’option générale d’affichage des sous-titres locaux;
				#   2. la piste locale correspondante est explicitement marquée comme forcée.
				#
				# Ce second cas corrige les fichiers VOSTFR/MULTi où Kodi sélectionne bien
				# la piste forcée, mais laisse parfois subtitleenabled=False.
				if self.auto_enable == 'true' or self._last_selected_embedded_is_forced:
					_sub_log('Local subtitle selection -> showSubtitles(True) | forced=%s | auto_enable=%s' % (self._last_selected_embedded_is_forced, self.auto_enable))
					self.showSubtitles(True)
				else:
					_sub_log('Local subtitle selection -> selected only, Kodi keeps display setting')
				return True
			if sleep_ms and attempt < retries: kodi_utils.sleep(sleep_ms)
		_sub_log('Local subtitle selection -> no local subtitle selected')
		return False

	# Point d’entrée du module.
	# Ordre volontaire : local/intégré -> fichier déjà téléchargé -> recherche Wyzie.

	# Vérifie la langue de la piste audio actuellement lue.
	# Objectif : si le média joue déjà dans la langue choisie pour les sous-titres
	# (ex. audio français + sous-titres français), on évite de lancer Wyzie inutilement
	# lorsqu’aucun sous-titre local adapté n’a été trouvé.
	def _current_audio_matches_language(self):
		_sub_log('Audio language check -> start')
		try:
			player_query = {"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}
			player_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(player_query)))
			player_id = next((p.get('playerid') for p in player_resp.get('result', []) if p.get('type') == 'video'), None)
			if player_id is None:
				_sub_log('Audio language check -> no active video player')
				return False

			props_query = {
				"jsonrpc": "2.0",
				"method": "Player.GetProperties",
				"params": {"playerid": player_id, "properties": ["currentaudiostream"]},
				"id": 1
			}
			props_resp = json.loads(kodi_utils.execJSONRPC(json.dumps(props_query)))
			props = props_resp.get('result', {})
			audio = props.get('currentaudiostream') or {}
			audio_language = (audio.get('language') or '').lower()
			audio_name = (audio.get('name') or '').lower()
			audio_text = '%s %s' % (audio_language, audio_name)

			target_language = (self.language1 or '').lower()
			target_short = (kodi_utils.convert_language(self.language1, format='short') or '').lower()
			candidates = {target_language, target_short}

			# Équivalences fréquentes entre ISO 639-1, ISO 639-2 et libellés Kodi.
			# Kodi peut retourner "fre", "fra", "fr" ou parfois un nom de piste en texte libre.
			if target_language in ('fre', 'fra') or target_short == 'fr':
				candidates.update(('fre', 'fra', 'fr', 'french', 'français', 'francais'))
			elif target_language == 'eng' or target_short == 'en':
				candidates.update(('eng', 'en', 'english', 'anglais'))
			elif target_language == 'spa' or target_short == 'es':
				candidates.update(('spa', 'es', 'spanish', 'espagnol'))
			elif target_language in ('por', 'pob') or target_short == 'pt':
				candidates.update(('por', 'pob', 'pt', 'pt-br', 'pt_br', 'ptbr', 'pt-pt', 'pt_pt', 'ptpt', 'portuguese', 'portugais'))

			candidates = {i for i in candidates if i}
			match = audio_language in candidates or any(i in audio_text for i in candidates if len(i) > 2)

			_sub_log('Audio language check -> current=%s | name=%s | expected=%s/%s | match=%s' % (audio_language, audio_name, target_language, target_short, match))
			return match
		except Exception as e:
			_sub_log('Audio language check exception -> %s: %s' % (type(e).__name__, e))
			return False


	def run(self, query, imdb_id, season, episode, poster):
		_sub_log('Run -> query=%s | imdb_id=%s | season=%s | episode=%s | action=%s | language=%s | api_key=%s' % (query, imdb_id, season, episode, self.subs_action, self.language1, 'présente' if self.apikey else 'absente'))
		# Étape 1 : priorité aux sous-titres déjà présents dans le média.
		# Si une piste locale correspond à la langue cible, Wyzie n’est pas appelé.
		def _video_file_subs():
			_sub_log('Step 1 -> checking local/embedded subtitles')
			if self.select_embedded_subtitle():
				_sub_log('Step 1 -> local/embedded subtitle selected')
				kodi_utils.notification(32852, icon=addon_icon)
				return True
			try: available_sub_language = self.getSubtitles()
			except Exception as e:
				_sub_log('Step 1 -> getSubtitles exception -> %s: %s' % (type(e).__name__, e))
				available_sub_language = ''
			_sub_log('Step 1 -> getSubtitles returned=%s | expected=%s' % (available_sub_language, self.language1))
			if not available_sub_language == self.language1:
				_sub_log('Step 1 -> no matching active/local subtitle, continue to downloaded/Wyzie')
				return False
			if self.auto_enable == 'true':
				_sub_log('Step 1 -> showSubtitles(True) for existing subtitle')
				self.showSubtitles(True)
			kodi_utils.notification(32852, icon=addon_icon)
			return True
		# Étape 2 : recherche d’un sous-titre déjà téléchargé dans special://temp/.
		# Cela évite de retélécharger le même fichier pendant la session.
		def _downloaded_subs():
			_sub_log('Step 2 -> checking already downloaded subtitle file=%s' % search_filename)
			files = kodi_utils.list_dirs(subtitle_path)[1]
			final_match = next((i for i in files if i == search_filename), None)
			if not final_match:
				_sub_log('Step 2 -> no downloaded subtitle found, continue to Wyzie')
				return False
			subtitle = '%s%s' % (subtitle_path, final_match)
			_sub_log('Step 2 -> downloaded subtitle found -> %s' % subtitle)
			kodi_utils.notification(32792, icon=addon_icon)
			return subtitle
		# Étape 3 : recherche externe via l’API Wyzie.
		# Cette étape est appelée seulement si aucune solution locale utile n’a été trouvée.
		def _searched_subs():
			_sub_log('Step 3 -> Wyzie search start')
			search_language = kodi_utils.convert_language(self.language1, format='short')
			_sub_log('Step 3 -> search_language=%s' % search_language)
			result = subtitles_search(imdb_id, season, episode, self.apikey, self.language1)
			if isinstance(result, str):
				_sub_log('Step 3 -> Wyzie error returned -> %s' % result)
				return kodi_utils.notification('Subtitles Error: %s' % result, icon=addon_icon)
			if not result:
				_sub_log('Step 3 -> Wyzie returned no result')
				return kodi_utils.notification(32793, icon=addon_icon)
			_sub_log('Step 3 -> Wyzie returned %s result(s)' % len(result))
			# Helpers de tri pour les variantes portugaises dans les résultats Wyzie.
			def _is_brazil(item):
				display = (item.get('display') or '').lower()
				flag = (item.get('flagUrl') or '').lower()
				text = '%s %s' % (display, flag)
				return any(i in text for i in ('brazil', 'brasil', 'brazilian', 'pt-br', 'ptbr', 'pt_br'))
			def _is_portugal(item):
				display = (item.get('display') or '').lower()
				flag = (item.get('flagUrl') or '').lower()
				text = '%s %s' % (display, flag)
				return any(i in text for i in ('portugal', 'iberian', 'european', 'pt-pt', 'ptpt', 'pt_pt'))
			def _lang_matches(item):
				lang = (item.get('language') or '').lower()
				if not lang: return False
				search_lang = (search_language or '').lower()
				candidates = {search_lang, (self.language1 or '').lower()}
				if search_lang == 'pt' or (self.language1 or '') in ('por', 'pob'):
					candidates.update(('pt', 'por', 'pob', 'pt-br', 'pt_br', 'ptbr'))
				return lang in candidates
			def _is_english(item):
				# L’anglais reste un plan B utile lorsque la langue choisie
				# n’est pas disponible chez Wyzie.
				lang = (item.get('language') or '').lower()
				display = (item.get('display') or '').lower()
				flag = (item.get('flagUrl') or '').lower()
				text = '%s %s %s' % (lang, display, flag)
				return lang in ('en', 'eng') or 'english' in text or 'anglais' in text

			def _priority_rank(item):
				# Ordre voulu dans la fenêtre de sélection :
				#   0. langue choisie dans alkoFlix (ex. Français);
				#   1. anglais comme solution de secours;
				#   2. autres langues.
				if _lang_matches(item): return 0
				if _is_english(item): return 1
				return 2

			# Tri stable : langue choisie en premier, anglais ensuite,
			# puis les autres langues en dernier, avec un ordre alphabétique lisible.
			result.sort(key=lambda k: ((k.get('display') or '').lower(), (k.get('source') or '').lower(), (k.get('media') or '').lower()), reverse=False)
			result.sort(key=_priority_rank, reverse=False)

			def _auto_choice_index():
				# En mode automatique, on choisit d’abord la langue configurée.
				# Si elle est absente, on permet l’anglais comme plan B.
				# Les autres langues ne sont pas choisies automatiquement.
				if search_language == 'pt' or (self.language1 or '') in ('por', 'pob'):
					if self.language1 == 'por':
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and _is_portugal(_)), -1)
						if idx >= 0: return idx
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and not _is_brazil(_)), -1)
						if idx >= 0: return idx
					elif self.language1 == 'pob':
						idx = next((i for i, _ in enumerate(result) if _lang_matches(_) and _is_brazil(_)), -1)
						if idx >= 0: return idx

				idx = next((i for i, _ in enumerate(result) if _lang_matches(_)), -1)
				if idx >= 0: return idx

				idx = next((i for i, _ in enumerate(result) if _is_english(_)), -1)
				if idx >= 0:
					_sub_log('Step 3 -> no selected-language subtitle found, English fallback selected index=%s' % idx)
					return idx

				return -1
			# Mode “Sélectionner” : si plusieurs résultats existent,
			# une boîte de dialogue permet de choisir le sous-titre.
			if self.subs_action == 'select' and len(result) > 1:
				_sub_log('Step 3 -> manual subtitle selection dialog opened')
				try: video_path = self.getPlayingFile()
				except: video_path = ''
				if '|' in video_path: video_path = video_path.split('|')[0]
				video_path = os.path.basename(video_path)
				heading = '%s - %s' % (ls(32246).upper(), video_path)
				def _builder():
					for i in result:
						listitem = kodi_utils.make_listitem()
						listitem.setLabel('%s%s' % (i['display'].upper(), ' (SDH)' if i['isHearingImpaired'] else ''))
						listitem.setLabel2('%s[CR]%s' % (i['source'].upper(), i['media']))
						listitem.setArt({'icon': i['flagUrl'].replace('24.png', '64.png')})
						yield listitem
				self.pause()
				chosen_sub = kodi_utils.dialog.select(heading, list(_builder()), useDetails=True)
				self.pause()
			else:
				chosen_sub = _auto_choice_index()
				_sub_log('Step 3 -> auto selected index=%s' % chosen_sub)
			if chosen_sub < 0:
				# Wyzie a bien retourné des résultats, mais aucun ne correspond
				# à la langue choisie ni au plan B anglais.
				# On affiche donc un message explicite pour éviter que l’utilisateur
				# pense que la recherche ne s’est pas lancée.
				_sub_log('Step 3 -> Wyzie returned results, but none matched selected language=%s or English fallback' % self.language1)
				return kodi_utils.notification('Aucun sous-titre trouvé dans la langue choisie ou en anglais', icon=addon_icon)
			chosen_sub = result[chosen_sub]
			_sub_log('Step 3 -> selected subtitle -> language=%s | source=%s | display=%s | media=%s' % (chosen_sub.get('language'), chosen_sub.get('source'), chosen_sub.get('display'), chosen_sub.get('media')))
			try: lang = kodi_utils.convert_language(chosen_sub['language'])
			except: lang = chosen_sub['language']
			encoding = chosen_sub['encoding'].lower()
			final_filename = sub_filename + '_%s.%s' % (lang, chosen_sub['format'])
			final_path = '%s%s' % (subtitle_path, final_filename)
			# Téléchargement du sous-titre choisi, puis écriture du fichier .srt temporaire.
			response = subtitles_download(chosen_sub['url'])
			if isinstance(response, str): return kodi_utils.notification('Subtitles Error: %s' % response, icon=addon_icon)
			try:
				if not 'utf-8' in encoding:
					import codecs
					content = codecs.decode(response.content, encoding=encoding)
				else: content = response.text
			except: content = response.content
			with kodi_utils.open_file(final_path, 'w') as file: file.write(content)
			_sub_log('Step 3 -> subtitle written -> %s' % final_path)
			kodi_utils.sleep(1000)
			return final_path
		if not self.subs_action in ('auto', 'select'):
			_sub_log('Run aborted -> subtitles action is off')
			return
		# Délai volontaire : laisse Kodi démarrer la lecture et exposer les pistes locales.
		kodi_utils.sleep(2500)
		# Emplacement temporaire volontaire.
		# alkoFlix nettoie ses sous-titres temporaires au démarrage.
		subtitle_path = 'special://temp/'
		sub_filename = 'alkoFlixSubs_%s_%s_%s' % (imdb_id, season, episode) if season else 'alkoFlixSubs_%s' % imdb_id
		search_filename = sub_filename + '_%s.srt' % self.language1
		# Si l’audio courant est déjà dans la langue choisie, alkoFlix ne force
		# aucun sous-titre local et ne lance pas Wyzie.
		#
		# Exemple : fichier MULTi + piste audio française sélectionnée automatiquement
		# par Kodi/alkoFlix. Dans ce cas, on laisse Kodi appliquer son propre réglage,
		# notamment “sous-titres forcés seulement”, sans intervenir.
		if self._current_audio_matches_language():
			_sub_log('Run finished -> audio already matches selected subtitle language, local subtitles and Wyzie skipped')
			return

		subtitle = _video_file_subs()
		if subtitle:
			_sub_log('Run finished -> local/embedded subtitle handled')
			return

		subtitle = _downloaded_subs()
		if subtitle:
			_sub_log('Run finished -> setting already downloaded subtitle')
			return self.setSubtitles(subtitle)
		subtitle = _searched_subs()
		if subtitle:
			_sub_log('Run finished -> setting Wyzie subtitle')
			return self.setSubtitles(subtitle)
		_sub_log('Run finished -> no subtitle set')
