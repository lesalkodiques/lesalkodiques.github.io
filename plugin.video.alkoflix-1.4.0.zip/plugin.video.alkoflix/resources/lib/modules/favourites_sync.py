# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/favourites_sync.py

from modules import kodi_utils, settings
from modules.utils import get_datetime
from caches.favourites_cache import favourites_cache, favourite_type_from_context, local_favourite_keys

logger = kodi_utils.logger
get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting


def _fetch_meta(media_type, tmdb_id):
	try:
		from indexers.metadata import movie_meta, tvshow_meta
		user_info = settings.metadata_user_info()
		if media_type == 'movie': return movie_meta('tmdb_id', tmdb_id, user_info, get_datetime())
		if media_type == 'tvshow': return tvshow_meta('tmdb_id', tmdb_id, user_info, get_datetime())
	except Exception as e:
		logger('alkoFlix favourites initial sync meta failed', '%s | %s | %s' % (media_type, tmdb_id, e))
	return None


def _store(media_type, tmdb_id, title=''):
	if not tmdb_id or media_type not in ('movie', 'tvshow'): return False
	meta = _fetch_meta(media_type, tmdb_id)
	fav_type = favourite_type_from_context(media_type, {}, '', meta)
	if meta and not title: title = meta.get('title') or meta.get('rootname') or ''
	success = False
	for key in local_favourite_keys(media_type, fav_type):
		# Stockage local dans la catégorie alkoFlix réelle seulement.
		# Le fournisseur choisi reste une sauvegarde globale en arrière-plan.
		success = favourites_cache.add_to_favourites(key, tmdb_id, title or str(tmdb_id)) or success
	return success


def _import_trakt():
	if not get_setting('trakt_user', ''): return 0
	from indexers import trakt_api
	count = 0
	for media_type in ('movie', 'tvshow'):
		for item in trakt_api.trakt_fetch_favorites(media_type) or []:
			ids = item.get('media_ids') or {}
			if _store(media_type, ids.get('tmdb'), item.get('title')): count += 1
	return count


def _import_tmdb():
	if not get_setting('tmdb.token', ''): return 0
	from indexers import tmdb_api
	count = 0
	for media_type, tmdb_type in (('movie', 'movie'), ('tvshow', 'tv')):
		for item in tmdb_api.all_items(tmdb_api.favorite, tmdb_type) or []:
			if _store(media_type, item.get('id'), item.get('title') or item.get('name')): count += 1
	return count


def import_external_favourites(source=None, force=False):
	try: source = int(source if source is not None else settings.favourites_import_source())
	except: source = 0
	provider_names = {1: 'Trakt', 3: 'TMDb', 4: 'alkoPastes'}
	if source not in (1, 3, 4): return {'success': False, 'source': source, 'provider': '', 'count': 0, 'error': 'disabled'}
	setting_key = 'favourites.sync.initialized.source'
	if not force and get_setting(setting_key, '') == str(source):
		return {'success': True, 'source': source, 'provider': provider_names[source], 'count': 0, 'skipped': True}
	logger('alkoFlix favourites initial sync', 'Starting | source=%s' % source)
	try:
		if source == 1: count = _import_trakt()
		elif source == 3: count = _import_tmdb()
		else:
			from modules.alkopastes_backup import import_alkopastes_favourites
			result = import_alkopastes_favourites()
			if not result.get('success'):
				error = result.get('error') or 'alkoPastes import failed'
				if error == 'missing_backup':
					logger('alkoFlix favourites initial sync', 'Skipped | source=%s | no alkoPastes backup found' % source)
					return {'success': False, 'source': source, 'provider': provider_names[source], 'count': 0, 'error': 'missing_backup'}
				raise Exception(error)
			count = result.get('count', 0)
		set_setting(setting_key, str(source))
		logger('alkoFlix favourites initial sync', 'Finished | source=%s | imported=%s' % (source, count))
		return {'success': True, 'source': source, 'provider': provider_names[source], 'count': count}
	except Exception as e:
		logger('alkoFlix favourites initial sync', 'Failed | source=%s | %s: %s' % (source, type(e).__name__, e))
		return {'success': False, 'source': source, 'provider': provider_names.get(source, ''), 'count': 0, 'error': '%s: %s' % (type(e).__name__, e)}



def _backup_counts(result):
	counts = (result or {}).get('counts') or {}
	return {
		'movies': int(counts.get('movies') or 0),
		'shows': int(counts.get('tvshows') or 0),
		'seasons': int(counts.get('seasons') or 0),
		'episodes': int(counts.get('episodes') or 0),
		'people': int(counts.get('people') or 0),
		'collections': int(counts.get('collections') or 0)
	}

def sync_local_favourites_to_external(source=None):
	source = 4
	provider_name = 'alkoPastes'
	logger('alkoFlix favourites alkoPastes sync', 'Starting')
	try:
		from modules.alkopastes_backup import export_local_favourites_to_alkopastes
		backup_result = export_local_favourites_to_alkopastes(force=True)
		counts = _backup_counts(backup_result)
		if not backup_result.get('success'):
			return {'success': False, 'source': source, 'provider': provider_name, 'error': backup_result.get('error') or 'alkoPastes export failed', **counts}
		logger('alkoFlix favourites alkoPastes sync', 'Finished | %s' % counts)
		return {'success': True, 'source': source, 'provider': provider_name, **counts}
	except Exception as e:
		logger('alkoFlix favourites alkoPastes sync', 'Failed | %s: %s' % (type(e).__name__, e))
		return {'success': False, 'source': source, 'provider': provider_name, 'error': '%s: %s' % (type(e).__name__, e), 'movies': 0, 'shows': 0, 'seasons': 0, 'episodes': 0, 'people': 0, 'collections': 0}
