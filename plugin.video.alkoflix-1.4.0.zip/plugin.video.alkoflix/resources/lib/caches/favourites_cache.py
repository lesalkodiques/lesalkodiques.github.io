# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/caches/favourites_cache.py

from caches import BaseCache, favourites_db, container_refresh
from modules import settings
from modules.utils import sort_for_article, paginate_list, get_datetime
from datetime import datetime
# from modules.kodi_utils import logger

INSERT_FAV = 'INSERT OR IGNORE INTO favourites (db_type, tmdb_id, title, added_at) VALUES (?, ?, ?, ?)'
DELETE_FAV = 'DELETE FROM favourites where db_type = ? and tmdb_id = ?'
SELECT_FAV = 'SELECT tmdb_id, title, added_at FROM favourites WHERE db_type = ?'
CLEAR_FAV = 'DELETE FROM favourites WHERE db_type = ?'

# Les clés ci-dessous gardent le type média réel dans le nom du favori local.
# Cela permet d'avoir des dossiers de favoris spécialisés sans multiplier les
# types techniques Kodi utilisés pour la lecture.
FAVOURITE_TYPES = (
	'movie', 'tvshow', 'season', 'episode',
	'movie_family', 'tv_family', 'season_family', 'episode_family',
	'movie_animation', 'tv_animation', 'season_animation', 'episode_animation',
	'anime_movie', 'anime_tv', 'anime_season', 'anime_episode',
	'movie_documentary', 'movie_tv_movie',
	'tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news', 'season_documentary', 'episode_documentary',
	'person', 'collection', 'collection_family', 'collection_animation', 'collection_anime'
)


# Les familles favorites restent locales. Les services externes ne voient que
# les films et séries globaux, tandis qu'alkoFlix conserve le classement précis.
MOVIE_FAVOURITE_TYPES = ('movie', 'movie_family', 'movie_animation', 'anime_movie', 'movie_documentary', 'movie_tv_movie')
TV_FAVOURITE_TYPES = ('tvshow', 'tv_family', 'tv_animation', 'anime_tv', 'tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news')
SEASON_FAVOURITE_TYPES = ('season', 'season_family', 'season_animation', 'anime_season', 'season_documentary')
EPISODE_FAVOURITE_TYPES = ('episode', 'episode_family', 'episode_animation', 'anime_episode', 'episode_documentary')
MOVIE_SPECIAL_FAVOURITE_TYPES = tuple(i for i in MOVIE_FAVOURITE_TYPES if i != 'movie')
TV_SPECIAL_FAVOURITE_TYPES = tuple(i for i in TV_FAVOURITE_TYPES if i != 'tvshow')
SEASON_SPECIAL_FAVOURITE_TYPES = tuple(i for i in SEASON_FAVOURITE_TYPES if i != 'season')
EPISODE_SPECIAL_FAVOURITE_TYPES = tuple(i for i in EPISODE_FAVOURITE_TYPES if i != 'episode')
TV_OBJECT_FAVOURITE_TYPES = TV_FAVOURITE_TYPES + SEASON_FAVOURITE_TYPES + EPISODE_FAVOURITE_TYPES
COLLECTION_FAVOURITE_TYPES = ('collection', 'collection_family', 'collection_animation', 'collection_anime')
ALL_LOCAL_FAVOURITE_TYPES = MOVIE_FAVOURITE_TYPES + TV_OBJECT_FAVOURITE_TYPES + ('person',) + COLLECTION_FAVOURITE_TYPES

SEASON_FAVOURITES_FROM_TV = {
	'tvshow': 'season',
	'tv_family': 'season_family',
	'tv_animation': 'season_animation',
	'anime_tv': 'anime_season',
	'tv_documentary': 'season_documentary',
	'tv_reality': 'season_documentary',
	'tv_talkshow': 'season_documentary',
	'tv_news': 'season_documentary'
}
EPISODE_FAVOURITES_FROM_TV = {
	'tvshow': 'episode',
	'tv_family': 'episode_family',
	'tv_animation': 'episode_animation',
	'anime_tv': 'anime_episode',
	'tv_documentary': 'episode_documentary',
	'tv_reality': 'episode_documentary',
	'tv_talkshow': 'episode_documentary',
	'tv_news': 'episode_documentary'
}

MOVIE_SPECIAL_FAVOURITES = {
	'movie_family': 'movie_family',
	'movie_family_kids': 'movie_family',
	'movie_animation': 'movie_animation',
	'anime_movie': 'anime_movie',
	'movie_documentary': 'movie_documentary',
	'movie_tv_movie': 'movie_documentary'
}

TV_SPECIAL_FAVOURITES = {
	'series_family': 'tv_family',
	'series_family_kids': 'tv_family',
	'series_animation': 'tv_animation',
	'anime_series': 'anime_tv',
	'anime_tv': 'anime_tv',
	'series_documentary': 'tv_documentary',
	'series_reality': 'tv_documentary',
	'series_talkshow': 'tv_documentary',
	'series_news': 'tv_documentary',
	'tv_documentary': 'tv_documentary',
	'tv_reality': 'tv_documentary',
	'tv_talkshow': 'tv_documentary',
	'tv_news': 'tv_documentary'
}

COLLECTION_SPECIAL_FAVOURITES = {
	'family': 'collection_family',
	'movie_family': 'collection_family',
	'animation': 'collection_animation',
	'movie_animation': 'collection_animation',
	'anime': 'collection_anime',
	'anime_movie': 'collection_anime'
}

def collection_favourite_type_from_saga_type(saga_type):
	return COLLECTION_SPECIAL_FAVOURITES.get(_normal_text(saga_type), 'collection')


def season_favourite_type_from_tv(tv_fav_type):
	return SEASON_FAVOURITES_FROM_TV.get(_normal_text(tv_fav_type), 'season')


def episode_favourite_type_from_tv(tv_fav_type):
	return EPISODE_FAVOURITES_FROM_TV.get(_normal_text(tv_fav_type), 'episode')


def tv_favourite_type_from_child(fav_type):
	fav_type = _normal_text(fav_type)
	if fav_type in SEASON_FAVOURITE_TYPES:
		for tv_type, season_type in SEASON_FAVOURITES_FROM_TV.items():
			if season_type == fav_type: return tv_type
	if fav_type in EPISODE_FAVOURITE_TYPES:
		for tv_type, episode_type in EPISODE_FAVOURITES_FROM_TV.items():
			if episode_type == fav_type: return tv_type
	return 'tvshow'


def child_favourite_type_from_parent(media_type, parent_fav_type):
	media_type = _base_media_type(media_type)
	if media_type == 'season': return season_favourite_type_from_tv(parent_fav_type)
	if media_type == 'episode': return episode_favourite_type_from_tv(parent_fav_type)
	return _normal_text(parent_fav_type) or media_type



def _normal_text(value):
	try:
		return str(value or '').strip().lower()
	except:
		return ''


def _meta_values(meta, key):
	try: value = (meta or {}).get(key)
	except: value = None
	if isinstance(value, (list, tuple, set)): return [_normal_text(i) for i in value if _normal_text(i)]
	return [_normal_text(i) for i in str(value or '').replace('|', ',').split(',') if _normal_text(i)]


def _meta_has_any(meta, key, names):
	values = _meta_values(meta, key)
	return any(any(name in value for name in names) for value in values)


def _meta_is_japanese(meta):
	country_codes = [i.upper() for i in _meta_values(meta, 'country_codes')]
	if 'JP' in country_codes: return True
	countries = _meta_values(meta, 'country')
	if any(i in countries for i in ('japan', 'japon')): return True
	language = _normal_text((meta or {}).get('original_language') or (meta or {}).get('original_lang'))
	return language == 'ja'


def _base_media_type(media_type):
	media_type = _normal_text(media_type)
	if media_type in ('tv', 'show', 'shows', 'series', 'tvshows', 'tvshow'): return 'tvshow'
	if media_type in ('movie', 'movies', 'film', 'films'): return 'movie'
	if media_type in ('person', 'people', 'actor', 'actress'): return 'person'
	if media_type in ('season', 'seasons'): return 'season'
	if media_type in ('episode', 'episodes'): return 'episode'
	if media_type in ('collection', 'collections', 'set', 'sets', 'saga', 'sagas'): return 'collection'
	return media_type


def favourite_type_from_context(media_type, params=None, action='', meta=None):
	media_type = _base_media_type(media_type)
	params = params or {}
	fav_type = _normal_text(params.get('fav_type') or params.get('favourite_type') or params.get('favorite_type'))
	if fav_type and fav_type not in ('movie', 'tvshow'):
		if fav_type in ('movie_tv_movie',): return 'movie_documentary'
		if fav_type in ('tv_reality', 'tv_talkshow', 'tv_news'): return 'tv_documentary'
		return fav_type

	if media_type in ('season', 'episode'):
		parent_fav_type = _normal_text(params.get('parent_fav_type') or params.get('series_fav_type') or params.get('tv_fav_type'))
		if parent_fav_type: return child_favourite_type_from_parent(media_type, parent_fav_type)
		return media_type
	if media_type == 'person': return media_type
	if media_type == 'collection':
		return collection_favourite_type_from_saga_type(params.get('saga_type'))

	documentary_type = _normal_text(params.get('documentary_type'))
	if documentary_type:
		if documentary_type in ('movie_documentary', 'movie_tv_movie') or documentary_type.startswith('movie'): return 'movie_documentary'
		if documentary_type.startswith('series') or documentary_type.startswith('tv'): return 'tv_documentary'
	family_type = _normal_text(params.get('family_type'))
	if family_type:
		if media_type == 'movie': return MOVIE_SPECIAL_FAVOURITES.get(family_type, 'movie')
		if media_type == 'tvshow': return TV_SPECIAL_FAVOURITES.get(family_type, 'tvshow')
	native_type = _normal_text(params.get('native_type'))
	if native_type == 'anime_movie': return 'anime_movie'
	if native_type == 'anime_series': return 'anime_tv'

	action = _normal_text(action or params.get('action'))
	if media_type == 'movie':
		if action.startswith(('tmdb_moviesanime_', 'trakt_moviesanime_')): return 'anime_movie'
		if action.startswith('tmdb_movies_family_animation_'): return 'movie_animation'
		if action.startswith('tmdb_movies_family_'): return 'movie_family'
		if action.startswith(('tmdb_movies_documentary_', 'tmdb_movies_tv_movie_')): return 'movie_documentary'
	elif media_type == 'tvshow':
		if action.startswith(('tmdb_tvanime_', 'trakt_tvanime_')): return 'anime_tv'
		if action.startswith('tmdb_tv_family_animation_'): return 'tv_animation'
		if action.startswith('tmdb_tv_family_') or action == 'tmdb_tv_networks': return 'tv_family'
		if action.startswith(('tmdb_tv_documentary_', 'tmdb_tv_reality_', 'tmdb_tv_talkshow_', 'tmdb_tv_news_')): return 'tv_documentary'

	# Fallback widgets : sans contexte de menu, on classe selon les genres TMDb.
	if meta:
		is_animation = _meta_has_any(meta, 'genre', ('animation', 'dessin animé', 'dessins animés'))
		is_japanese = _meta_is_japanese(meta)
		if media_type == 'movie':
			if is_animation and is_japanese: return 'anime_movie'
			if _meta_has_any(meta, 'genre', ('documentary', 'documentaire', 'tv movie', 'téléfilm', 'telefilm')): return 'movie_documentary'
			if is_animation: return 'movie_animation'
			if _meta_has_any(meta, 'genre', ('family', 'familial', 'familiaux', 'famille')): return 'movie_family'
		elif media_type == 'tvshow':
			if is_animation and is_japanese: return 'anime_tv'
			if _meta_has_any(meta, 'genre', ('documentary', 'documentaire', 'reality', 'téléréalité', 'telerealite', 'talk', 'talk-show', 'news', 'actualité', 'actualités')): return 'tv_documentary'
			if is_animation: return 'tv_animation'
			if _meta_has_any(meta, 'genre', ('family', 'familial', 'familiaux', 'famille', 'kids', 'enfant')): return 'tv_family'

	return media_type


def local_favourite_keys(media_type, favourite_type):
	media_type = _base_media_type(media_type)
	favourite_type = favourite_type_from_context(media_type, {'fav_type': favourite_type})
	# Un favori local ne doit vivre que dans sa catégorie alkoFlix réelle.
	# Trakt/MDBList/TMDb restent une sauvegarde externe globale films/séries,
	# mais on ne duplique plus les documentaires/animes/animations dans les
	# paniers racine movie/tvshow.
	return [favourite_type]

class Favourites(BaseCache):
	db_file = favourites_db

	def __init__(self):
		BaseCache.__init__(self)
		self._ensure_schema()

	def _ensure_schema(self):
		# Migration douce : les anciennes bases de favoris n'avaient pas de date d'ajout.
		try:
			columns = [i[1] for i in self.dbcur.execute("""PRAGMA table_info(favourites)""").fetchall()]
			if 'added_at' not in columns:
				self.dbcur.execute("""ALTER TABLE favourites ADD COLUMN added_at text""")
				now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				self.dbcur.execute("""UPDATE favourites SET added_at = ? WHERE added_at IS NULL OR added_at = ''""", (now,))
		except: pass
		# WIP10 : nettoyage des doublons créés par les WIP précédentes.
		# Les catégories spécialisées ne doivent plus remonter dans Films/Séries.
		try:
			movie_placeholders = ','.join('?' for _ in MOVIE_SPECIAL_FAVOURITE_TYPES)
			tv_placeholders = ','.join('?' for _ in TV_SPECIAL_FAVOURITE_TYPES)
			self.dbcur.execute("""DELETE FROM favourites WHERE db_type = 'movie' AND tmdb_id IN (SELECT tmdb_id FROM favourites WHERE db_type IN (%s))""" % movie_placeholders, MOVIE_SPECIAL_FAVOURITE_TYPES)
			self.dbcur.execute("""DELETE FROM favourites WHERE db_type = 'tvshow' AND tmdb_id IN (SELECT tmdb_id FROM favourites WHERE db_type IN (%s))""" % tv_placeholders, TV_SPECIAL_FAVOURITE_TYPES)
		except: pass

	def add_to_favourites(self, media_type, tmdb_id, title):
		try:
			added_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.dbcur.execute(INSERT_FAV, (media_type, str(tmdb_id), title, added_at))
			return True
		except: return False

	def add_to_favourites_at(self, media_type, tmdb_id, title, added_at=''):
		try:
			added_at = added_at or datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.dbcur.execute(INSERT_FAV, (media_type, str(tmdb_id), title, added_at))
			return True
		except: return False

	def remove_from_favourites(self, media_type, tmdb_id, title=''):
		try:
			self.dbcur.execute(DELETE_FAV, (media_type, str(tmdb_id)))
			container_refresh()
			return True
		except: return False

	def get_favourites(self, media_type):
		try: self._ensure_schema()
		except: pass
		self.dbcur.execute(SELECT_FAV, (media_type,))
		result = self.dbcur.fetchall()
		result = [{'tmdb_id': str(i[0]), 'title': str(i[1]), 'added_at': str(i[2] or '')} for i in result]
		return _sort_favourites(media_type, result)

	def clear_favourites(self, media_type):
		try:
			self.dbcur.execute(CLEAR_FAV, (media_type,))
			self.dbcur.execute("""VACUUM""")
			return True
		except: return False

	def count_favourites(self, media_types):
		try:
			if isinstance(media_types, str): media_types = (media_types,)
			media_types = tuple(str(i) for i in media_types if str(i or '').strip())
			if not media_types: return 0
			placeholders = ','.join('?' for _ in media_types)
			self.dbcur.execute("""SELECT COUNT(1) FROM favourites WHERE db_type IN (%s)""" % placeholders, media_types)
			row = self.dbcur.fetchone()
			return int(row[0] or 0) if row else 0
		except: return 0

	def has_favourites(self, media_types):
		return self.count_favourites(media_types) > 0

favourites_cache = Favourites()


def is_favourite(favourite_type, tmdb_id):
	try:
		if tmdb_id in ('', 'None', None): return False
		return any(str(i.get('tmdb_id')) == str(tmdb_id) for i in favourites_cache.get_favourites(favourite_type))
	except: return False

def favourites_context_label(favourite_type, tmdb_id):
	# Libellé volontairement neutre : l'action réelle (ajout/retrait) est confirmée dans la boîte de dialogue.
	return 'Favoris (alkoFlix)'

def clear_favourites_many(favourite_types):
	success = False
	for favourite_type in favourite_types:
		try: success = favourites_cache.clear_favourites(favourite_type) or success
		except: pass
	return success


def has_favourites_types(favourite_types):
	try:
		return favourites_cache.has_favourites(favourite_types)
	except: return False


def count_favourites_types(favourite_types):
	try:
		return favourites_cache.count_favourites(favourite_types)
	except: return 0

def _release_date_for_item(favourite_type, item):
	try:
		if favourite_type not in MOVIE_FAVOURITE_TYPES + TV_FAVOURITE_TYPES: return ''
		from indexers.metadata import movie_meta, tvshow_meta
		user_info = settings.metadata_user_info()
		current_date = get_datetime()
		if favourite_type in MOVIE_FAVOURITE_TYPES:
			meta = movie_meta('tmdb_id', item.get('tmdb_id'), user_info, current_date) or {}
		else:
			meta = tvshow_meta('tmdb_id', item.get('tmdb_id'), user_info, current_date) or {}
		return meta.get('premiered') or ''
	except: return ''


def _sort_favourites(favourite_type, data):
	try: sort_key = settings.lists_sort_order('favorites')
	except: sort_key = 0
	reverse = settings.lists_sort_reverse('favorites')
	if sort_key == 1:
		return sorted(data, key=lambda k: k.get('added_at') or '', reverse=reverse)
	if sort_key == 2:
		return sorted(data, key=lambda k: _release_date_for_item(favourite_type, k), reverse=reverse)
	data = sort_for_article(data, 'title', settings.ignore_articles())
	if reverse: data.reverse()
	return data


def _paginate_favourites_list(original_list, page_no, letter):
	paginate = settings.paginate()
	limit = settings.page_limit()
	try: page_no = int(page_no)
	except: page_no = 1
	if not original_list: return [], 1
	if paginate: final_list, total_pages = paginate_list(original_list, page_no, letter, limit)
	else: final_list, total_pages = original_list, 1
	return final_list or [], total_pages or 1


def get_favourites_by_type(favourite_type, page_no, letter):
	data = favourites_cache.get_favourites(favourite_type) or []
	original_list = [{'media_id': i['tmdb_id'], 'title': i['title'], 'added_at': i.get('added_at', '')} for i in data if i.get('tmdb_id')]
	return _paginate_favourites_list(original_list, page_no, letter)


def get_favourites_by_types(favourite_types, page_no, letter):
	# Agrégats utilisés uniquement par le dossier racine « Favoris ».
	# Les favoris restent stockés avec leur type réel dans favourites.db.
	seen, original_list = set(), []
	for favourite_type in favourite_types:
		for item in favourites_cache.get_favourites(favourite_type) or []:
			tmdb_id = item.get('tmdb_id')
			if not tmdb_id: continue
			key = str(tmdb_id)
			if key in seen: continue
			seen.add(key)
			original_list.append({'media_id': key, 'title': item.get('title', ''), 'added_at': item.get('added_at', '')})
	try: sort_key = settings.lists_sort_order('favorites')
	except: sort_key = 0
	reverse = settings.lists_sort_reverse('favorites')
	if sort_key == 1:
		original_list = sorted(original_list, key=lambda k: k.get('added_at') or '', reverse=reverse)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
		if reverse: original_list.reverse()
	return _paginate_favourites_list(original_list, page_no, letter)


def get_favourites(media_type, page_no, letter):
	return get_favourites_by_type(media_type, page_no, letter)


def get_favourites_movies_all(media_type, page_no, letter):
	# Tous les films non japonais : films racine + famille + animation + docus/téléfilms.
	return get_favourites_by_types(('movie', 'movie_family', 'movie_animation', 'movie_documentary', 'movie_tv_movie'), page_no, letter)


def get_favourites_tvshows_all(media_type, page_no, letter):
	# Toutes les séries non japonaises : séries racine + famille + animation + docus/télé.
	return get_favourites_by_types(('tvshow', 'tv_family', 'tv_animation', 'tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news'), page_no, letter)


def get_favourites_seasons_all(media_type, page_no, letter):
	return get_favourites_by_types(('season', 'season_family', 'season_animation', 'season_documentary'), page_no, letter)


def get_favourites_episodes_all(media_type, page_no, letter):
	return get_favourites_by_types(('episode', 'episode_family', 'episode_animation', 'episode_documentary'), page_no, letter)

def get_favourites_movie_family(media_type, page_no, letter):
	return get_favourites_by_type('movie_family', page_no, letter)

def get_favourites_tv_family(media_type, page_no, letter):
	return get_favourites_by_type('tv_family', page_no, letter)

def get_favourites_movie_animation(media_type, page_no, letter):
	return get_favourites_by_type('movie_animation', page_no, letter)

def get_favourites_tv_animation(media_type, page_no, letter):
	return get_favourites_by_type('tv_animation', page_no, letter)

def get_favourites_anime_movie(media_type, page_no, letter):
	return get_favourites_by_type('anime_movie', page_no, letter)

def get_favourites_anime_tv(media_type, page_no, letter):
	return get_favourites_by_type('anime_tv', page_no, letter)

def get_favourites_movie_documentary(media_type, page_no, letter):
	return get_favourites_by_type('movie_documentary', page_no, letter)

def get_favourites_movie_tv_movie(media_type, page_no, letter):
	return get_favourites_by_type('movie_documentary', page_no, letter)

def get_favourites_tv_documentary(media_type, page_no, letter):
	return get_favourites_by_type('tv_documentary', page_no, letter)

def get_favourites_tv_reality(media_type, page_no, letter):
	return get_favourites_by_type('tv_documentary', page_no, letter)

def get_favourites_tv_talkshow(media_type, page_no, letter):
	return get_favourites_by_type('tv_documentary', page_no, letter)

def get_favourites_tv_news(media_type, page_no, letter):
	return get_favourites_by_type('tv_documentary', page_no, letter)


def get_favourites_seasons(media_type, page_no, letter):
	return get_favourites_by_type('season', page_no, letter)

def get_favourites_episodes(media_type, page_no, letter):
	return get_favourites_by_type('episode', page_no, letter)
