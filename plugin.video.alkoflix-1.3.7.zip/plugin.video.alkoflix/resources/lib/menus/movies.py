# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/menus/movies.py

import sys
from threading import Thread
from indexers.metadata import movie_meta, rpdb_get, tmdb_image_base
from caches.watched_cache import get_watched_info_movie, get_watched_status_movie, get_bookmarks, get_resumetime, set_resumetime
from modules import kodi_utils, settings, user_ratings, parental_control
#from modules.utils import manual_function_import, get_datetime, make_thread_list_enumerate, chunks
from modules.utils import manual_function_import, get_datetime, TaskPool, chunks
# logger = kodi_utils.logger

# Alias locaux pour éviter les accès répétés aux modules pendant la construction des listes.
movie_meta_function, get_datetime_function, default_duration = movie_meta, get_datetime, 5400
get_watched_function, get_watched_info_function = get_watched_status_movie, get_watched_info_movie
KODI_VERSION, make_cast_list = kodi_utils.get_kodi_version(), kodi_utils.make_cast_list
string, ls, build_url, get_infolabel = str, kodi_utils.local_string, kodi_utils.build_url, kodi_utils.get_infolabel
remove_meta_keys, dict_removals = kodi_utils.remove_meta_keys, kodi_utils.movie_dict_removals
run_plugin, container_refresh, container_update = 'RunPlugin(%s)', 'Container.Refresh(%s)', 'Container.Update(%s)'
fanart_empty = kodi_utils.get_addoninfo('fanart')
poster_empty = kodi_utils.media_path('box_office.png')
item_jump = kodi_utils.media_path('item_jump.png')
item_next = kodi_utils.media_path('item_next.png')
watched_str, unwatched_str, traktmanager_str, tmdbmanager_str, mdblmanager_str = ls(32642), ls(32643), ls(32198), 'Gestion des listes TMDb', ls(32200)
favmanager_str, extras_str, options_str, recomm_str = ls(32197), 'Info & Extra', 'Options de lecture', '%s...' % ls(32503)
trailer_str = 'Bande annonce'
hide_str, clearprog_str, play_str = ls(32648), ls(32651), '%s...' % ls(32174)
nextpage_str, switchjump_str, jumpto_str = ls(32799), ls(32784), ls(32964)

ANIMATION_GENRE_NAMES = ('animation', 'dessin animé', 'dessins animés')

def _meta_has_animation_genre(genre):
	try:
		if isinstance(genre, (list, tuple)): values = genre
		else: values = str(genre or '').split(',')
		return any(str(item or '').strip().lower() in ANIMATION_GENRE_NAMES for item in values)
	except: return False

def _exclude_animation_for_action(action, params):
	if str(params.get('exclude_animation', '')).lower() == 'true': return True
	action = str(action or '')
	if not action: return False
	if action.startswith(('tmdb_moviesanime_', 'trakt_moviesanime_', 'tmdb_movies_family_', 'tmdb_movies_documentary_', 'tmdb_movies_tv_movie_')): return False
	if action in ('tmdb_movies_search', 'tmdb_movies_search_collections', 'tmdb_movies_collection'): return False
	if action.startswith(('tmdb_movies_', 'trakt_movies_', 'imdb_movies_')): return True
	return False

class Movies:
	def __init__(self, params):
		self.params = params
		self.items, self.new_page, self.total_pages = [], {}, None
		self.id_type, self.list, self.action, self.exit_list_params = (
			self.params.get('id_type', 'tmdb_id'),
			self.params.get('list', []),
			self.params.get('action'),
			self.params.get('exit_list_params')
		)
		self.append = self.items.append
		self.current_date = get_datetime_function()
		# Paramètres utilisés pour récupérer les métadonnées et les images selon la configuration utilisateur.
		self.meta_user_info = settings.metadata_user_info()
		self.watched_indicators = settings.watched_indicators()
		self.watched_info = get_watched_info_function(self.watched_indicators)
		self.bookmarks = get_bookmarks(self.watched_indicators, 'movie')
		self.include_year_in_title = settings.include_year_in_title('movie')
		self.media_click_opens_info = settings.media_click_opens_info()
		# Info & Extra utilise la fenêtre d'information native du skin.
		self.open_extras = False
		# Menu contextuel natif : ordre fixe, entrées externes selon services autorisés.
		self.cm_sort = settings.context_menu_sort()
		self.cm_services = settings.context_menu_services()
		self.rpdb_enabled = self.meta_user_info['extra_rpdb_movies']
		self.fanart_enabled = self.meta_user_info['extra_fanart_enabled']
		self.is_widget = kodi_utils.external_browse()
		self.widget_hide_watched = self.is_widget and self.meta_user_info['widget_hide_watched']
		if not self.exit_list_params: self.exit_list_params = get_infolabel('Container.FolderPath')
		self.watched_title = ('alkoFlix', 'Trakt', 'MDBList')[self.watched_indicators]
		self.poster_main, self.poster_backup, self.fanart_main, self.fanart_backup = settings.get_art_provider()
		self.user_ratings = user_ratings.get_active_ratings_index()
		self.parental_blocked = False
		self.exclude_animation_content = _exclude_animation_for_action(self.action, self.params)

	def build_movie_content(self, _position, _id):
		try:
			# Récupère les métadonnées du film avant de construire l'item Kodi.
			meta = movie_meta_function(self.id_type, _id, self.meta_user_info, self.current_date)
			meta_get = meta.get
			if not meta or meta_get('blank_entry', False): return
			if self.exclude_animation_content and _meta_has_animation_genre(meta_get('genre')): return
			if not parental_control.meta_allowed(meta, self.action, 'movie'):
				self.parental_blocked = True
				return
			playcount, overlay = get_watched_function(self.watched_info, string(meta['tmdb_id']))
			# Dans les widgets, on peut masquer les films déjà vus selon le réglage utilisateur.
			if self.widget_hide_watched and playcount: return
			meta.update({'playcount': playcount, 'overlay': overlay})
			resumetime, progress = get_resumetime(self.bookmarks, string(meta['tmdb_id']))
			sort = _id.get('sort', _position) if self.id_type == 'trakt_dict' else _position
			props = {'alkoflix_sort_order': string(sort)}
			cm = []
			cm_append = cm.append
			clearprog_params, unwatched_params, watched_params = '', '', ''
			rootname, title, year = meta_get('rootname'), meta_get('title'), meta_get('year')
			tmdb_id, imdb_id = meta_get('tmdb_id'), meta_get('imdb_id')
			user_rating = user_ratings.get_user_rating(self.user_ratings, 'movie', tmdb_id=tmdb_id, imdb_id=imdb_id)
			if user_rating: meta['userrating'] = user_rating
			poster = meta_get(self.poster_main) or meta_get(self.poster_backup) or poster_empty
			media_fanart = meta_get(self.fanart_main) or meta_get(self.fanart_backup)
			fanart = media_fanart or fanart_empty
			clearlogo = meta_get('clearlogo') or meta_get('tmdblogo') or ''
			if self.rpdb_enabled:
				rpdb_data = rpdb_get('movie', imdb_id or str(tmdb_id), self.meta_user_info['rpdb_api_key'])
				poster = rpdb_data.get('rpdb') or poster
			# Les images supplémentaires ne sont utilisées que si Fanart.tv est activé.
			# Ne force pas le fanart dans landscape : plusieurs skins affichent alors mieux le clearlogo.
			if self.fanart_enabled:
				banner, clearart, landscape, discart = meta_get('banner'), meta_get('clearart'), meta_get('landscape'), meta_get('discart')
			else: banner, clearart, landscape, discart = '', '', '', ''
			if not landscape and not media_fanart: landscape = poster
			play_params = build_url({'mode': 'play_media', 'media_type': 'movie', 'tmdb_id': tmdb_id})
			options_params = build_url({'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'is_widget': self.is_widget})
			recommended_params = build_url({'mode': 'build_movie_list', 'action': 'tmdb_movies_recommendations', 'tmdb_id': tmdb_id})
			trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None'})
			tmdb_manager_params = build_url({'mode': 'tmdb_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None'})
			mdbl_manager_params = build_url({'mode': 'mdbl_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None'})
			rating_params = build_url({'mode': 'rating_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None', 'title': title})
			fav_manager_params = build_url({'mode': 'favourites_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': 'None', 'title': title})
			trailer_params = build_url({'mode': 'play_trailer_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id})
			info_extra_params = build_url({'mode': 'info_extra_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'is_widget': string(self.is_widget).lower()})
			# Menu contextuel natif : Info & Extra ouvre la fiche info du skin.
			cm_append((self.cm_sort['options'], options_str, run_plugin % options_params))
			cm_append((self.cm_sort['options'], trailer_str, run_plugin % trailer_params))
			cm_append((self.cm_sort['extras'], extras_str, run_plugin % info_extra_params))
			url_params = info_extra_params if self.media_click_opens_info else play_params
			if self.cm_services['trakt']: cm_append((self.cm_sort['trakt'], traktmanager_str, run_plugin % trakt_manager_params))
			if self.cm_services['mdblist']: cm_append((self.cm_sort['mdblist'], mdblmanager_str, run_plugin % mdbl_manager_params))
			if self.cm_services['tmdblist']: cm_append((self.cm_sort['tmdblist'], tmdbmanager_str, run_plugin % tmdb_manager_params))
			if settings.context_rating_enabled('movie'): cm_append((self.cm_sort['rating'], ls(33135), run_plugin % rating_params))
			if settings.context_favourites_enabled(): cm_append((self.cm_sort['favourites'], favmanager_str, run_plugin % fav_manager_params))
			if progress != '0' or resumetime != '0': cm_append((self.cm_sort['mark'], clearprog_str, run_plugin % build_url({
				'mode': 'watched_unwatched_erase_bookmark', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'refresh': 'true'
			})))
			if playcount: cm_append((self.cm_sort['mark'], unwatched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_movie', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'title': title, 'year': year
			})))
			else: cm_append((self.cm_sort['mark'], watched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_movie', 'action': 'mark_as_watched', 'tmdb_id': tmdb_id, 'title': title, 'year': year
			})))
			# Trie les entrées du menu contextuel selon l'ordre automatique.
			cm.sort(key=lambda k: k[0])
			cm = [v for k, *v in cm if k]
			listitem = kodi_utils.make_listitem()
			listitem.addContextMenuItems(cm)
			listitem.setProperties(props)
			listitem.setLabel(rootname if self.include_year_in_title else title)
#			listitem.setContentLookup(False)
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'banner': banner, 'clearart': clearart,
							'clearlogo': clearlogo, 'landscape': landscape, 'discart': discart})
			if KODI_VERSION < 20:
				listitem.setCast(meta_get('cast', []))
				listitem.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id)})
				listitem.setInfo('video', remove_meta_keys(meta, dict_removals))
				listitem.setProperty('resumetime', resumetime)
			else:
				videoinfo = listitem.getVideoInfoTag(offscreen=True)
				videoinfo.setCast(make_cast_list(meta_get('cast', [])))
				videoinfo.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id)})
				videoinfo.setCountries(meta_get('country'))
				videoinfo.setDirectors(meta_get('director').split(', '))
				videoinfo.setDuration(int(meta_get('duration') or default_duration))
				videoinfo.setGenres(meta_get('genre').split(', '))
				videoinfo.setIMDBNumber(imdb_id)
				videoinfo.setMediaType('movie')
				videoinfo.setMpaa(meta_get('mpaa'))
				videoinfo.setPlaycount(playcount)
				videoinfo.setPlot(meta_get('plot'))
				videoinfo.setPremiered(meta_get('premiered'))
				videoinfo.setRating(meta_get('rating'))
				user_ratings.apply_user_rating_to_listitem(listitem, user_rating, videoinfo)
				videoinfo.setStudios((meta_get('studio'),))
				videoinfo.setTagLine(meta_get('tagline'))
				videoinfo.setTitle(rootname if self.include_year_in_title else title)
				videoinfo.setTrailer(meta_get('trailer'))
				videoinfo.setVotes(meta_get('votes'))
				videoinfo.setWriters(meta_get('writer').split(', '))
				videoinfo.setYear(int(year))
				if int(progress):
					listitem.setProperty('watchedprogress', progress)
					videoinfo.setResumePoint(*set_resumetime(resumetime, progress, videoinfo.getDuration()))
			self.append((url_params, listitem, False))
		except: pass

	def worker(self):
#		threads = list(make_thread_list_enumerate(self.build_movie_content, self.list, Thread))
		# Construction multi-threadée pour accélérer les longues listes de films.
		for i in TaskPool().tasks_enumerate(self.build_movie_content, self.list, Thread): i.join()
		self.items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		return self.items

class Menu(Movies):
	tmdb_main, trakt_main, tmdb_special_key_dict = (
		'tmdb_movies_popular', 'tmdb_movies_trending', 'tmdb_movies_random', 'tmdb_movies_top_rated', 'tmdb_movies_latest_releases', 'tmdb_movies_premieres', 'tmdb_movies_upcoming',
		'tmdb_movies_blockbusters', 'tmdb_moviesanime_popular', 'tmdb_moviesanime_random', 'tmdb_moviesanime_latest_releases',
		'tmdb_movies_family_popular', 'tmdb_movies_family_random', 'tmdb_movies_family_latest_releases',
		'tmdb_movies_family_animation_popular', 'tmdb_movies_family_animation_random', 'tmdb_movies_family_animation_latest_releases',
		'tmdb_movies_documentary_popular', 'tmdb_movies_documentary_random', 'tmdb_movies_documentary_trending', 'tmdb_movies_documentary_latest_releases',
		'tmdb_movies_tv_movie_popular', 'tmdb_movies_tv_movie_random', 'tmdb_movies_tv_movie_trending', 'tmdb_movies_tv_movie_latest_releases'
	), (
		'trakt_movies_trending', 'trakt_movies_trending_recent', 'trakt_movies_most_watched',
		'trakt_moviesanime_trending', 'trakt_moviesanime_most_watched'
	), {
		'tmdb_movies_networks': 'company', 'tmdb_movies_year': 'year', 'tmdb_moviesanime_year': 'year',
		'tmdb_movies_language': 'language_code', 'tmdb_movies_watch_provider': 'provider_id',
		'tmdb_moviesanime_language': 'language_code', 'tmdb_moviesanime_watch_provider': 'provider_id',
		'tmdb_movies_family_year': 'year', 'tmdb_movies_family_watch_provider': 'provider_id', 'tmdb_movies_family_kids_watch_provider': 'provider_id', 'tmdb_movies_family_genres': 'genre_id',
		'tmdb_movies_family_animation_year': 'year', 'tmdb_movies_family_animation_watch_provider': 'provider_id', 'tmdb_movies_family_animation_genres': 'genre_id',
		'tmdb_movies_documentary_year': 'year', 'tmdb_movies_documentary_language': 'language_code', 'tmdb_movies_documentary_watch_provider': 'provider_id', 'tmdb_movies_documentary_genres': 'genre_id',
		'tmdb_movies_tv_movie_year': 'year', 'tmdb_movies_tv_movie_language': 'language_code', 'tmdb_movies_tv_movie_watch_provider': 'provider_id', 'tmdb_movies_tv_movie_genres': 'genre_id',
		'tmdb_movies_keyword': 'keyword_id'
	}
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_favorites', 'trakt_collection_lists')
	mdblist_personal = ('mdblist_collection', 'mdblist_watchlist', 'mdblist_favorites')
	imdb_personal = ('imdb_watchlist', 'imdb_user_list_contents')
	similar = ('tmdb_movies_similar', 'tmdb_movies_recommendations')
	personal_dict = {
		'in_progress_movies': ('caches.watched_cache', 'get_in_progress_movies'),
		'favourites_movies': ('caches.favourites_cache', 'get_favourites'),
		'watched_movies': ('caches.watched_cache', 'get_watched_items')
	}

	def run(self):
		try:
			params_get = self.params.get
			self.handle, self.builder = int(sys.argv[1]), self.worker
			view_type, content_type = 'view.movies', 'movies'
			mode = params_get('mode')
			try: page_no = int(params_get('new_page', '1'))
			except ValueError: page_no = params_get('new_page')
			letter = params_get('new_letter', 'None')
			if self.action in Menu.personal_dict: var_module, import_function = Menu.personal_dict[self.action]
			else: var_module, import_function = 'indexers.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			if self.action in Menu.tmdb_main:
				data = function(page_no)
				self.list = [i['id'] for i in data['results']]
				total_pages = data['total_pages']
				if total_pages > page_no: self.new_page = {'new_page': string(data['page'] + 1)}
			elif self.action in Menu.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				self.list = [i['movie']['ids'] for i in data]
				if self.action not in ('trakt_moviesanime_trending',):
					self.new_page = {'new_page': string(page_no + 1)}
			elif self.action in Menu.tmdb_personal:
				data, total_pages = function('movie', page_no, letter)
				self.list = [i['id'] for i in data]
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.trakt_personal:
				self.id_type = 'trakt_dict'
				data, total_pages = function('movies', page_no, letter)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
				except: pass
			elif self.action in Menu.mdblist_personal:
				self.id_type = 'trakt_dict'
				data, total_pages = function('movies', page_no, letter)
				self.list = [{'imdb': i['imdb_id'], 'tmdb': i['id']} for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
				except: pass
			elif self.action in Menu.imdb_personal:
				self.id_type = 'imdb_id'
				list_id = params_get('list_id')
				data, next_page = function('movie', list_id, page_no)
				self.list = [i['imdb_id'] for i in data]
				if next_page: self.new_page = {'list_id': list_id, 'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.personal_dict:
				data, total_pages = function('movie', page_no, letter)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.similar:
				tmdb_id = params_get('tmdb_id')
				data = function(tmdb_id, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['page'] < data['total_pages']: self.new_page = {'new_page': string(data['page'] + 1), 'tmdb_id': tmdb_id}
			elif self.action in Menu.tmdb_special_key_dict:
				key = Menu.tmdb_special_key_dict[self.action]
				function_var = params_get(key)
				if not function_var: return
				provider_region = params_get('provider_region')
				if self.action.endswith('_watch_provider') and provider_region:
					data = function(function_var, page_no, provider_region) or {}
				else:
					data = function(function_var, page_no) or {}
				results = data.get('results', []) if isinstance(data, dict) else []
				self.list = [i.get('id') for i in results if isinstance(i, dict) and i.get('id')]
				if self.action.endswith('_watch_provider') and not self.list:
					kodi_utils.logger('catalogue provider empty', '%s | provider_id=%s | region=%s | page=%s' % (self.action, function_var, provider_region or 'settings', page_no))
				if isinstance(data, dict) and data.get('page', page_no) < data.get('total_pages', page_no):
					self.new_page = {'new_page': string(data.get('page', page_no) + 1), key: function_var}
					if provider_region: self.new_page['provider_region'] = provider_region
			elif self.action == 'tmdb_movies_discover':
				from menus.discover import set_history
				name, query = params_get('name'), params_get('query')
				if page_no == 1: set_history('movie', name, query)
				data = function(query, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['page'] < data['total_pages']: self.new_page = {'query': query, 'name': name, 'new_page': string(data['page'] + 1)}
			elif self.action == 'imdb_movies_oscar_winners':
				from modules.meta_lists import oscar_winners
				self.list = [i for i in chunks(oscar_winners, 20)][page_no-1]
				if self.list[-1] != 631: self.new_page = {'new_page': string(page_no + 1)}
			elif self.action in ('tmdb_movies_genres', 'tmdb_moviesanime_genres'):
				# Certains retours TMDb peuvent être vides ou incomplets.
				# On sécurise la lecture pour éviter un échec complet du répertoire Kodi.
				genre_id = params_get('genre_id')
				if not genre_id: return
				data = function(genre_id, page_no) or {}
				results = data.get('results', []) if isinstance(data, dict) else []
				self.list = [i.get('id') for i in results if isinstance(i, dict) and i.get('id')]
				if isinstance(data, dict) and data.get('page', page_no) < data.get('total_pages', page_no):
					self.new_page = {'new_page': string(data.get('page', page_no) + 1), 'genre_id': genre_id}
			elif self.action == 'tmdb_movies_search':
				query = params_get('query')
				data = function(query, page_no)
				self.list = [i['id'] for i in data['results']]
				total_pages = data['total_pages']
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter, 'query': query}
			elif self.action == 'tmdb_movies_search_collections':
				self.builder, view_type, content_type = self.build_collections_results, 'view.movies', 'sets'
				query = params_get('query')
				data = function(query, page_no)
				self.list = data['results']
				total_pages = data['total_pages']
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'query': query}
			elif self.action == 'tmdb_movies_curated_collections':
				self.builder, view_type, content_type = self.build_collections_results, 'view.movies', 'sets'
				saga_type = params_get('saga_type', 'movie')
				data = function(saga_type, page_no)
				self.list = data.get('results', [])
				total_pages = data.get('total_pages', 1)
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'saga_type': saga_type}
			elif self.action == 'tmdb_movies_collection':
				data = sorted(function(params_get('collection_id'))['parts'], key=lambda k: k['release_date'] or '2050')
				self.list = [i['id'] for i in data]
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('movies')
				self.list = [i['ids'] for i in data]
			# Ajoute l'entrée de navigation rapide seulement dans les listes complètes, pas dans les widgets.
			if self.total_pages and not self.is_widget and settings.nav_jump_use_alphabet():
				url_params = {
					'mode': 'build_navigate_to_page', 'current_page': page_no, 'total_pages': self.total_pages,
					'query': params_get('search_name', ''), 'actor_id': params_get('actor_id', ''),
					'transfer_mode': mode, 'transfer_action': self.action, 'media_type': 'Films'
				}
				kodi_utils.add_dir(self.handle, url_params, jumpto_str, item_jump, isFolder=False)
			items = self.builder()
			if items: kodi_utils.add_items(self.handle, items)
			if self.new_page:
				self.new_page.update({'mode': mode, 'action': self.action, 'exit_list_params': self.exit_list_params, 'name': ls(params_get('name'))})
				kodi_utils.add_dir(self.handle, self.new_page, nextpage_str, item_next)
		except Exception as e:
			kodi_utils.logger('movies menu error', '%s: %s' % (self.action, e))
		kodi_utils.set_category(self.handle, ls(params_get('name')))
		kodi_utils.set_sort_method(self.handle, content_type)
		kodi_utils.set_content(self.handle, content_type)
		kodi_utils.end_directory(self.handle, False if self.is_widget else None)
		kodi_utils.set_view_mode(view_type, content_type)

	def build_collections_results(self):
		# Construit les résultats de collections TMDb comme dossiers navigables.
		def _process():
			for item in self.list:
				url_params = build_url({'mode': 'build_movie_list', 'action': 'tmdb_movies_collection', 'collection_id': item['id']})
				poster_path, backdrop_path = item['poster_path'], item['backdrop_path']
				if poster_path: poster = tmdb_image_base % (image_resolution['poster'], poster_path)
				else: poster = poster_empty
				if backdrop_path: fanart = tmdb_image_base % (image_resolution['fanart'], backdrop_path)
				else: fanart = fanart_empty
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(item['name'])
				kodi_utils.set_listitem_video_info(listitem, {'plot': item['overview'], 'mediatype': 'set', 'title': item['name']})
				listitem.setArt({'icon': poster, 'fanart': fanart})
				yield (url_params, listitem, True)
		image_resolution = settings.get_resolution()
		self.items = list(_process())
		return self.items

