# resource.images.moviegenreicons.transparent

## Icônes de genres multilingues (français et anglais) 

- Icones de genres pris en charge par défaut avec plusieurs skins.

## 🔗 TÉLÉCHARGER: https://lesalkodiques.github.io/repo/
