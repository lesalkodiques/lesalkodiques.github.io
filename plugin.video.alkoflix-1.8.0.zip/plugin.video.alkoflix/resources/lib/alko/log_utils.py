# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/alko/log_utils.py

import inspect
from alko.control import transPath, setting as getSetting, lang
from modules.log_sanitizer import sanitize_log_text

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5 # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
DEBUGPREFIX = '[ alkoFlix SOURCES %s ]'
LOGPATH = transPath('special://logpath/')


def _mask_sensitive_log_text(text):
	return sanitize_log_text(text)

def log(msg, caller=None, level=LOGDEBUG):
	debug_enabled = getSetting('debug.enabled') == 'true'
	if not debug_enabled: return
	if isinstance(msg, int): msg = lang(msg) # for strings.po translations
	try:
		if not msg.isprintable(): # ex. "\n" is not a printable character so returns False on those sort of cases
			msg = '%s (NORMALIZED by log_utils.log())' % normalize(msg)
		if isinstance(msg, bytes):
			msg = '%s (ENCODED by log_utils.log())' % msg.decode('utf-8', errors='replace')

		msg = _mask_sensitive_log_text(msg)

		if caller == 'scraper_error': pass
		elif caller is not None and level != LOGERROR:
			func = inspect.currentframe().f_back.f_code
			line_number = inspect.currentframe().f_back.f_lineno
			caller = "%s.%s()" % (caller, func.co_name)
			msg = '\nFrom func name: %s Line # :%s\n           msg: %s' % (caller, line_number, msg)
		elif caller is not None and level == LOGERROR:
			msg = '\nFrom func name: %s.%s() Line # :%s\n           msg: %s' % (caller[0], caller[1], caller[2], msg)

		# Quand le débogage alkoFlix est activé, les diagnostics doivent rester
		# visibles même si le débogage global Kodi est désactivé. Les messages
		# DEBUG/INFO sont donc envoyés en niveau Kodi INFO, tout en conservant
		# le libellé interne DEBUG/INFO dans le préfixe. Les avertissements et
		# erreurs gardent leur niveau Kodi naturel.
		import xbmc
		try:
			label = debug_list[level]
		except Exception:
			label = 'DEBUG'
		try:
			if level >= LOGERROR:
				kodi_level = getattr(xbmc, 'LOGERROR', LOGERROR)
			elif level == LOGWARNING:
				kodi_level = getattr(xbmc, 'LOGWARNING', LOGWARNING)
			else:
				kodi_level = getattr(xbmc, 'LOGINFO', LOGINFO)
		except Exception:
			kodi_level = LOGINFO
		xbmc.log('%s: %s' % (DEBUGPREFIX % label, msg), kodi_level)
	except Exception as e:
		import traceback
		traceback.print_exc()
		import xbmc
		xbmc.log('[ plugin.video.alkoflix ] log_utils.log() Logging Failure: %s' % (e), LOGERROR)

def error(message=None, exception=True):
	try:
		import sys
		if exception:
			type, value, traceback = sys.exc_info()
			addon = 'plugin.video.alkoflix'
			filename = (traceback.tb_frame.f_code.co_filename)
			filename = filename.split(addon)[1]
			name = traceback.tb_frame.f_code.co_name
			linenumber = traceback.tb_lineno
			errortype = type.__name__
			errormessage = value or value.message
			if str(errormessage) == '': return
			if message: message += ' -> '
			else: message = ''
			message += str(errortype) + ' -> ' + str(errormessage)
			caller = [filename, name, linenumber]
		else:
			caller = None
		del(type, value, traceback) # So we don't leave our local labels/objects dangling
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		import xbmc
		xbmc.log('[ plugin.video.alkoflix ] log_utils.error() Logging Failure: %s' % (e), LOGERROR)


def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except:
		error()
		return msg

