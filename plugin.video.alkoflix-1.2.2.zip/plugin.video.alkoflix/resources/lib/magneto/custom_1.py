# created  for alkoscrapers
"""
	alkoscrapers Project
"""

import re
from json import loads as jsloads
from urllib.parse import quote, urlparse

from alko import client
from alko import source_utils
from alko.control import setting as getSetting


class source:
	timeout = 7
	priority = 1
	pack_capable = False # packs parsed in sources function
	hasMovies = True
	hasEpisodes = True
	def _base_from_manifest(self, manifest_url):
		if not manifest_url: return None
		try:
			if '://' not in manifest_url:
				manifest_url = 'https://%s' % manifest_url
			parsed = urlparse(manifest_url)
			if not parsed.scheme or not parsed.netloc: return None
			path = parsed.path or ''
			for suffix in ('/manifest.json', '/manifest'):
				if path.endswith(suffix):
					path = path[:-len(suffix)]
					break
			base_url = '%s://%s%s' % (parsed.scheme, parsed.netloc, path)
			return base_url.rstrip('/')
		except:
			return None
	def _release_title_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		release_title = meta.get('originalTitle') or meta.get('title') or meta.get('name') or ''
		if not release_title:
			release_title = behavior.get('filename') or ''
		if not release_title:
			for key in ('title', 'description'):
				text = stream.get(key) or ''
				if not text: continue
				text = text.replace('\u2508\u27a4', '\n')
				match = re.search(r'([A-Za-z0-9].*?\.(?:mkv|mp4|avi|m2ts|m4v|ts))', text, re.IGNORECASE)
				if match:
					return match.group(1).strip()
				line = text.split('\n')[0].strip()
				if line:
					release_title = line
					break
		if not release_title:
			release_title = stream.get('name') or ''
		return release_title
	def __init__(self):
		self.language = ['en', 'fr']
		self.display_name = getSetting('custom_1.name', '').strip() or 'Custom Stremio Addon 1'
		manifest_url = getSetting('custom_1.manifest_url', '').strip()
		self.base_link = self._base_from_manifest(manifest_url) if manifest_url else None
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data or not self.base_link: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace(':', ' ')
			title = re.sub(r'\s+', ' ', title).strip()
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			total_seasons = data['total_seasons'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data.get('imdb')
			catalogue_id = data.get('catalogue_id')
			if 'tvshowtitle' in data:
				if not imdb: return sources
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
			else:
				hdlr = year
				request_id = catalogue_id or imdb
				if not request_id: return sources
				url = '%s%s' % (self.base_link, self.movieSearch_link % quote(str(request_id), safe=':'))
			# log_utils.log('url = %s' % url)
			if 'timeout' in data: self.timeout = int(data['timeout'])
			results = client.request(url, timeout=self.timeout)
			files = jsloads(results).get('streams') or [] if results else []
			# Les résultats CUSTOM_STREMIO1 doivent respecter la configuration du manifest.
			# Aucun filtre de langue alkoFlix n'est appliqué ici.
		except:
			source_utils.scraper_error('CUSTOM_STREMIO1')
			return sources

		for file in files:
			try:
				package, episode_start = None, 0
				meta = file.get('meta') or {}
				behavior = file.get('behaviorHints') or {}
				direct_url = file.get('url')
				info_hash = file.get('infoHash') or file.get('infohash') or file.get('info_hash')
				source_type = (meta.get('type') or file.get('type') or '').lower()
				if source_type == 'nzb': source_type = 'usenet'
				if source_type == 'http': source_type = 'direct'
				if direct_url and str(direct_url).lower().startswith('magnet:'):
					source_type = 'torrent'
				if not source_type:
					source_type = 'torrent' if info_hash else 'direct'
				use_direct = bool(direct_url) and not str(direct_url).lower().startswith('magnet:')
				if not info_hash and not use_direct and direct_url:
					match = re.search(r'btih:([A-Fa-f0-9]{40})', direct_url)
					if match: info_hash = match.group(1)
				info_hash = None if use_direct else info_hash

				release_title = self._release_title_from_stream(file, meta, behavior)
				name = source_utils.clean_name(release_title)
				if not name: continue

				if total_seasons is not None:
					valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
					if valid:
						package = 'show'
					else:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name)
						if valid: package = 'season'
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				name_info = re.sub(r'\b4khdhub(?:\.com)?\b', '', name_info, flags=re.I)
				name_info = re.sub(r'\.{2,}', '.', name_info)
				language = source_utils.release_language(name_info)

				if use_direct:
					if not direct_url: continue
					url = direct_url
				else:
					if not info_hash: continue
					url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, name)

				seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				dsize = 0
				try:
					size_bytes = float(meta.get('size') or behavior.get('videoSize') or 0)
					if size_bytes > 0:
						size = f"{size_bytes / 1073741824:.2f} GB"
						dsize, isize = source_utils._size(size)
						info.insert(0, isize)
				except:
					dsize = 0
				info = ' | '.join(info)

				if use_direct:
					item = {
						'source': source_type or 'direct', 'language': language, 'direct': True, 'debridonly': False,
						'provider': 'custom_stremio1', 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders,
						'custom_stremio1_direct': True, 'debrid': 'custom_stremio1', 'provider_name': self.display_name,
						'bypass_filter': True, 'true_size': True
					}
				else:
					item = {
						'source': 'torrent', 'language': language, 'direct': False, 'debridonly': True,
						'provider': 'custom_stremio1', 'hash': info_hash, 'url': url, 'name': name, 'name_info': name_info,
						'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'provider_name': self.display_name,
						'bypass_filter': True, 'true_size': True
					}
				tracker = self.display_name or meta.get('indexer') or file.get('name') or file.get('tracker')
				if source_type == 'usenet' and not tracker: tracker = 'usenet'
				if tracker:
					item['tracker'] = tracker
				if package: item['package'] = package
				if package == 'show': item.update({'last_season': last_season})
				if episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('CUSTOM_STREMIO1')
		return sources
