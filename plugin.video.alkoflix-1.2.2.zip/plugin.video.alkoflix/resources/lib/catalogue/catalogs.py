# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/catalogue/catalogs.py

import json
import os
from urllib.parse import quote

import xbmcgui
from datetime import timedelta

from alko import client
from modules import kodi_utils as ku
from modules import settings as ks
from indexers import tmdb_api
from caches.main_cache import MainCache

# Catalogue public chargé automatiquement.
# Si l'utilisateur renseigne un manifest personnalisé dans les réglages,
# cette URL par défaut est remplacée par la sienne.
DEFAULT_CATALOGUE_MANIFEST_URL = 'https://addon-stremio-fs-public.vercel.app/eyJ0IjoiMTRlNDY5ZDgwZTJmZjkxYTA1MWY3NjlkYmQ5MzY3NTciLCJyIjpmYWxzZSwiYyI6WyJkZXJuaWVycy1maWxtcyIsImZpbG1zLWFjdGlvbiIsImRlcm5pZXJlcy1zZXJpZXMiLCJzZXJpZXMtbmV0ZmxpeCIsInNlcmllcy1hcHBsZXR2Iiwic2VyaWVzLXByaW1lIiwic2VyaWVzLWRpc25leXBsdXMiLCJkb2N1bWVudGFpcmVzIiwiaG9ycmV1ciIsImFuaW1hdGlvbnMiLCJhdmVudHVyZXMiLCJhcnQtbWFydGlhdXgiLCJiaW9waWNzIiwiY29tZWRpZXMiLCJlc3Bpb25uYWdlcyIsImZhbWlsbGVzIiwiZmFudGFzdGlxdWVzIiwicG9saWNpZXJzIiwidGhyaWxsZXJzIiwid2VzdGVybnMiLCJkcmFtZXMiLCJoaXN0b3JpcXVlcyIsImd1ZXJyZXMiLCJyb21hbmNlcyIsInNjaWVuY2UtZmljdGlvbnMiLCJzcGVjdGFjbGUiXSwidiI6ZmFsc2V9/manifest.json'
CATALOGUE_PAGE_SIZE = 20
LOCAL_MANIFEST = 'special://home/addons/plugin.video.alkoflix/resources/data/catalogues/french_stream_public.json'

build_url, make_listitem, add_item, add_items, add_dir = ku.build_url, ku.make_listitem, ku.add_item, ku.add_items, ku.add_dir
end_directory, set_content, set_category, set_view_mode = ku.end_directory, ku.set_content, ku.set_category, ku.set_view_mode
media_path, notification, logger = ku.media_path, ku.notification, ku.logger

CACHE_PREFIX = 'alkoflix_catalogue_'


def _cache_get(key):
	try: return MainCache().get(CACHE_PREFIX + key)
	except: return None


def _cache_set(key, data, hours=24):
	try: MainCache().set(CACHE_PREFIX + key, data, expiration=timedelta(hours=hours))
	except: pass
	return data


def _translate(path):
	try: return ku.translate_path(path)
	except: return path


def _read_json_file(path):
	try:
		with open(_translate(path), 'r', encoding='utf-8') as fh:
			return json.load(fh)
	except Exception as e:
		logger('catalogues local manifest error', e)
		return {}


def _json_request(url, cache_hours=6):
	# Les catalogues externes peuvent être lents. On garde une petite mise en cache
	# pour éviter de recharger le manifest et la même page à chaque ouverture de menu.
	cache_key = 'json_%s' % url
	cached = _cache_get(cache_key)
	if cached is not None: return cached
	try:
		result = client.request(url, headers={'Accept': 'application/json'}, timeout='20')
		data = json.loads(result) if result else {}
		return _cache_set(cache_key, data, hours=cache_hours)
	except Exception as e:
		logger('catalogues request error', e)
		return {}


def _manifest_url():
	# Vide = catalogue public par défaut.
	# Rempli = manifest personnalisé de l'utilisateur.
	try: custom_url = ku.get_setting('catalogue.custom.manifest_url', '')
	except: custom_url = ''
	if not custom_url:
		try: custom_url = ku.get_setting('catalogue.french_stream_public.manifest_url', '')
		except: custom_url = ''
	return (custom_url or DEFAULT_CATALOGUE_MANIFEST_URL).strip()


def _base_url(manifest_url=''):
	manifest_url = (manifest_url or _manifest_url()).strip()
	if not manifest_url: return ''
	if manifest_url.endswith('/manifest.json'): return manifest_url[:-14].rstrip('/')
	return manifest_url.rsplit('/', 1)[0].rstrip('/')




def _display_catalogue_name(name):
	# Nettoie uniquement l’affichage des entrées du menu Catalogue.
	# Les identifiants internes du manifest restent inchangés.
	name = str(name or '').strip()
	for prefix in ('FS - ', 'FS- ', 'FS – ', 'FS– '):
		if name.startswith(prefix):
			return name[len(prefix):].strip()
	return name


def _folder_icon():
	return media_path('folder.png')

def _manifest():
	remote = _manifest_url()
	if remote:
		data = _json_request(remote)
		if data: return data
	return _read_json_file(LOCAL_MANIFEST)


def _catalog_url(catalog_type, catalog_id, page_no=1, search=''):
	base = _base_url()
	if not base: return ''
	extra = []
	try:
		page_no = int(page_no)
	except: page_no = 1
	if page_no > 1: extra.append('skip=%s' % ((page_no - 1) * CATALOGUE_PAGE_SIZE))
	if search: extra.append('search=%s' % quote(search.encode('utf-8') if False else search, safe=''))
	if extra:
		return '%s/catalog/%s/%s/%s.json' % (base, catalog_type, catalog_id, '&'.join(extra))
	return '%s/catalog/%s/%s.json' % (base, catalog_type, catalog_id)


def _meta_url(item_type, item_id):
	base = _base_url()
	if not base: return ''
	return '%s/meta/%s/%s.json' % (base, item_type, quote(item_id, safe=':'))


def _safe_title(item):
	return item.get('name') or item.get('title') or item.get('id') or 'Sans titre'


def _year(item):
	try: return str(item.get('releaseInfo') or item.get('year') or '')[:4]
	except: return ''


def _catalogue_id_parts(item_id):
	item_id = str(item_id or '')
	if item_id.startswith('tmdb:'): return item_id.replace('tmdb:', '', 1), ''
	if item_id.startswith('tt'): return '', item_id
	return '', ''


def _custom_meta(item, media_type='movie'):
	title = _safe_title(item)
	year = _year(item)
	poster = item.get('poster') or item.get('posterShape') or ''
	fanart = item.get('background') or item.get('poster') or ks.addon_fanart()
	tmdb_id, imdb_id = _catalogue_id_parts(item.get('id'))
	meta = {
		'title': title,
		'rootname': '%s (%s)' % (title, year) if year else title,
		'original_title': title,
		'year': year or '0',
		'premiered': item.get('released') or '',
		'plot': item.get('description') or item.get('overview') or '',
		'genre': ', '.join(item.get('genres', [])) if isinstance(item.get('genres'), list) else item.get('genres', ''),
		'poster': poster,
		'fanart': fanart,
		'landscape': item.get('background') or poster,
		'banner': '',
		'clearart': '',
		'clearlogo': '',
		'tmdblogo': '',
		'discart': '',
		'imdb_id': imdb_id,
		'tmdb_id': tmdb_id or '0',
		'tvdb_id': '',
		'mediatype': media_type,
		'cast': [],
		'country': [],
		'director': '',
		'duration': 5400,
		'mpaa': '',
		'rating': item.get('imdbRating') or 0,
		'studio': '',
		'tagline': '',
		'trailer': '',
		'votes': '',
		'writer': '',
		'alternative_titles': [],
		'country_codes': [],
		'extra_info': {}
	}
	return meta




def _clean_search_title(title):
	# Nettoie seulement les préfixes d'affichage fréquents avant une recherche TMDb.
	# Le titre original reste transmis aux scrapers si aucun identifiant TMDb n'est trouvé.
	title = str(title or '').strip()
	for prefix in ('FS - ', 'FS- ', 'FS – ', 'FS– '):
		if title.startswith(prefix):
			title = title[len(prefix):].strip()
	return title


def _best_tmdb_match(results, title, year=''):
	if not results: return ''
	wanted = _clean_search_title(title).lower()
	year = str(year or '')[:4]
	first_id = ''
	for item in results:
		try:
			if not first_id and item.get('id'): first_id = str(item.get('id'))
			item_title = (item.get('title') or item.get('name') or item.get('original_title') or item.get('original_name') or '').lower()
			item_year = str(item.get('release_date') or item.get('first_air_date') or '')[:4]
			if item_title == wanted and (not year or item_year == year):
				return str(item.get('id'))
		except: pass
	return first_id


def _search_tmdb_id(item, media_type='movie'):
	# Les catalogues publics peuvent retourner des IDs internes (fs:...).
	# Dans ce cas, on tente de retrouver la fiche TMDb pour garder l'affichage uniforme avec alkoFlix.
	title = _clean_search_title(_safe_title(item))
	year = _year(item)
	if not title: return ''
	cache_key = 'tmdb_%s_%s_%s' % (media_type, title.lower(), year)
	cached = _cache_get(cache_key)
	if cached is not None: return cached
	try:
		query = quote(title.encode('utf-8') if False else title, safe='')
		if media_type == 'series': data = tmdb_api.tmdb_tv_search(query, 1) or {}
		else: data = tmdb_api.tmdb_movies_search(query, 1) or {}
		result = _best_tmdb_match(data.get('results', []), title, year)
		return _cache_set(cache_key, result, hours=168)
	except Exception as e:
		logger('catalogues tmdb search error', e)
		return ''


def _resolve_media_id(item, media_type='movie'):
	catalogue_id = item.get('id', '')
	tmdb_id, imdb_id = _catalogue_id_parts(catalogue_id)
	if item.get('tmdb_id') or item.get('tmdbId'):
		return 'tmdb_id', str(item.get('tmdb_id') or item.get('tmdbId'))
	if item.get('imdb_id') or item.get('imdbId'):
		return 'imdb_id', str(item.get('imdb_id') or item.get('imdbId'))
	if tmdb_id: return 'tmdb_id', tmdb_id
	if imdb_id: return 'imdb_id', imdb_id
	tmdb_id = _search_tmdb_id(item, media_type)
	if tmdb_id: return 'tmdb_id', tmdb_id
	return '', ''

def _item_art(item):
	poster = item.get('poster') or media_path('movies.png')
	fanart = item.get('background') or poster or ks.addon_fanart()
	return {'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart, 'landscape': item.get('background') or poster, 'banner': poster}


class Catalogues:
	def __init__(self, params):
		params['handle'] = int(__import__('sys').argv[1])
		self.params = params
		self.params_get = params.get
		self.handle = params['handle']
		self.fanart = ks.addon_fanart()

	def root(self):
		manifest = _manifest()
		catalogs = manifest.get('catalogs', [])
		if not catalogs:
			notification('Aucun catalogue disponible.', 3000)
		for cat in catalogs:
			# Les catalogues de recherche ne sont pas affichés ici : alkoFlix possède déjà
			# sa propre recherche native, plus complète et mieux intégrée à l'interface.
			if cat.get('id') == 'fs-search' or any(extra.get('name') == 'search' and extra.get('isRequired') for extra in cat.get('extra', [])):
				continue
			raw_name = cat.get('name') or cat.get('id')
			if not raw_name: continue
			name = _display_catalogue_name(raw_name)
			params = {'mode': 'catalogue.catalog', 'catalog_type': cat.get('type', 'movie'), 'catalog_id': cat.get('id'), 'name': name}
			icon = _folder_icon()
			add_dir(self.handle, params, name, icon, self.fanart, True)
		self._finish('Catalogue', content='')

	def catalog(self):
		catalog_type = self.params_get('catalog_type', 'movie')
		catalog_id = self.params_get('catalog_id', '')
		page_no = self.params_get('new_page', '1')
		search = self.params_get('search', '')
		content_type = 'tvshows' if catalog_type == 'series' else 'movies'
		view_type = 'view.tvshows' if catalog_type == 'series' else 'view.movies'
		if self.params_get('search_required') == 'true' and not search:
			keyboard = xbmcgui.Dialog().input('Recherche Catalogue')
			if not keyboard: return self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)
			search = keyboard
		url = _catalog_url(catalog_type, catalog_id, page_no, search)
		if not url:
			notification('URL du catalogue non configurée.', 4000)
			return self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)
		data = _json_request(url)
		items = data.get('metas') or data.get('items') or []
		if not items: notification('Aucun élément retourné par ce catalogue.', 3000)

		# Pagination locale uniforme avec les autres menus alkoFlix.
		# Certains catalogues retournent plus de 20 éléments même avec le paramètre skip ;
		# on limite donc toujours l'affichage à 20 items par page côté Kodi.
		visible_items = items[:CATALOGUE_PAGE_SIZE]
		for item in visible_items:
			self._add_catalogue_item(item, catalog_type)

		if len(items) >= CATALOGUE_PAGE_SIZE:
			next_params = dict(self.params)
			next_params.update({'mode': 'catalogue.catalog', 'new_page': str(int(page_no) + 1)})
			if search: next_params['search'] = search
			add_dir(self.handle, next_params, 'Page suivante', media_path('item_next.png'), self.fanart, True)
		self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)

	def meta(self):
		item_type = self.params_get('item_type', 'series')
		item_id = self.params_get('item_id', '')
		url = _meta_url(item_type, item_id)
		if not url:
			notification('URL du catalogue non configurée.', 4000)
			return self._finish(self.params_get('name', 'Catalogue'))
		data = _json_request(url).get('meta', {})
		videos = data.get('videos', [])
		if not videos:
			notification('Aucun épisode disponible dans cette fiche.', 3000)
		for video in videos:
			self._add_episode_item(data, video)
		self._finish(_safe_title(data), 'episodes', 'view.episodes')

	def _add_catalogue_item(self, item, catalog_type):
		# Priorité aux builders natifs d'alkoFlix pour obtenir les mêmes métadonnées,
		# menus contextuels, affiches, fanarts et types de média que les autres sections.
		media_type = 'series' if catalog_type == 'series' else 'movie'
		id_type, media_id = _resolve_media_id(item, media_type)
		if id_type and media_id:
			try:
				if media_type == 'series':
					from menus.tvshows import TVShows
					builder = TVShows({'id_type': id_type, 'list': [], 'action': 'catalogue_tvshows', 'exit_list_params': self.params_get('exit_list_params', '')})
					# Évite les affiches RPDB 404 sur les catalogues publics : TMDb reste la source d'art principale.
					builder.rpdb_enabled = False
					builder.build_tvshow_content(0, media_id)
				else:
					from menus.movies import Movies
					builder = Movies({'id_type': id_type, 'list': [], 'action': 'catalogue_movies', 'exit_list_params': self.params_get('exit_list_params', '')})
					# Évite les affiches RPDB 404 sur les catalogues publics : TMDb reste la source d'art principale.
					builder.rpdb_enabled = False
					builder.build_movie_content(0, media_id)
				if builder.items:
					add_items(self.handle, builder.items)
					return
			except Exception as e:
				logger('catalogues native builder error', e)
		# Fallback : garde l'ancien comportement si TMDb ne trouve rien.
		self._add_fallback_item(item, catalog_type)

	def _add_fallback_item(self, item, catalog_type):
		label = _safe_title(item)
		catalogue_id = item.get('id', '')
		listitem = make_listitem()
		listitem.setLabel(label)
		listitem.setArt(_item_art(item))
		if catalog_type == 'series':
			url = build_url({'mode': 'catalogue.meta', 'item_type': 'series', 'item_id': catalogue_id, 'name': label})
			is_folder = True
		else:
			meta = _custom_meta(item, 'movie')
			params = {'mode': 'play_media', 'media_type': 'movie', 'custom_title': label, 'custom_year': _year(item), 'meta': json.dumps(meta)}
			url = build_url(params)
			is_folder = False
		try:
			info = {'title': label, 'plot': item.get('description') or '', 'year': int(_year(item) or 0), 'mediatype': 'tvshow' if catalog_type == 'series' else 'movie'}
			listitem.setInfo('video', info)
		except: pass
		add_item(self.handle, url, listitem, is_folder)

	def _add_episode_item(self, show_meta, video):
		show_title = _safe_title(show_meta)
		season = str(video.get('season') or 1)
		episode = str(video.get('episode') or 1)
		ep_title = video.get('title') or 'S%sE%s' % (season, episode)
		label = 'S%sE%s - %s' % (season.zfill(2), episode.zfill(2), ep_title)
		meta = _custom_meta(show_meta, 'episode')
		meta.update({'mediatype': 'episode', 'season': int(season), 'episode': int(episode), 'ep_name': ep_title})
		params = {
			'mode': 'play_media', 'media_type': 'episode', 'tmdb_id': meta.get('tmdb_id') or '0',
			'season': season, 'episode': episode, 'custom_title': show_title, 'custom_season': season,
			'custom_episode': episode, 'meta': json.dumps(meta)
		}
		listitem = make_listitem()
		listitem.setLabel(label)
		listitem.setArt(_item_art(show_meta))
		try: listitem.setInfo('video', {'title': ep_title, 'tvshowtitle': show_title, 'season': int(season), 'episode': int(episode), 'plot': video.get('overview') or ''})
		except: pass
		add_item(self.handle, build_url(params), listitem, False)

	def _finish(self, name, content='videos', view_type='view.main'):
		set_category(self.handle, name)
		try: ku.set_sort_method(self.handle, content or '')
		except: pass
		set_content(self.handle, content or '')
		end_directory(self.handle)
		set_view_mode(view_type, content or '')
