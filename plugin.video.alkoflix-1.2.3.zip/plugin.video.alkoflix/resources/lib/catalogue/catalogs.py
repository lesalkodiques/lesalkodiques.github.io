# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/catalogue/catalogs.py

import json
import os
import re
from urllib.parse import quote

import xbmcgui
from datetime import timedelta

from alko import client
from modules import kodi_utils as ku
from modules import settings as ks
from indexers import tmdb_api
from caches.main_cache import MainCache

# Catalogue public chargé automatiquement.
# Si l'utilisateur renseigne un manifest personnalisé dans les réglages,
# cette URL par défaut est remplacée par la sienne.
DEFAULT_CATALOGUE_MANIFEST_URL = 'https://addon-stremio-fs-public.vercel.app/eyJ0IjoiMTRlNDY5ZDgwZTJmZjkxYTA1MWY3NjlkYmQ5MzY3NTciLCJyIjpmYWxzZSwiYyI6WyJkZXJuaWVycy1maWxtcyIsImZpbG1zLWFjdGlvbiIsImRlcm5pZXJlcy1zZXJpZXMiLCJzZXJpZXMtbmV0ZmxpeCIsInNlcmllcy1hcHBsZXR2Iiwic2VyaWVzLXByaW1lIiwic2VyaWVzLWRpc25leXBsdXMiLCJkb2N1bWVudGFpcmVzIiwiaG9ycmV1ciIsImFuaW1hdGlvbnMiLCJhdmVudHVyZXMiLCJhcnQtbWFydGlhdXgiLCJiaW9waWNzIiwiY29tZWRpZXMiLCJlc3Bpb25uYWdlcyIsImZhbWlsbGVzIiwiZmFudGFzdGlxdWVzIiwicG9saWNpZXJzIiwidGhyaWxsZXJzIiwid2VzdGVybnMiLCJkcmFtZXMiLCJoaXN0b3JpcXVlcyIsImd1ZXJyZXMiLCJyb21hbmNlcyIsInNjaWVuY2UtZmljdGlvbnMiLCJzcGVjdGFjbGUiXSwidiI6ZmFsc2V9/manifest.json'
CATALOGUE_PAGE_SIZE = 20
LOCAL_MANIFEST = 'special://home/addons/plugin.video.alkoflix/resources/data/catalogues/french_stream_public.json'

build_url, make_listitem, add_item, add_items, add_dir = ku.build_url, ku.make_listitem, ku.add_item, ku.add_items, ku.add_dir
end_directory, set_content, set_category, set_view_mode = ku.end_directory, ku.set_content, ku.set_category, ku.set_view_mode
media_path, notification, logger = ku.media_path, ku.notification, ku.logger

CACHE_PREFIX = 'alkoflix_catalogue_'


def _cache_get(key):
	try: return MainCache().get(CACHE_PREFIX + key)
	except: return None


def _cache_set(key, data, hours=24):
	try: MainCache().set(CACHE_PREFIX + key, data, expiration=timedelta(hours=hours))
	except: pass
	return data


def _translate(path):
	try: return ku.translate_path(path)
	except: return path


def _read_json_file(path):
	try:
		with open(_translate(path), 'r', encoding='utf-8') as fh:
			return json.load(fh)
	except Exception as e:
		logger('catalogues local manifest error', e)
		return {}


def _json_request(url, cache_hours=6):
	# Les catalogues externes peuvent être lents. On garde une petite mise en cache
	# pour éviter de recharger le manifest et la même page à chaque ouverture de menu.
	cache_key = 'json_%s' % url
	cached = _cache_get(cache_key)
	if cached is not None: return cached
	try:
		result = client.request(url, headers={'Accept': 'application/json'}, timeout='20')
		data = json.loads(result) if result else {}
		# Certains endpoints de catalogue peuvent répondre JSON null.
		# On normalise en dictionnaire vide pour éviter les .get() sur None.
		if data is None:
			data = {}
		return _cache_set(cache_key, data, hours=cache_hours)
	except Exception as e:
		logger('catalogues request error', e)
		return {}


def _manifest_url():
	# Vide = catalogue public par défaut.
	# Rempli = manifest personnalisé de l'utilisateur.
	try: custom_url = ku.get_setting('catalogue.custom.manifest_url', '')
	except: custom_url = ''
	if not custom_url:
		try: custom_url = ku.get_setting('catalogue.french_stream_public.manifest_url', '')
		except: custom_url = ''
	return (custom_url or DEFAULT_CATALOGUE_MANIFEST_URL).strip()


def _base_url(manifest_url=''):
	manifest_url = (manifest_url or _manifest_url()).strip()
	if not manifest_url: return ''
	if manifest_url.endswith('/manifest.json'): return manifest_url[:-14].rstrip('/')
	return manifest_url.rsplit('/', 1)[0].rstrip('/')




def _display_catalogue_name(name):
	# Nettoie uniquement l’affichage des entrées du menu Catalogue.
	# Les identifiants internes du manifest restent inchangés.
	name = str(name or '').strip()
	for prefix in ('FS - ', 'FS- ', 'FS – ', 'FS– '):
		if name.startswith(prefix):
			return name[len(prefix):].strip()
	return name



def _clean_catalogue_title_suffix(title):
	# Certains catalogues ajoutent une info de navigation à la fin du titre
	# (ex. "Saison" / "Saison 1"). Cette info ne fait pas partie du vrai
	# titre TMDb/IMDb et peut empêcher la résolution exacte avant le scrape.
	title = str(title or '').strip()
	if not title: return title
	patterns = (
		r'\s*[-–—:]\s*saison\s*\d*\s*$',
		r'\s+saison\s*\d*\s*$',
		r'\s*\(\s*saison\s*\d*\s*\)\s*$',
		r'\s+season\s*\d*\s*$',
		r'\s*\(\s*season\s*\d*\s*\)\s*$',
	)
	for pattern in patterns:
		title = re.sub(pattern, '', title, flags=re.I).strip()
	return title

def _folder_icon():
	return media_path('folder.png')



def _catalogue_folder_context(name, icon_name='folder.png'):
	# Aligne les dossiers du Catalogue avec les autres menus d'alkoFlix :
	# ajout au menu principal + ajout dans un dossier de raccourcis.
	# Le menu d'édition complet (Modifier le menu / Parcourir les éléments retirés)
	# reste géré par le menu principal une fois l'élément ajouté.
	try:
		add_menu_str = ku.local_string(32730)
		shortcut_folder_str = ku.local_string(32731)
	except:
		add_menu_str, shortcut_folder_str = 'Ajouter au menu', 'Ajouter à un dossier de raccourcis'
	name = str(name or '').strip()
	icon_name = str(icon_name or 'folder.png')
	return [
		(add_menu_str, 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.add_external', 'name': name, 'iconImage': icon_name})),
		(shortcut_folder_str, 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_item', 'name': name, 'iconImage': icon_name}))
	]


def _add_catalogue_dir(handle, params, name, icon_name='folder.png', fanart=None, is_folder=True):
	# Variante locale de add_dir(), avec les context menus attendus sur les dossiers.
	params = dict(params or {})
	params.setdefault('name', name)
	params.setdefault('iconImage', icon_name)
	icon = media_path(icon_name) if icon_name and '://' not in icon_name else icon_name
	url = build_url(params)
	listitem = make_listitem()
	listitem.setLabel(name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart or ks.addon_fanart(), 'banner': icon, 'landscape': icon})
	try: listitem.addContextMenuItems(_catalogue_folder_context(name, icon_name))
	except: pass
	add_item(handle, url, listitem, is_folder)

def _manifest():
	remote = _manifest_url()
	if remote:
		data = _json_request(remote)
		if data: return data
	return _read_json_file(LOCAL_MANIFEST)


def _catalog_url(catalog_type, catalog_id, page_no=1, search=''):
	base = _base_url()
	if not base: return ''
	extra = []
	try:
		page_no = int(page_no)
	except: page_no = 1
	if page_no > 1: extra.append('skip=%s' % ((page_no - 1) * CATALOGUE_PAGE_SIZE))
	if search: extra.append('search=%s' % quote(search.encode('utf-8') if False else search, safe=''))
	if extra:
		return '%s/catalog/%s/%s/%s.json' % (base, catalog_type, catalog_id, '&'.join(extra))
	return '%s/catalog/%s/%s.json' % (base, catalog_type, catalog_id)


def _meta_url(item_type, item_id):
	base = _base_url()
	if not base: return ''
	return '%s/meta/%s/%s.json' % (base, item_type, quote(item_id, safe=':'))


def _safe_title(item):
	raw_title = item.get('name') or item.get('title') or item.get('id') or 'Sans titre'
	return _clean_catalogue_title_suffix(raw_title)


def _year(item):
	try: return str(item.get('releaseInfo') or item.get('year') or '')[:4]
	except: return ''


def _catalogue_id_parts(item_id):
	item_id = str(item_id or '')
	if item_id.startswith('tmdb:'):
		return item_id.replace('tmdb:', '', 1).split(':')[0], ''
	# Certains catalogues retournent des identifiants enrichis du type
	# tt1234567:1:2 ou fs:... avec l'IMDb inclus ailleurs dans la chaîne.
	# Pour le scrape, on conserve uniquement l'identifiant IMDb pur.
	match = re.search(r'(tt\d+)', item_id)
	if match: return '', match.group(1)
	return '', ''


def _custom_meta(item, media_type='movie'):
	title = _safe_title(item)
	year = _year(item)
	poster = item.get('poster') or item.get('posterShape') or ''
	fanart = item.get('background') or item.get('poster') or ks.addon_fanart()
	tmdb_id, imdb_id = _catalogue_id_parts(item.get('id'))
	meta = {
		'title': title,
		'rootname': '%s (%s)' % (title, year) if year else title,
		'original_title': title,
		'year': year or '0',
		'premiered': item.get('released') or '',
		'plot': item.get('description') or item.get('overview') or '',
		'genre': ', '.join(item.get('genres', [])) if isinstance(item.get('genres'), list) else item.get('genres', ''),
		'poster': poster,
		'fanart': fanart,
		'landscape': item.get('background') or poster,
		'banner': '',
		'clearart': '',
		'clearlogo': '',
		'tmdblogo': '',
		'discart': '',
		'imdb_id': imdb_id,
		'tmdb_id': tmdb_id or '0',
		'tvdb_id': '',
		'mediatype': media_type,
		'cast': [],
		'country': [],
		'director': '',
		'duration': 5400,
		'mpaa': '',
		'rating': item.get('imdbRating') or 0,
		'studio': '',
		'tagline': '',
		'trailer': '',
		'votes': '',
		'writer': '',
		'alternative_titles': [],
		'country_codes': [],
		'extra_info': {}
	}
	return meta




def _clean_search_title(title):
	# Nettoie seulement les préfixes d'affichage fréquents avant une recherche TMDb.
	# Le titre original reste transmis aux scrapers si aucun identifiant TMDb n'est trouvé.
	title = str(title or '').strip()
	for prefix in ('FS - ', 'FS- ', 'FS – ', 'FS– '):
		if title.startswith(prefix):
			title = title[len(prefix):].strip()
	return _clean_catalogue_title_suffix(title)


def _best_tmdb_match(results, title, year=''):
	if not results: return ''
	wanted = _clean_search_title(title).lower()
	year = str(year or '')[:4]
	first_id = ''
	for item in results:
		try:
			if not first_id and item.get('id'): first_id = str(item.get('id'))
			item_title = (item.get('title') or item.get('name') or item.get('original_title') or item.get('original_name') or '').lower()
			item_year = str(item.get('release_date') or item.get('first_air_date') or '')[:4]
			if item_title == wanted and (not year or item_year == year):
				return str(item.get('id'))
		except: pass
	return first_id


def _search_tmdb_id(item, media_type='movie'):
	# Les catalogues publics peuvent retourner des IDs internes (fs:...).
	# Dans ce cas, on tente de retrouver la fiche TMDb pour garder l'affichage uniforme avec alkoFlix.
	title = _clean_search_title(_safe_title(item))
	year = _year(item)
	if not title: return ''
	cache_key = 'tmdb_%s_%s_%s' % (media_type, title.lower(), year)
	cached = _cache_get(cache_key)
	if cached is not None: return cached
	try:
		query = quote(title.encode('utf-8') if False else title, safe='')
		if media_type == 'series': data = tmdb_api.tmdb_tv_search(query, 1) or {}
		else: data = tmdb_api.tmdb_movies_search(query, 1) or {}
		result = _best_tmdb_match(data.get('results', []), title, year)
		return _cache_set(cache_key, result, hours=168)
	except Exception as e:
		logger('catalogues tmdb search error', e)
		return ''


def _item_imdb_id(item):
	# IMDb est prioritaire pour le scrape, car les catalogues externes le fournissent
	# souvent directement et les scrapers externes le comprennent très bien.
	for key in ('imdb_id', 'imdbId', 'imdb', 'imdbID'):
		value = item.get(key)
		if value:
			match = re.search(r'(tt\d+)', str(value))
			if match: return match.group(1)
	_, imdb_id = _catalogue_id_parts(item.get('id', ''))
	return imdb_id


def _resolve_media_id(item, media_type='movie'):
	catalogue_id = item.get('id', '')
	tmdb_id, imdb_id = _catalogue_id_parts(catalogue_id)
	# Pour les catalogues, IMDb passe avant TMDb afin de transmettre aux scrapers
	# l'identifiant le plus précis possible. TMDb reste utilisé pour l'affichage.
	imdb_id = _item_imdb_id(item) or imdb_id
	if imdb_id: return 'imdb_id', imdb_id
	if item.get('imdb_id') or item.get('imdbId'):
		return 'imdb_id', str(item.get('imdb_id') or item.get('imdbId'))
	if item.get('tmdb_id') or item.get('tmdbId'):
		return 'tmdb_id', str(item.get('tmdb_id') or item.get('tmdbId'))
	if tmdb_id: return 'tmdb_id', tmdb_id
	tmdb_id = _search_tmdb_id(item, media_type)
	if tmdb_id: return 'tmdb_id', tmdb_id
	return '', ''

def _item_art(item):
	poster = item.get('poster') or media_path('movies.png')
	fanart = item.get('background') or poster or ks.addon_fanart()
	return {'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart, 'landscape': item.get('background') or poster, 'banner': poster}


def _valid_param(value):
	if value is None: return ''
	value = str(value).strip()
	if not value or value.lower() in ('none', 'null', 'false', '0'): return ''
	return value


def _append_param_to_url(url, key, value):
	value = _valid_param(value)
	if not value or ('%s=' % key) in str(url): return url
	separator = '&' if '?' in str(url) else '?'
	return '%s%s%s=%s' % (url, separator, key, quote(str(value), safe=':'))


def _append_catalogue_context_to_items(items, imdb_id='', catalogue_id=''):
	# Les items construits par les builders natifs gardent l'affichage TMDb,
	# mais les scrapeurs doivent aussi recevoir l'identifiant brut du catalogue.
	# Certains catalogues publics utilisent des IDs internes (fs:...) qui sont
	# nécessaires pour retrouver les liens, même quand TMDb affiche la bonne fiche.
	if not imdb_id and not catalogue_id: return items
	patched = []
	for item in items:
		try:
			url, listitem, is_folder = item[:3]
			url = _append_param_to_url(url, 'imdb_id', imdb_id)
			url = _append_param_to_url(url, 'catalogue_id', catalogue_id)
			patched.append((url, listitem, is_folder))
		except:
			patched.append(item)
	return patched


def _context_menu(media_type='movie', tmdb_id='', imdb_id='', tvdb_id='', title='', year='', catalogue_id='', is_widget=False):
	# Menu contextuel minimal utilisé seulement par les items Catalogue construits
	# en fallback. Quand le builder natif alkoFlix est disponible, son menu complet
	# reste prioritaire.
	cm = []
	tmdb_id = _valid_param(tmdb_id)
	imdb_id = _valid_param(imdb_id)
	tvdb_id = _valid_param(tvdb_id)
	title = str(title or '')
	media_type = 'tvshow' if media_type in ('series', 'tvshow') else media_type
	run_plugin = 'RunPlugin(%s)'
	container_update = 'Container.Update(%s)'
	try: cm_sort = ks.context_menu_sort()
	except: cm_sort = {'options': 10, 'extras': 20, 'trakt': 30, 'mdblist': 40, 'tmdblist': 50, 'favourites': 60, 'mark': 70, 'exit': 100}
	def _add(sort_key, label, command):
		try: priority = cm_sort.get(sort_key, 0)
		except: priority = 0
		if priority and command: cm.append((priority, label, command))

	if media_type == 'episode':
		if tmdb_id:
			_add('options', 'Options', run_plugin % build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'is_widget': is_widget}))
			_add('trakt', 'Gestion Trakt', run_plugin % build_url({'mode': 'trakt_manager_choice', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
			_add('mdblist', 'Gestion des listes MDBList', run_plugin % build_url({'mode': 'mdbl_manager_choice', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
			_add('tmdblist', 'Gestion des listes TMDb', run_plugin % build_url({'mode': 'tmdb_manager_choice', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
	elif media_type == 'tvshow':
		if tmdb_id:
			_add('options', 'Options', run_plugin % build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': is_widget}))
			_add('options', 'Bande annonce', run_plugin % build_url({'mode': 'play_trailer_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id}))
			_add('extras', 'Extras', run_plugin % build_url({'mode': 'extras_menu_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': is_widget}))
			_add('extras', 'Parcourir...', container_update % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))
			_add('trakt', 'Gestion Trakt', run_plugin % build_url({'mode': 'trakt_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
			_add('mdblist', 'Gestion des listes MDBList', run_plugin % build_url({'mode': 'mdbl_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
			_add('tmdblist', 'Gestion des listes TMDb', run_plugin % build_url({'mode': 'tmdb_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id}))
			_add('favourites', 'Favoris', run_plugin % build_url({'mode': 'favourites_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title}))
	else:
		play_params = {'mode': 'play_media', 'media_type': 'movie', 'custom_title': title, 'custom_year': year}
		if tmdb_id: play_params['tmdb_id'] = tmdb_id
		if imdb_id: play_params['imdb_id'] = imdb_id
		if catalogue_id: play_params['catalogue_id'] = catalogue_id
		_add('extras', 'Lire...', run_plugin % build_url(play_params))
		if tmdb_id:
			_add('options', 'Options', run_plugin % build_url({'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'is_widget': is_widget}))
			_add('options', 'Bande annonce', run_plugin % build_url({'mode': 'play_trailer_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id}))
			_add('extras', 'Extras', run_plugin % build_url({'mode': 'extras_menu_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'is_widget': is_widget}))
			_add('trakt', 'Gestion Trakt', run_plugin % build_url({'mode': 'trakt_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None'}))
			_add('mdblist', 'Gestion des listes MDBList', run_plugin % build_url({'mode': 'mdbl_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None'}))
			_add('tmdblist', 'Gestion des listes TMDb', run_plugin % build_url({'mode': 'tmdb_manager_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None'}))
			_add('favourites', 'Favoris', run_plugin % build_url({'mode': 'favourites_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'title': title}))
	try:
		cm.sort(key=lambda k: k[0])
		return [v for k, *v in cm if k]
	except:
		return []


class Catalogues:
	def __init__(self, params):
		params['handle'] = int(__import__('sys').argv[1])
		self.params = params
		self.params_get = params.get
		self.handle = params['handle']
		self.fanart = ks.addon_fanart()

	def root(self):
		manifest = _manifest()
		catalogs = manifest.get('catalogs', [])
		if not catalogs:
			notification('Aucun catalogue disponible.', 3000)
		for cat in catalogs:
			# Les catalogues de recherche ne sont pas affichés ici : alkoFlix possède déjà
			# sa propre recherche native, plus complète et mieux intégrée à l'interface.
			if cat.get('id') == 'fs-search' or any(extra.get('name') == 'search' and extra.get('isRequired') for extra in cat.get('extra', [])):
				continue
			raw_name = cat.get('name') or cat.get('id')
			if not raw_name: continue
			name = _display_catalogue_name(raw_name)
			params = {'mode': 'catalogue.catalog', 'catalog_type': cat.get('type', 'movie'), 'catalog_id': cat.get('id'), 'name': name, 'iconImage': 'folder.png'}
			_add_catalogue_dir(self.handle, params, name, 'folder.png', self.fanart, True)
		self._finish('Catalogue', content='')

	def catalog(self):
		catalog_type = self.params_get('catalog_type', 'movie')
		catalog_id = self.params_get('catalog_id', '')
		try:
			page_no = max(1, int(self.params_get('new_page', '1')))
		except:
			page_no = 1
		search = self.params_get('search', '')
		content_type = 'tvshows' if catalog_type == 'series' else 'movies'
		view_type = 'view.tvshows' if catalog_type == 'series' else 'view.movies'
		if self.params_get('search_required') == 'true' and not search:
			keyboard = xbmcgui.Dialog().input('Recherche Catalogue')
			if not keyboard: return self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)
			search = keyboard

		# Le serveur du catalogue ne respecte pas toujours le paramètre skip.
		# Pour éviter que « Page suivante » recharge la première page en boucle,
		# alkoFlix récupère la liste de base puis applique sa propre pagination locale.
		url = _catalog_url(catalog_type, catalog_id, 1, search)
		if not url:
			notification('URL du catalogue non configurée.', 4000)
			return self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)
		data = _json_request(url)
		items = data.get('metas') or data.get('items') or []
		if not items: notification('Aucun élément retourné par ce catalogue.', 3000)

		start = (page_no - 1) * CATALOGUE_PAGE_SIZE
		end = start + CATALOGUE_PAGE_SIZE
		visible_items = items[start:end]
		for item in visible_items:
			self._add_catalogue_item(item, catalog_type)

		if len(items) > end:
			next_params = dict(self.params)
			next_params.pop('handle', None)
			next_params.update({'mode': 'catalogue.catalog', 'new_page': str(page_no + 1)})
			if search: next_params['search'] = search
			next_params.setdefault('iconImage', 'item_next.png')
			_add_catalogue_dir(self.handle, next_params, 'Page suivante', 'item_next.png', self.fanart, True)
		self._finish(self.params_get('name', 'Catalogue'), content_type, view_type)

	def meta(self):
		item_type = self.params_get('item_type', 'series')
		item_id = self.params_get('item_id', '')
		url = _meta_url(item_type, item_id)
		if not url:
			notification('URL du catalogue non configurée.', 4000)
			return self._finish(self.params_get('name', 'Catalogue'))
		response = _json_request(url) or {}
		data = response.get('meta') or {}
		if not isinstance(data, dict):
			data = {}
		# Fallback minimal : si le serveur retourne null pour une fiche, on garde
		# au moins un affichage propre et on évite de casser la navigation Kodi.
		if not data:
			data = {'id': item_id, 'name': _clean_catalogue_title_suffix(self.params_get('name', 'Catalogue'))}
		videos = data.get('videos') or []
		if not isinstance(videos, list):
			videos = []
		if not videos:
			notification('Aucun épisode disponible dans cette fiche.', 3000)
		for video in videos:
			if isinstance(video, dict):
				self._add_episode_item(data, video)
		self._finish(_safe_title(data), 'episodes', 'view.episodes')

	def _add_catalogue_item(self, item, catalog_type):
		# Priorité aux builders natifs d'alkoFlix pour obtenir les mêmes métadonnées,
		# menus contextuels, affiches, fanarts et types de média que les autres sections.
		media_type = 'series' if catalog_type == 'series' else 'movie'
		id_type, media_id = _resolve_media_id(item, media_type)
		catalogue_id = item.get('id', '')
		imdb_for_scrape = _item_imdb_id(item) or (media_id if id_type == 'imdb_id' else '')
		if id_type and media_id:
			try:
				if media_type == 'series':
					from menus.tvshows import TVShows
					builder = TVShows({'id_type': id_type, 'list': [], 'action': 'catalogue_tvshows', 'exit_list_params': self.params_get('exit_list_params', '')})
					# Évite les affiches RPDB 404 sur les catalogues publics : TMDb reste la source d'art principale.
					builder.rpdb_enabled = False
					builder.build_tvshow_content(0, media_id)
				else:
					from menus.movies import Movies
					builder = Movies({'id_type': id_type, 'list': [], 'action': 'catalogue_movies', 'exit_list_params': self.params_get('exit_list_params', '')})
					# Évite les affiches RPDB 404 sur les catalogues publics : TMDb reste la source d'art principale.
					builder.rpdb_enabled = False
					builder.build_movie_content(0, media_id)
				if builder.items:
					add_items(self.handle, _append_catalogue_context_to_items(builder.items, imdb_for_scrape, catalogue_id))
					return
			except Exception as e:
				logger('catalogues native builder error', e)
		# Fallback : garde l'ancien comportement si TMDb ne trouve rien.
		self._add_fallback_item(item, catalog_type)

	def _add_fallback_item(self, item, catalog_type):
		label = _safe_title(item)
		catalogue_id = item.get('id', '')
		listitem = make_listitem()
		listitem.setLabel(label)
		listitem.setArt(_item_art(item))
		year = _year(item)
		id_type, media_id = _resolve_media_id(item, 'series' if catalog_type == 'series' else 'movie')
		tmdb_id = media_id if id_type == 'tmdb_id' else ''
		imdb_id = _item_imdb_id(item) or (media_id if id_type == 'imdb_id' else '')
		if catalog_type == 'series':
			url = build_url({'mode': 'catalogue.meta', 'item_type': 'series', 'item_id': catalogue_id, 'name': label})
			is_folder = True
			cm = _context_menu('tvshow', tmdb_id=tmdb_id, imdb_id=imdb_id, title=label, year=year, catalogue_id=catalogue_id)
		else:
			meta = _custom_meta(item, 'movie')
			if tmdb_id and (not meta.get('tmdb_id') or meta.get('tmdb_id') == '0'):
				meta['tmdb_id'] = tmdb_id
			if imdb_id and not meta.get('imdb_id'):
				meta['imdb_id'] = imdb_id
			params = {'mode': 'play_media', 'media_type': 'movie', 'custom_title': label, 'custom_year': year, 'meta': json.dumps(meta)}
			if imdb_id: params['imdb_id'] = imdb_id
			if catalogue_id: params['catalogue_id'] = catalogue_id
			if tmdb_id: params['tmdb_id'] = tmdb_id
			elif meta.get('tmdb_id') and meta.get('tmdb_id') != '0': params['tmdb_id'] = meta.get('tmdb_id')
			url = build_url(params)
			is_folder = False
			cm = _context_menu('movie', tmdb_id=tmdb_id or meta.get('tmdb_id'), imdb_id=imdb_id, title=label, year=year, catalogue_id=catalogue_id)
			try: listitem.setProperty('IsPlayable', 'true')
			except: pass
		try:
			if cm: listitem.addContextMenuItems(cm)
		except: pass
		try:
			info = {'title': label, 'plot': item.get('description') or '', 'year': int(year or 0), 'mediatype': 'tvshow' if catalog_type == 'series' else 'movie'}
			listitem.setInfo('video', info)
		except: pass
		add_item(self.handle, url, listitem, is_folder)

	def _add_episode_item(self, show_meta, video):
		show_title = _safe_title(show_meta)
		season = str(video.get('season') or 1)
		episode = str(video.get('episode') or 1)
		ep_title = video.get('title') or 'S%sE%s' % (season, episode)
		label = 'S%sE%s - %s' % (season.zfill(2), episode.zfill(2), ep_title)
		meta = _custom_meta(show_meta, 'episode')
		meta.update({'mediatype': 'episode', 'season': int(season), 'episode': int(episode), 'ep_name': ep_title})
		params = {
			'mode': 'play_media', 'media_type': 'episode', 'tmdb_id': meta.get('tmdb_id') or '0',
			'season': season, 'episode': episode, 'custom_title': show_title, 'custom_season': season,
			'custom_episode': episode, 'meta': json.dumps(meta)
		}
		if meta.get('imdb_id'): params['imdb_id'] = meta.get('imdb_id')
		if show_meta.get('id'): params['catalogue_id'] = show_meta.get('id')
		listitem = make_listitem()
		listitem.setLabel(label)
		listitem.setArt(_item_art(show_meta))
		try: listitem.setProperty('IsPlayable', 'true')
		except: pass
		try:
			cm = _context_menu('episode', tmdb_id=meta.get('tmdb_id'), imdb_id=meta.get('imdb_id'), tvdb_id=meta.get('tvdb_id'), title=show_title, catalogue_id=show_meta.get('id'))
			if cm: listitem.addContextMenuItems(cm)
		except: pass
		try: listitem.setInfo('video', {'title': ep_title, 'tvshowtitle': show_title, 'season': int(season), 'episode': int(episode), 'plot': video.get('overview') or ''})
		except: pass
		add_item(self.handle, build_url(params), listitem, False)

	def _finish(self, name, content='videos', view_type='view.main'):
		set_category(self.handle, name)
		try: ku.set_sort_method(self.handle, content or '')
		except: pass
		set_content(self.handle, content or '')
		end_directory(self.handle)
		set_view_mode(view_type, content or '')
