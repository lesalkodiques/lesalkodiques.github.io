# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/torr9.py

from modules.private_torznab import PrivateTorznabSource


class source(PrivateTorznabSource):
	provider_key = 'torr9'
	provider_name = 'Torr9'
	api_setting = 'private.torr9.api_key'
	base_url = 'https://api.torr9.net/api/v1/torznab'
	response_mode = 'xml'
	priority = 3
