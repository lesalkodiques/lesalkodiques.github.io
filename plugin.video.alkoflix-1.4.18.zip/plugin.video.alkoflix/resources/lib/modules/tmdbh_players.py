# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/tmdbh_players.py

from modules.kodi_utils import dialog, path_exists, make_directorys, copy_file, notification, ok_dialog, confirm_dialog
import os
import xbmc
import xbmcvfs

SOURCE_DIR = 'special://home/addons/plugin.video.alkoflix/resources/players/json/'
START_DIR = 'special://profile/addon_data/'
PLAYERS_DIR = 'players'
PLAYER_FILES = (
	'alkoflix.autoplay.json',
	'alkoflix.options.json',
	'alkoflix.select.json',
)

def _clean_path(path):
	# Normalise le chemin sans convertir les chemins special://, afin de conserver la compatibilité entre les systèmes.
	if not path: return ''
	path = path.replace('\\', '/')
	return path if path.endswith('/') else '%s/' % path

def _join_path(base, name):
	return '%s%s' % (_clean_path(base), name)

def _translate_path(path):
	# Convertit les chemins special:// en vrais chemins locaux quand Kodi l'exige pour la création de dossier.
	try: return xbmcvfs.translatePath(path)
	except Exception:
		try: return xbmc.translatePath(path)
		except Exception: return path

def _ensure_directory(path):
	# xbmcvfs.mkdirs peut parfois refuser de créer un sous-dossier special:// sur Android.
	# On tente d'abord la méthode Kodi, puis un fallback os.makedirs sur le chemin traduit.
	path = _clean_path(path)
	if path_exists(path): return True
	try: make_directorys(path)
	except Exception: pass
	if path_exists(path): return True
	try:
		local_path = _translate_path(path)
		if local_path:
			os.makedirs(local_path, exist_ok=True)
	except Exception: pass
	return path_exists(path) or os.path.isdir(_translate_path(path))

def _is_players_folder(path):
	# Évite de créer un chemin players/players si l'utilisateur sélectionne directement le dossier players.
	path = _clean_path(path).rstrip('/')
	return path.split('/')[-1].lower() == PLAYERS_DIR

def _target_players_dir(destination):
	# La sélection se fait normalement sur le dossier addon_data de TMDb Helper.
	# Les fichiers doivent ensuite être copiés dans son sous-dossier players.
	return _clean_path(destination) if _is_players_folder(destination) else _clean_path(_join_path(destination, PLAYERS_DIR))

def _json_files(path):
	# Retourne uniquement les players alkoFlix attendus et présents dans le dossier source.
	try:
		_, files = xbmcvfs.listdir(_clean_path(path))
	except Exception:
		return []
	available = set(item for item in files if item.lower().endswith('.json'))
	return [filename for filename in PLAYER_FILES if filename in available]

def _copy_file(source, target):
	# Copie standard Kodi, avec fallback manuel pour certains environnements Android capricieux.
	try:
		if copy_file(source, target): return True
	except Exception: pass
	try:
		reader = xbmcvfs.File(source, 'rb')
		try: data = reader.readBytes()
		finally: reader.close()
		writer = xbmcvfs.File(target, 'wb')
		try: writer.write(data)
		finally: writer.close()
		return path_exists(target)
	except Exception:
		return False

def _copy_players(destination, files):
	copied, failed = [], []
	for filename in files:
		source = _join_path(SOURCE_DIR, filename)
		target = _join_path(destination, filename)
		if _copy_file(source, target): copied.append(filename)
		else: failed.append(filename)
	return copied, failed

def install_players():
	# Ouvre l'arborescence userdata/addon_data pour laisser l'utilisateur choisir le dossier de destination.
	# Le dossier de destination n'est pas codé en dur afin de rester compatible si l'addon TMDb Helper change d'identifiant.
	source = _clean_path(SOURCE_DIR)
	start = _clean_path(START_DIR)

	if not path_exists(source):
		ok_dialog(text='Le dossier des players TMDbH est introuvable dans alkoFlix.[CR][CR]Chemin attendu :[CR]%s' % source)
		return

	files = _json_files(source)
	if not files:
		ok_dialog(text='Aucun fichier JSON de player TMDbH n’a été trouvé dans :[CR]%s' % source)
		return

	_ensure_directory(start)

	destination = dialog.browseSingle(0, 'Sélectionner le dossier de destination', 'files', '', False, True, start)
	destination = _clean_path(destination)
	if not destination:
		return

	if not path_exists(destination):
		ok_dialog(text='Le dossier sélectionné est introuvable :[CR]%s' % destination)
		return

	players_destination = _target_players_dir(destination)
	if not _ensure_directory(players_destination):
		ok_dialog(text='Le dossier players n’a pas pu être créé dans :[CR]%s[CR][CR]Chemin tenté :[CR]%s' % (destination, players_destination))
		return

	existing = [filename for filename in files if path_exists(_join_path(players_destination, filename))]
	if existing:
		text = 'Un ou plusieurs players alkoFlix existent déjà dans le dossier players sélectionné.[CR][CR]Voulez-vous les remplacer ?'
		if not confirm_dialog(text=text, ok_label='Remplacer', cancel_label='Annuler', top_space=True):
			return

	copied, failed = _copy_players(players_destination, files)
	if copied and not failed:
		notification('%d player(s) TMDbH copié(s)' % len(copied), 3000)
		return

	if copied and failed:
		ok_dialog(text='%d player(s) copié(s), mais %d fichier(s) n’ont pas pu être copiés.' % (len(copied), len(failed)))
		return

	ok_dialog(text='Les players TMDbH n’ont pas pu être copiés dans le dossier sélectionné.')
