# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/list_sorting.py
# © Les alKODIques

import random
from indexers.metadata import movie_meta, tvshow_meta
from modules import kodi_utils, settings
from modules.utils import get_datetime, sort_for_article


def _metadata_user_info():
	# Le tri de listes a seulement besoin des métadonnées textuelles.
	# On évite donc d'appeler Fanart.tv pendant ce pré-traitement.
	try:
		user_info = dict(settings.metadata_user_info())
		user_info['extra_fanart_enabled'] = False
		return user_info
	except:
		return settings.metadata_user_info()


def _ids_from_trakt_item(item):
	media_type = item.get('type')
	if media_type == 'movie': return 'movie', (item.get('movie') or {}).get('ids') or {}
	if media_type in ('show', 'season', 'episode'):
		show = item.get('show') or {}
		if not show and media_type in item:
			show = (item.get(media_type) or {}).get('show') or {}
		return 'tvshow', show.get('ids') or {}
	return None, {}


def _ids_from_mdbl_item(item):
	media_type = 'movie' if item.get('mediatype') == 'movie' else 'tvshow' if item.get('mediatype') == 'show' else None
	return media_type, {'tmdb': item.get('id') or item.get('tmdb') or item.get('tmdb_id'), 'imdb': item.get('imdb_id') or item.get('imdb')}


def _meta_for_item(service, item, user_info, current_date):
	try:
		media_type, ids = _ids_from_trakt_item(item) if service == 'trakt' else _ids_from_mdbl_item(item)
		if not media_type or not ids: return {}
		meta = movie_meta('trakt_dict', ids, user_info, current_date) if media_type == 'movie' else tvshow_meta('trakt_dict', ids, user_info, current_date)
		meta = dict(meta or {})
		meta['_alkoflix_list_media_type'] = media_type
		return meta
	except Exception as exc:
		try: kodi_utils.logger('list sort metadata skipped', '%s: %s' % (type(exc).__name__, exc))
		except: pass
		return {}


def _nested_item(item):
	for key in ('movie', 'show', 'season', 'episode'):
		value = item.get(key)
		if isinstance(value, dict): return value
	return {}


def _first_text(*values):
	for value in values:
		if value not in ('', None): return str(value)
	return ''


def _fallback_title_value(item):
	nested = _nested_item(item)
	return _first_text(
		item.get('title'), item.get('name'), item.get('original_title'), item.get('original_name'),
		nested.get('title'), nested.get('name'), nested.get('original_title'), nested.get('original_name')
	).lower()


def _title_value(meta, item):
	return _first_text(meta.get('title'), meta.get('rootname'), meta.get('originaltitle'), meta.get('original_title'), _fallback_title_value(item)).lower()


def _fallback_date_value(item):
	nested = _nested_item(item)
	return _first_text(
		item.get('released'), item.get('first_aired'), item.get('release_date'), item.get('air_date'), item.get('year'), item.get('release_year'),
		nested.get('released'), nested.get('first_aired'), nested.get('release_date'), nested.get('air_date'), nested.get('year')
	)


def _date_value(meta, item):
	return _first_text(meta.get('premiered'), meta.get('aired'), meta.get('release_date'), _fallback_date_value(item))


def _float_value(*values):
	for value in values:
		try:
			if value not in ('', None): return float(str(value).replace(',', '.'))
		except: pass
	return 0.0


def _int_value(*values):
	for value in values:
		try:
			if value not in ('', None): return int(float(str(value).replace(',', '').replace(' ', '')))
		except: pass
	return 0


def _rating_value(meta, item):
	nested = _nested_item(item)
	return _float_value(
		meta.get('rating'), meta.get('vote_average'), item.get('rating'), item.get('score'), item.get('imdb_rating'),
		item.get('tmdb_rating'), nested.get('rating'), nested.get('score')
	)


def _votes_value(meta, item):
	nested = _nested_item(item)
	return _int_value(meta.get('votes'), meta.get('vote_count'), item.get('votes'), item.get('vote_count'), nested.get('votes'), nested.get('vote_count'))


def apply_context_list_sort(results, service, params):
	# Les listes Trakt/MDBList sont des listes utilisateurs thématiques.
	# On trie donc les éléments présents dans la liste, sans filtrage régional,
	# sans seuil de votes et sans obligation de visuel.
	list_sort = str((params or {}).get('list_sort') or '').strip().lower()
	if not list_sort or list_sort == 'original': return results
	user_info, current_date = _metadata_user_info(), get_datetime()
	enriched = []
	for index, item in enumerate(results or [], 1):
		try:
			meta = _meta_for_item(service, item, user_info, current_date)
		except:
			meta = {}
		try:
			item['_alkoflix_list_sort_index'] = index
			item['_alkoflix_list_sort_title'] = _title_value(meta, item)
			item['_alkoflix_list_sort_date'] = _date_value(meta, item)
			item['_alkoflix_list_sort_rating'] = _rating_value(meta, item)
			item['_alkoflix_list_sort_votes'] = _votes_value(meta, item)
		except:
			item['_alkoflix_list_sort_index'] = index
			item['_alkoflix_list_sort_title'] = _fallback_title_value(item)
			item['_alkoflix_list_sort_date'] = _fallback_date_value(item)
			item['_alkoflix_list_sort_rating'] = 0
			item['_alkoflix_list_sort_votes'] = 0
		enriched.append(item)
	if list_sort == 'date':
		enriched.sort(key=lambda k: (k.get('_alkoflix_list_sort_date') or '', k.get('_alkoflix_list_sort_title') or ''), reverse=True)
	elif list_sort == 'rated':
		enriched.sort(key=lambda k: (k.get('_alkoflix_list_sort_rating') or 0, k.get('_alkoflix_list_sort_votes') or 0, k.get('_alkoflix_list_sort_title') or ''), reverse=True)
	elif list_sort == 'random':
		seed = str((params or {}).get('list_random_seed') or '')
		if seed:
			random.Random(seed).shuffle(enriched)
		else:
			random.shuffle(enriched)
	elif list_sort == 'title':
		enriched = sort_for_article(enriched, '_alkoflix_list_sort_title', settings.ignore_articles())
	return enriched
