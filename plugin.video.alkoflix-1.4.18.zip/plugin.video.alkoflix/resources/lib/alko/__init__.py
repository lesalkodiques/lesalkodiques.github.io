# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/alko/__init__.py
"""Outils sources alkoFlix."""
