# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/alko/cache.py

"""Petit cache de compatibilité pour les anciens modules `alko`.

Certains modules hérités, dont `alko.client`, appellent encore `alko.cache.get(...)`.
Le cache principal moderne vit maintenant dans `resources/lib/caches`, mais ce shim
garde l'ancienne interface afin que les fenêtres d'autorisation et les appels réseau
puissent fonctionner sur une installation neuve.
"""

from datetime import timedelta
from hashlib import md5


def _cache_key(function, args):
	name = '%s.%s' % (
		getattr(function, '__module__', ''),
		getattr(function, '__name__', repr(function))
	)
	raw = repr((name, args))
	try:
		digest = md5(raw.encode('utf-8')).hexdigest()
	except Exception:
		digest = md5(str(raw).encode('utf-8', 'ignore')).hexdigest()
	return 'alkoflix_alko_cache_%s' % digest


def get(function, duration=24, *args):
	"""Retourne une valeur en cache ou exécute la fonction fournie.

	`duration` est exprimé en heures, comme dans l'ancien module utilisé par
	`alko.client`.
	"""
	try:
		cache_id = _cache_key(function, args)
		from caches.main_cache import MainCache
		maincache = MainCache()
		cached = maincache.get(cache_id)
		if cached is not None:
			return cached
		result = function(*args)
		try:
			expiration = timedelta(hours=int(duration))
		except Exception:
			expiration = timedelta(hours=24)
		maincache.set(cache_id, result, expiration=expiration)
		return result
	except Exception:
		try:
			return function(*args)
		except Exception:
			return None
