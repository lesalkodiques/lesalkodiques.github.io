import sys
from caches.navigator_cache import navigator_cache as nc
from modules import kodi_utils as ku, settings as ks
# logger = ku.logger

media_path, ls, build_url, notification, list_dirs = ku.media_path, ku.local_string, ku.build_url, ku.notification, ku.list_dirs
make_listitem, add_item, add_dir, end_directory, add_items = ku.make_listitem, ku.add_item, ku.add_dir, ku.end_directory, ku.add_items
set_content, set_view_mode, set_sort_method, set_category = ku.set_content, ku.set_view_mode, ku.set_sort_method, ku.set_category
_in_str, mov_str, tv_str, edit_str = ls(32484), ls(32028), ls(32029), ls(32705)
browse_str, add_menu_str, s_folder_str = ls(32706), ls(32730), ls(32731)

class Navigator:
	def __init__(self, params):
		params['handle'] = int(sys.argv[1])
		params['fanart'] = ks.addon_fanart()
		self.params = params
		self.params_get = self.params.get
		self.list_name = self.params_get('action', 'RootList')

	def downloads(self):
		dl_str, pr_str, im_str = ls(32107), ls(32485), ls(32798)
		mov_path, ep_path = ks.download_directory('movie'), ks.download_directory('episode')
		prem_path, im_path = ks.download_directory('premium'), ks.download_directory('image')
		n_ins = _in_str % (dl_str.upper(), '')
		self._add_item({'mode': 'navigator.folder_navigator', 'folder_path': mov_path , 'name': mov_str}, 'movies.png' , n_ins)
		self._add_item({'mode': 'navigator.folder_navigator', 'folder_path': ep_path  , 'name': tv_str }, 'tv.png'     , n_ins)
		self._add_item({'mode': 'navigator.folder_navigator', 'folder_path': prem_path, 'name': pr_str }, 'premium.png', n_ins)
		self._add_item({'mode': 'browser_image', 'folder_path': im_path, 'name': im_str }, 'people.png' , n_ins, False)
		self._end_directory()

	def discover_main(self):
		discover_str, his_str, help_str = ls(32451), ls(32486), ls(32487)
		movh_str, tvh_str = '%s %s' % (mov_str, his_str), '%s %s' % (tv_str, his_str)
		n_ins = _in_str % (discover_str.upper(), '')
		self._add_item({'mode': 'discover.movie', 'media_type': 'movie',    'name': mov_str }, 'discover.png', n_ins)
		self._add_item({'mode': 'discover.tvshow', 'media_type': 'tvshow',  'name': tv_str  }, 'discover.png', n_ins)
		self._add_item({'mode': 'discover.history', 'media_type': 'movie',  'name': movh_str}, 'discover.png', n_ins)
		self._add_item({'mode': 'discover.history', 'media_type': 'tvshow', 'name': tvh_str }, 'discover.png', n_ins)
		self._add_item({'mode': 'discover.help', 'name': help_str}, 'discover.png', n_ins, False)
		self._end_directory()

	def premium(self):
		from modules.debrid import debrid_enabled
		easynews, debrids = ks.easynews_active(), debrid_enabled()
		if easynews: self.easynews()
		if 'real-debrid' in debrids: self.real_debrid()
		if 'premiumize.me' in debrids: self.premiumize()
		if 'alldebrid' in debrids: self.alldebrid()
		if 'torbox' in debrids: self.torbox()
		if 'offcloud' in debrids: self.offcloud()
		if 'easydebrid' in debrids: self.easydebrid()
		self._end_directory()

	def easynews(self):
		easy_str, se_str, acc_str = ls(32070), ls(32450), ls(32494)
		n_ins = _in_str % (easy_str.upper(), '')
		self._add_item({'mode': 'search_history', 'action': 'easynews_video', 'name': se_str }, 'search.png'  , n_ins)
		self._add_item({'mode': 'easynews.account_info', 'name': acc_str}, 'easynews.png', n_ins, False)

	def real_debrid(self):
		rd_str, acc_str, his_str, cloud_str = ls(32054), ls(32494), ls(32486), ls(32496)
		clca_str, n_ins = ls(32497) % rd_str, _in_str % (rd_str.upper(), '')
		self._add_item({'mode': 'real_debrid.rd_torrent_cloud',     'name': cloud_str}, 'realdebrid.png', n_ins)
		self._add_item({'mode': 'real_debrid.show_account_info',    'name': acc_str  }, 'realdebrid.png', n_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'rd_cloud', 'name': clca_str }, 'realdebrid.png', n_ins, False)

	def premiumize(self):
		pm_str, acc_str, his_str, cloud_str = ls(32061), ls(32494), ls(32486), ls(32496)
		clca_str, n_ins = ls(32497) % pm_str, _in_str % (pm_str.upper(), '')
		self._add_item({'mode': 'premiumize.pm_torrent_cloud',      'name': cloud_str}, 'premiumize.png', n_ins)
		self._add_item({'mode': 'premiumize.show_account_info',     'name': acc_str  }, 'premiumize.png', n_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'pm_cloud', 'name': clca_str }, 'premiumize.png', n_ins, False)

	def alldebrid(self):
		ad_str, acc_str, his_str, cloud_str = ls(32063), ls(32494), ls(32486), ls(32496)
		clca_str, n_ins = ls(32497) % ad_str, _in_str % (ad_str.upper(), '')
		self._add_item({'mode': 'alldebrid.ad_torrent_cloud',       'name': cloud_str}, 'alldebrid.png', n_ins)
		self._add_item({'mode': 'alldebrid.show_account_info',      'name': acc_str  }, 'alldebrid.png', n_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'ad_cloud', 'name': clca_str }, 'alldebrid.png', n_ins, False)

	def torbox(self):
		tor_str, usenet_str, web_str = 'Torrent', 'Usenet', ls(33150)
		tb_str, cloud_str, ai_str = 'TorBox', ls(32496), ls(32494)
		clca_str, n_ins = ls(32497) % tb_str, _in_str % (tb_str.upper(), '')
		self._add_item({'mode': 'torbox.tb_torrent_cloud', 'media_type': 'torent', 'name': tor_str   }, 'torbox.png', n_ins)
		self._add_item({'mode': 'torbox.tb_torrent_cloud', 'media_type': 'usenet', 'name': usenet_str}, 'torbox.png', n_ins)
		self._add_item({'mode': 'torbox.show_account_info', 'name': ai_str    }, 'torbox.png', n_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'tb_cloud', 'name': clca_str  }, 'torbox.png', n_ins, False)

	def offcloud(self):
		oc_str, clc_str = 'Offcloud', ls(33151),
		cloud_str, ai_str = ls(32496), ls(32494)
		clca_str, n_ins = ls(32497) % oc_str, _in_str % (oc_str.upper(), '')
		self._add_item({'mode': 'offcloud.oc_torrent_cloud',        'name': cloud_str}, 'offcloud.png', n_ins)
		self._add_item({'mode': 'offcloud.show_account_info',       'name': ai_str   }, 'offcloud.png', n_ins, False)
		self._add_item({'mode': 'offcloud.user_cloud_clear',        'name': clc_str  }, 'offcloud.png', n_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'oc_cloud', 'name': clca_str }, 'offcloud.png', n_ins, False)

	def easydebrid(self):
		ed_str, cloud_str, ai_str = 'EasyDebrid', ls(32496), ls(32494)
		n_ins = _in_str % (ed_str.upper(), '')
		self._add_item({'mode': 'easydebrid.show_account_info', 'name': ai_str    }, 'easydebrid.png', n_ins, False)

	def _fav_has(self, favourite_types):
		try:
			from caches.favourites_cache import has_favourites_types
			return has_favourites_types(favourite_types)
		except: return False

	def _fav_add_if(self, favourite_types, url_params, iconImage='favourites.png', prefix='', isFolder=True):
		if not self._fav_has(favourite_types): return False
		self._add_item(url_params, iconImage, prefix, isFolder)
		return True

	def favourites(self):
		# Racine Favoris : dossiers directs, sans cascade de sous-dossiers thématiques.
		fav_str = 'Favoris (alkoFlix)'
		clear_fav_str = 'Vider les favoris'
		n_ins, c_n_ins = _in_str % (fav_str.upper(), ''), _in_str % (ls(32524).upper(), '')
		has_any = False
		has_any = self._fav_add_if(('movie', 'movie_family', 'movie_animation', 'movie_documentary', 'movie_tv_movie'), {'mode': 'build_movie_list', 'action': 'favourites_movies_all', 'name': 'Favoris (Films)', 'fav_type': 'movie'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('tvshow', 'tv_family', 'tv_animation', 'tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news'), {'mode': 'build_tvshow_list', 'action': 'favourites_tvshows_all', 'name': 'Favoris (Séries)', 'fav_type': 'tvshow'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('season', 'season_family', 'season_animation', 'season_documentary'), {'mode': 'build_season_list', 'action': 'favourites_seasons_all', 'name': 'Favoris (Saisons)', 'parent_fav_type': 'tvshow'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('episode', 'episode_family', 'episode_animation', 'episode_documentary'), {'mode': 'build_season_list', 'action': 'favourites_episodes_all', 'name': 'Favoris (Épisodes)', 'parent_fav_type': 'tvshow'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('anime_movie', 'anime_tv', 'anime_season', 'anime_episode'), {'mode': 'navigator.favourites_anime', 'name': 'Animés japonais'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('collection',), {'mode': 'catalogue.sagas_favourites', 'name': 'Sagas'}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if(('person',), {'mode': 'people.favourites', 'name': 'Personnes'}, 'favourites.png', n_ins) or has_any
		if has_any and not ku.external_browse():
			self._add_item({'mode': 'favourites_choice', 'cache': 'clear_favourites', 'fav_group': 'all', 'name': clear_fav_str}, 'broom-ball.png', c_n_ins, False)
		self._end_directory()

	def favourites_series(self):
		# Conservé pour le menu racine Séries, qui garde ses sous-dossiers propres.
		fav_str = ls(32453)
		n_ins = _in_str % (fav_str.upper(), '')
		group = self.params_get('fav_group', 'root')
		mapping = {
			'root': ('favourites_tvshows', 'favourites_seasons', 'favourites_episodes', 'tvshow', 'season', 'episode', 'series_root'),
			'family': ('favourites_tv_family', 'favourites_seasons_family', 'favourites_episodes_family', 'tv_family', 'season_family', 'episode_family', 'series_family'),
			'animation': ('favourites_tv_animation', 'favourites_seasons_animation', 'favourites_episodes_animation', 'tv_animation', 'season_animation', 'episode_animation', 'series_animation'),
			'anime': ('favourites_anime_tv', 'favourites_anime_seasons', 'favourites_anime_episodes', 'anime_tv', 'anime_season', 'anime_episode', 'series_anime'),
			'documentary': ('favourites_tv_documentary', 'favourites_seasons_documentary', 'favourites_episodes_documentary', 'tv_documentary', 'season_documentary', 'episode_documentary', 'series_documentary')
		}
		tv_action, season_action, episode_action, tv_fav_type, season_fav_type, episode_fav_type, clear_group = mapping.get(group, mapping['root'])
		has_any = False
		has_any = self._fav_add_if((tv_fav_type,), {'mode': 'build_tvshow_list', 'action': tv_action, 'name': 'Séries', 'fav_type': tv_fav_type}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if((season_fav_type,), {'mode': 'build_season_list', 'action': season_action, 'name': 'Saisons', 'parent_fav_type': tv_fav_type}, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if((episode_fav_type,), {'mode': 'build_season_list', 'action': episode_action, 'name': 'Épisodes', 'parent_fav_type': tv_fav_type}, 'favourites.png', n_ins) or has_any
		self._end_directory()

	def _favourites_contextual(self, movie_action, movie_type, tv_action, season_action, episode_action, tv_type, season_type, episode_type, include_sagas=False, saga_fav_type='collection', saga_type=''):
		# Favoris contextuels : tout est listé directement dans le dossier Favoris du menu.
		# Les paramètres de contexte sont volontairement répétés dans les URL : ils
		# empêchent Kodi de retomber sur les favoris globaux quand une entrée provient
		# d'un ancien cache navigateur.
		fav_str = ls(32453)
		n_ins = _in_str % (fav_str.upper(), '')
		has_any = False
		movie_params = {'mode': 'build_movie_list', 'action': movie_action, 'name': 'Favoris (Films)', 'fav_type': movie_type}
		tv_params = {'mode': 'build_tvshow_list', 'action': tv_action, 'name': 'Favoris (Séries)', 'fav_type': tv_type}
		season_params = {'mode': 'build_season_list', 'action': season_action, 'name': 'Favoris (Saisons)', 'parent_fav_type': tv_type}
		episode_params = {'mode': 'build_season_list', 'action': episode_action, 'name': 'Favoris (Épisodes)', 'parent_fav_type': tv_type}
		if movie_type == 'movie_family': movie_params['family_type'] = 'movie_family'
		if tv_type == 'tv_family':
			tv_params['family_type'] = 'series_family'
			tv_params['fav_group'] = 'series_family'
			season_params['parent_fav_type'] = 'tv_family'
			season_params['fav_group'] = 'series_family'
			episode_params['parent_fav_type'] = 'tv_family'
			episode_params['fav_group'] = 'series_family'
		has_any = self._fav_add_if((movie_type,), movie_params, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if((tv_type,), tv_params, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if((season_type,), season_params, 'favourites.png', n_ins) or has_any
		has_any = self._fav_add_if((episode_type,), episode_params, 'favourites.png', n_ins) or has_any
		if include_sagas:
			has_any = self._fav_add_if((saga_fav_type,), {'mode': 'catalogue.sagas_favourites', 'name': 'Favoris (Sagas)', 'fav_type': saga_fav_type, 'saga_type': saga_type}, 'favourites.png', n_ins) or has_any
		self._end_directory()

	def favourites_family(self):
		self._favourites_contextual('favourites_movie_family', 'movie_family', 'favourites_tv_family', 'favourites_seasons_family', 'favourites_episodes_family', 'tv_family', 'season_family', 'episode_family', True, 'collection_family', 'family')

	def favourites_animation(self):
		self._favourites_contextual('favourites_movie_animation', 'movie_animation', 'favourites_tv_animation', 'favourites_seasons_animation', 'favourites_episodes_animation', 'tv_animation', 'season_animation', 'episode_animation', True, 'collection_animation', 'animation')

	def favourites_anime(self):
		self._favourites_contextual('favourites_anime_movie', 'anime_movie', 'favourites_anime_tv', 'favourites_anime_seasons', 'favourites_anime_episodes', 'anime_tv', 'anime_season', 'anime_episode', True, 'collection_anime', 'anime')

	def favourites_documentary(self):
		self._favourites_contextual('favourites_movie_documentary', 'movie_documentary', 'favourites_tv_documentary', 'favourites_seasons_documentary', 'favourites_episodes_documentary', 'tv_documentary', 'season_documentary', 'episode_documentary')

	def _my_content_statuses(self):
		trakt_status = ku.get_setting('trakt_user') not in ('', None)
		tmdb_status = ku.get_setting('tmdb.account_id') not in ('', None)
		mdblist_status = ku.get_setting('mdblist.token') not in ('', None)
		return trakt_status, tmdb_status, mdblist_status

	def my_content(self):
		trakt_status, tmdb_status, mdblist_status = self._my_content_statuses()
		active_services = []
		if trakt_status: active_services.append(('navigator.my_content_trakt', 'Trakt', 'trakt.png'))
		if mdblist_status: active_services.append(('navigator.my_content_mdblist', 'MDBList', 'mdblist.png'))
		if tmdb_status: active_services.append(('navigator.my_content_tmdb', 'TMDb', 'tmdb.png'))

		if len(active_services) > 1:
			n_ins = _in_str % (ls(32454).upper(), '')
			for mode, name, icon in active_services:
				self._add_item({'mode': mode, 'name': name}, icon, n_ins)
			self._end_directory()
			return

		if trakt_status: self._add_my_content_trakt()
		elif mdblist_status: self._add_my_content_mdblist()
		elif tmdb_status: self._add_my_content_tmdb()
		else: self._add_my_content_trakt(include_personal=False)
		self._end_directory()

	def my_content_trakt(self):
		self._add_my_content_trakt()
		self._end_directory()

	def my_content_mdblist(self):
		self._add_my_content_mdblist()
		self._end_directory()

	def my_content_tmdb(self):
		self._add_my_content_tmdb()
		self._end_directory()

	def _add_my_content_trakt(self, include_personal=True):
		trakt_str, coll_str, wlist_str, fav_str, ls_str = ls(32037), ls(32499), ls(32500), ls(32453), ls(32501)
		t_n_ins = _in_str % (trakt_str.upper(), '')
		user_str, l_str, ai_str = ls(32065), ls(32501), ls(32494)
		tu_str = 'Listes tendances'
		pu_str = 'Listes populaires'
		sea_str = 'Recherche de listes'
		if include_personal:
			# Raccourcis personnels Trakt visibles dans Mes listes > Trakt.
			# Favoris doit rester au même niveau que Watchlist et Collection.
			self._add_item({'mode': 'navigator.trakt_watchlists' , 'name': wlist_str}, 'thumbtack.png', t_n_ins)
			self._add_item({'mode': 'navigator.trakt_favorites'  , 'name': fav_str  }, 'favourites.png', t_n_ins)
			self._add_item({'mode': 'navigator.trakt_collections', 'name': coll_str }, 'sets.png', t_n_ins)
			self._add_item({'mode': 'navigator.trakt_lists'      , 'name': ls_str   }, 'trakt.png', t_n_ins)
			self._add_item({'mode': 'build_tvshow_list', 'action': 'in_progress_tvshows', 'watched_indicators': '1', 'name': ls(32481)}, 'recent.png', t_n_ins)
			self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_in_progress_tvshows', 'watched_indicators': '1', 'hide_watched_items': 'true', 'name': ls(33122)}, 'in_progress_tvshow.png', t_n_ins)
			self._add_item({'mode': 'build_next_episode', 'watched_indicators': '1', 'name': ls(32483)}, 'next_episode.png', t_n_ins)
			self._add_item({'mode': 'trakt.trakt_account_info'   , 'name': ai_str   }, 'info2.png', t_n_ins, False)
		self._add_item({'mode': 'build_trakt_list.get_trakt_trending_popular_lists', 'list_type': 'trending', 'name': tu_str }, 'rocket.png', t_n_ins)
		self._add_item({'mode': 'build_trakt_list.get_trakt_trending_popular_lists', 'list_type': 'popular' , 'name': pu_str }, 'popular.png', t_n_ins)
		self._add_item({'mode': 'build_trakt_list.search_trakt_lists'                                       , 'name': sea_str}, 'search.png', t_n_ins)

	def _add_my_content_mdblist(self):
		coll_str, wlist_str, fav_str = ls(32499), ls(32500), ls(32453)
		ai_str, ml_str = ls(32494), ls(32454)
		pu_str, sea_str = 'Listes populaires', 'Recherche de listes'
		m_n_ins = _in_str % ('MDBList'.upper(), '')
		self._add_item({'mode': 'navigator.mdblist_watchlists' , 'name': wlist_str}, 'thumbtack.png', m_n_ins)
		self._add_item({'mode': 'navigator.mdblist_favorites'  , 'name': fav_str  }, 'favourites.png', m_n_ins)
		self._add_item({'mode': 'navigator.mdblist_collections', 'name': coll_str }, 'sets.png', m_n_ins)
		self._add_item({'mode': 'build_mdb_list.get_mdbl_lists', 'list_type': 'my_lists', 'name': ml_str}, 'mdblist.png', m_n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'in_progress_tvshows', 'watched_indicators': '2', 'name': ls(32481)}, 'recent.png', m_n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_in_progress_tvshows', 'watched_indicators': '2', 'hide_watched_items': 'true', 'name': ls(33122)}, 'in_progress_tvshow.png', m_n_ins)
		self._add_item({'mode': 'build_next_episode', 'watched_indicators': '2', 'name': ls(32483)}, 'next_episode.png', m_n_ins)
		self._add_item({'mode': 'mdblist.mdbl_account_info', 'name': ai_str}, 'info2.png', m_n_ins, False)
		self._add_item({'mode': 'build_mdb_list.get_mdbl_toplists', 'name': pu_str}, 'popular.png', m_n_ins)
		self._add_item({'mode': 'build_mdb_list.search_mdbl_lists', 'name': sea_str}, 'search.png', m_n_ins)

	def mdblist_watchlists(self):
		wlist_str = ls(32500)
		n_ins = _in_str % (('MDBList %s' % wlist_str).upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'mdblist_watchlist', 'name': mov_str}, 'thumbtack.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'mdblist_watchlist', 'name': tv_str}, 'thumbtack.png', n_ins)
		self._end_directory()

	def mdblist_favorites(self):
		fav_str = ls(32453)
		n_ins = _in_str % (('MDBList %s' % fav_str).upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'mdblist_favorites', 'name': mov_str}, 'favourites.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'mdblist_favorites', 'name': tv_str}, 'favourites.png', n_ins)
		self._end_directory()

	def mdblist_collections(self):
		coll_str = ls(32499)
		n_ins = _in_str % (('MDBList %s' % coll_str).upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'mdblist_collection', 'name': mov_str}, 'sets.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'mdblist_collection', 'name': tv_str}, 'sets.png', n_ins)
		self._end_directory()

	def _add_my_content_tmdb(self):
		wlist_str, fav_str, rec_str, ml_str = ls(32500), ls(32453), ls(32503), ls(32454)
		tmdb_n_ins = _in_str % ('TMDb'.upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'tmdb_watchlist'       , 'name': '%s (%s)' % (wlist_str, mov_str)}, 'thumbtack.png', tmdb_n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'tmdb_watchlist'      , 'name': '%s (%s)' % (wlist_str, tv_str) }, 'thumbtack.png', tmdb_n_ins)
		self._add_item({'mode': 'build_tmdb_list.get_tmdb_lists'                     , 'name': ml_str                         }, 'user.png', tmdb_n_ins)
		self._add_item({'mode': 'build_movie_list', 'action': 'tmdb_favorite'        , 'name': '%s (%s)' % (fav_str, mov_str)  }, 'favourites.png', tmdb_n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'tmdb_favorite'       , 'name': '%s (%s)' % (fav_str, tv_str)   }, 'favourites.png', tmdb_n_ins)
		self._add_item({'mode': 'build_movie_list', 'action': 'tmdb_recommendations' , 'name': '%s (%s)' % (rec_str, mov_str)  }, 'announce.png', tmdb_n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'tmdb_recommendations', 'name': '%s (%s)' % (rec_str, tv_str)   }, 'announce.png', tmdb_n_ins)

	def tmdb_favorites(self):
		fav_str = ls(32453)
		n_ins = _in_str % (('TMDb %s' % fav_str).upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'tmdb_favorite',  'name': mov_str}, 'favourites.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'tmdb_favorite', 'name': tv_str }, 'favourites.png', n_ins)
		self._end_directory()

	def trakt_collections(self):
		# use 'new_page' to pass the type of list to be processed when using 'trakt_collection_lists'...
		t_str, col_str = ls(32037), ls(32499)
		tcol_str = '%s %s' % (t_str, col_str)
		n_ins = _in_str % (tcol_str.upper(), '')
		mrec_str, mran_str = '%s %s' % (ls(32498), mov_str), '%s %s' % (ls(32504), mov_str)
		tvrec_str, tvran_str, ra_str = '%s %s' % (ls(32498), tv_str), '%s %s' % (ls(32504), tv_str), '%s %s' % (ls(32505), ls(32506))
		n_ins = _in_str % (col_str.upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_collection'                             , 'name': mov_str  }, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_collection'                            , 'name': tv_str   }, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_collection_lists', 'new_page': 'recent' , 'name': mrec_str }, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_collection_lists', 'new_page': 'random' , 'name': mran_str }, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_collection_lists', 'new_page': 'recent', 'name': tvrec_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_collection_lists', 'new_page': 'random', 'name': tvran_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_my_calendar', 'recently_aired': 'true'                                , 'name': ra_str   }, 'trakt.png', n_ins)
		self._end_directory()

	def trakt_watchlists(self):
		t_str, watchlist_str = ls(32037), ls(32500)
		trakt_watchlist_str = '%s %s' % (t_str, watchlist_str)
		n_ins = _in_str % (trakt_watchlist_str.upper(), '')
		tmdb_status = ku.get_setting('tmdb.account_id') not in ('', None)
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_watchlist',  'name': mov_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_watchlist', 'name': tv_str }, 'trakt.png', n_ins)
		self._add_item({'mode': 'tmdb.import_trakt_watchlist',                    'name': ls(33147)}, 'trakt.png', n_ins, False) if tmdb_status else None
		self._end_directory()


	def trakt_favorites(self):
		t_str, fav_str = ls(32037), ls(32453)
		trakt_favorites_str = '%s %s' % (t_str, fav_str)
		n_ins = _in_str % (trakt_favorites_str.upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_favorites',  'name': mov_str}, 'favourites.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_favorites', 'name': tv_str }, 'favourites.png', n_ins)
		self._end_directory()

	def trakt_lists(self):
		t_str, ml_str, ll_str, rec_str = ls(32037), ls(32454), ls(32502), ls(32503)
		cal_str, ani_str, drp_str = ls(32081), ls(33148), ls(33149)
		n_ins = _in_str % (t_str.upper(), '')
		self._add_item({'mode': 'build_trakt_list.get_trakt_lists', 'list_type': 'my_lists'   , 'name': ml_str }, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_trakt_list.get_trakt_lists', 'list_type': 'liked_lists', 'name': ll_str }, 'trakt.png', n_ins)
		self._add_item({'mode': 'navigator.trakt_recommendations'                             , 'name': rec_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_droplist'               , 'name': drp_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_my_calendar'                                           , 'name': cal_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_my_anime_calendar'                                     , 'name': ani_str}, 'trakt.png', n_ins)
		self._end_directory()

	def trakt_recommendations(self):
		rec_str = ls(32503)
		n_ins = _in_str % (rec_str.upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'trakt_recommendations',  'name': mov_str}, 'trakt.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'trakt_recommendations', 'name': tv_str }, 'trakt.png', n_ins)
		self._end_directory()

	def imdb_watchlists(self):
		imdb_str, watchlist_str = ls(32064), ls(32500)
		imdb_watchlist_str = '%s %s' % (imdb_str, watchlist_str)
		n_ins = _in_str % (imdb_watchlist_str.upper(), '')
		self._add_item({'mode': 'build_movie_list', 'action': 'imdb_watchlist',  'name': mov_str}, 'imdb.png', n_ins)
		self._add_item({'mode': 'build_tvshow_list', 'action': 'imdb_watchlist', 'name': tv_str }, 'imdb.png', n_ins)
		self._end_directory()

	def imdb_lists(self):
		imdb_str, lists_str = ls(32064), ls(32501)
		imdb_lists_str = '%s %s' % (imdb_str, lists_str)
		n_ins = _in_str % (imdb_lists_str.upper(), '')
		self._add_item({'mode': 'imdb_build_user_lists', 'media_type': 'movie',  'name': mov_str}, 'imdb.png', n_ins)
		self._add_item({'mode': 'imdb_build_user_lists', 'media_type': 'tvshow', 'name': tv_str }, 'imdb.png', n_ins)
		self._end_directory()

	def search(self):
		search_str, people_str, clca_str, help_str = ls(32450), ls(32507), ls(32497), ls(32487)
		coll_str, clear_search_str = 'Sagas de films', clca_str % search_str
		kw_mov, kw_tv = 'Mot-clé TMDb (%s)' % mov_str, 'Mot-clé TMDb (%s)' % tv_str
		n_ins, s_n_ins = _in_str % (ls(32524).upper(), ''), _in_str % (search_str.upper(), '')
		self._add_item({'mode': 'navigator.discover_main',                         'name': ls(32451)       }, 'discover.png', s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'movie',               'name': mov_str         }, 'search_movie.png' , s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'tvshow',              'name': tv_str          }, 'search_tv.png'    , s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'people',              'name': people_str      }, 'search_people.png', s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'tmdb_collections',    'name': coll_str        }, 'search_tmdb.png'  , s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'tmdb_keyword_movie',  'name': kw_mov          }, 'search_tmdb.png'  , s_n_ins)
		self._add_item({'mode': 'search_history', 'action': 'tmdb_keyword_tvshow', 'name': kw_tv           }, 'search_tmdb.png'  , s_n_ins)
		self._add_item({'mode': 'tmdb_keyword_help', 'name': help_str}, 'info2.png', s_n_ins, False)
		self._add_item({'mode': 'clear_search_history',                            'name': clear_search_str}, 'tools.png'        , n_ins, False)
		self._end_directory()

	def settings(self):
		alkoflix_str, manager_str, changelog_str = 'Réglages alkoFlix', ls(32513), ls(32508)
		log_utils, views_str, clean_str, lang_inv_str, ms_str = ls(32777), ls(32510), ls(32512), ls(32978), ls(32455)
		settings_str, changelog_log_viewer_str = ls(32247), '%s & %s' % (changelog_str, log_utils)
		shortcut_manager_str = 'Gestion des dossiers de widgets'
		n_ins, l_str = _in_str % (settings_str.upper(), ''), _in_str % ('LINKS', '')
		self._add_item({'mode': 'open_settings', 'query': '4.0', 'name': alkoflix_str                 }, 'alkoflix.png', n_ins, False)
		self._add_item({'mode': 'myservices',                    'name': ms_str                  }, 'premium.png', n_ins, False)
		self._add_item({'mode': 'navigator.clear_info',          'name': clean_str               }, 'tools.png', n_ins)
		self._add_item({'mode': 'navigator.log_utils',           'name': changelog_log_viewer_str}, 'info.png', n_ins)
		self._add_item({'mode': 'navigator.set_view_modes',      'name': views_str               }, 'lists.png', n_ins)
		self._add_item({'mode': 'navigator.shortcut_folders',    'name': shortcut_manager_str    }, 'folder.png', n_ins)
		self._add_item({'mode': 'toggle_language_invoker',       'name': lang_inv_str            }, 'languages.png', n_ins, False)
		self._end_directory()

	def clear_info(self):
		cache_str, clca_str, clean_str, settings_str = ls(32524), ls(32497), ls(32526), ls(32247)
		clean_all_str = 'Nettoyer tous les paramètres'
		clean_set_cache_str = 'Nettoyer les paramètres en cache'
		clean_databases_str = 'Nettoyer les bases de données'
		clean_thumbs_str = 'Nettoyer les miniatures obsolètes'
		clear_internal_str = 'Vider les caches internes'
		clear_services_str = 'Vider le cache des services'
		clear_meta_str = 'Vider le cache des métadonnées'
		clear_list_str = 'Vider le cache des listes'
		clear_menu_str = 'Vider le cache des menus'
		clear_folders_str = 'Vider le cache des dossiers de liens'
		clear_trakt_str, clear_mdbl_str = clca_str % ls(32037), clca_str % 'MDBList'
		clear_tmdb_str, clear_wyzie_str = clca_str % 'TMDbLists', clca_str % 'Wyzie'
		clear_easynews_str = clca_str % 'EasyNews'
		clear_imdb_str = clca_str % ls(32064)
		clext_str = 'Vider le cache des scrapers externes'
		clear_ad_str, clear_pm_str, clear_rd_str = clca_str % ls(32063), clca_str % ls(32061), clca_str % ls(32054)
		clear_tb_str, clear_oc_str = clca_str % 'TorBox', clca_str % 'Offcloud'
		clear_internal_upper = '[B]%s[/B]' % clear_internal_str
		clear_services_upper = '[B]%s[/B]' % clear_services_str
		clean_ins = _in_str % (clean_str.upper(), '')
		internal_ins = _in_str % ('CACHES INTERNES', '')
		services_ins = _in_str % ('CACHES DES SERVICES', '')
		self._add_item({'mode': 'clean_settings',                            'name': clean_all_str      }, 'settings.png', clean_ins, False)
		self._add_item({'mode': 'clean_settings_window_properties',          'name': clean_set_cache_str}, 'recent.png', clean_ins, False)
		self._add_item({'mode': 'clean_databases',                           'name': clean_databases_str}, 'database.png', clean_ins, False)
		self._add_item({'mode': 'clean_thumbnails',                          'name': clean_thumbs_str   }, 'pictures.png', clean_ins, False)
		self._add_item({'mode': 'clear_internal_cache',                      'name': clear_internal_upper}, 'broom-ball.png', internal_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'meta',              'name': clear_meta_str      }, 'info2.png', internal_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'list',              'name': clear_list_str      }, 'lists.png', internal_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'navigator',         'name': clear_menu_str      }, 'folder.png', internal_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'external_scrapers', 'name': clext_str           }, 'magnet.png', internal_ins, False)
		self._add_item({'mode': 'clear_cache', 'cache': 'folders',           'name': clear_folders_str   }, 'cloud.png', internal_ins, False)
		from modules.debrid import debrid_enabled
		enabled_debrids = debrid_enabled()
		trakt_active = ku.get_setting('trakt_user') not in ('', None)
		mdblist_active = ku.get_setting('mdblist.token') not in ('', None)
		tmdb_active = ku.get_setting('tmdb.token') not in ('', None) or ku.get_setting('tmdb.session_id') not in ('', None)
		imdb_active = ku.get_setting('imdb_user') not in ('', None)
		wyzie_active = ku.get_setting('subtitles.apikey') not in ('', None)
		easynews_active = ks.easynews_active()
		self._add_item({'mode': 'clear_services_cache',                      'name': clear_services_upper}, 'cloud.png', services_ins, False)
		if trakt_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'trakt',             'name': clear_trakt_str     }, 'trakt.png', services_ins, False)
		if mdblist_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'mdblist',           'name': clear_mdbl_str      }, 'mdblist.png', services_ins, False)
		if tmdb_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'tmdblist',          'name': clear_tmdb_str      }, 'tmdb.png', services_ins, False)
		if imdb_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'imdb',              'name': clear_imdb_str      }, 'imdb_small.png', services_ins, False)
		if wyzie_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'wyzie',             'name': clear_wyzie_str     }, 'languages.png', services_ins, False)
		if easynews_active:
			self._add_item({'mode': 'clear_cache', 'cache': 'easynews',          'name': clear_easynews_str  }, 'easynews.png', services_ins, False)
		if 'alldebrid' in enabled_debrids:
			self._add_item({'mode': 'clear_cache', 'cache': 'ad_cloud',          'name': clear_ad_str        }, 'alldebrid.png', services_ins, False)
		if 'premiumize.me' in enabled_debrids:
			self._add_item({'mode': 'clear_cache', 'cache': 'pm_cloud',          'name': clear_pm_str        }, 'premiumize.png', services_ins, False)
		if 'real-debrid' in enabled_debrids:
			self._add_item({'mode': 'clear_cache', 'cache': 'rd_cloud',          'name': clear_rd_str        }, 'realdebrid.png', services_ins, False)
		if 'torbox' in enabled_debrids:
			self._add_item({'mode': 'clear_cache', 'cache': 'tb_cloud',          'name': clear_tb_str        }, 'torbox.png', services_ins, False)
		if 'offcloud' in enabled_debrids:
			self._add_item({'mode': 'clear_cache', 'cache': 'oc_cloud',          'name': clear_oc_str        }, 'offcloud.png', services_ins, False)
		self._end_directory()

	def set_view_modes(self):
		set_views_str, lists_str, root_str, movies_str = ls(32510), ls(32501), ls(32457), ls(32028)
		tvshows_str, season_str, episode_str = ls(32029), ls(32537), ls(32506)
		premium_files_str, ep_lists_str = ls(32485), 'Listes d\'épisodes'
		n_ins, reset_str = _in_str % (set_views_str.upper(), ''), 'Réinitialiser toutes les vues'
		self._add_item({'mode': 'choose_view', 'view_type': 'view.main', 'content': ''                  , 'name': root_str         }, 'alkoflix.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.movies', 'content': 'movies'          , 'name': movies_str       }, 'movies.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.tvshows', 'content': 'tvshows'        , 'name': tvshows_str      }, 'tv.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.seasons', 'content': 'seasons'        , 'name': season_str       }, 'folder.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.episodes', 'content': 'episodes'      , 'name': episode_str      }, 'player.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.episodes_lists', 'content': 'episodes', 'name': ep_lists_str     }, 'lists.png', n_ins)
		self._add_item({'mode': 'choose_view', 'view_type': 'view.premium', 'content': 'files'          , 'name': premium_files_str}, 'premium.png', n_ins)
		self._add_item({'mode': 'clear_view', 'view_type': 'all'                                                                    , 'name': reset_str        }, 'tools.png', n_ins, False)
		self._end_directory()

	def log_utils(self):
		alkoflix_vstr, log_path = ku.get_addoninfo('version'), 'special://home/addons/%s/changelog.txt'
		kl_loc, mt_str = 'special://logpath/kodi.log', log_path % 'plugin.video.alkoflix'
		alkoflix_str, cl_str, lut_str, k_str, lv_str = ls(32036), ls(32508), ls(32777), ls(32538), ls(32509)
		mh_str, klv_h, klu_h = '%s  (v.%s)' % (alkoflix_str, alkoflix_vstr), '%s %s' % (k_str, lv_str), ls(32853)
		cl_n_ins, lu_n_ins = _in_str % (cl_str.upper(), ''), _in_str % (lut_str.upper(), '')
		self._add_item({'mode': 'show_text', 'heading': mh_str, 'file': mt_str,                    'name': mh_str}, 'lists.png', cl_n_ins, False)
		self._add_item({'mode': 'show_text', 'heading': klv_h, 'file': kl_loc, 'kodi_log': 'true', 'name': klv_h }, 'lists.png', lu_n_ins, False)
		self._add_item({'mode': 'upload_logfile',                                                  'name': klu_h }, 'lists.png', lu_n_ins, False)
		self._end_directory()

	def years(self):
		from modules.meta_lists import years
		menu_type = self.params_get('menu_type')
		mode = 'build_movie_list' if menu_type == 'movie' else 'build_tvshow_list'
		action = 'tmdb_movies_year' if menu_type == 'movie' else 'tmdb_tv_year'
		lst_ins = self.make_list_name(menu_type)
		for i in years():
			list_name = '%s: %s %s' % (lst_ins.upper(), str(i), ls(32460))
			self._add_item({'mode': mode, 'action': action, 'year': str(i), 'name': str(i)}, 'calender.png', list_name=list_name)
		self._end_directory()

	def anime_years(self):
		from modules.meta_lists import years
		menu_type = self.params_get('menu_type')
		mode = 'build_movie_list' if menu_type == 'movie' else 'build_tvshow_list'
		action = 'tmdb_moviesanime_year' if menu_type == 'movie' else 'tmdb_tvanime_year'
		lst_ins = self.make_list_name(menu_type)
		for i in years():
			list_name = 'ANIME %s: %s %s' % (lst_ins.upper(), str(i), ls(32460))
			self._add_item({'mode': mode, 'action': action, 'year': str(i), 'name': str(i)}, 'calender.png', list_name=list_name)
		self._end_directory()

	def genres(self):
		import json
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie':
			from modules.meta_lists import movie_genres as genre_list
			mode, action = 'build_movie_list', 'tmdb_movies_genres'
		else:
			from modules.meta_lists import tvshow_genres as genre_list
			mode, action = 'build_tvshow_list', 'tmdb_tv_genres'
		# Les genres isolés dans des menus dédiés sont retirés des menus généraux
		# pour éviter les doublons dans Films/Séries.
		excluded_genres = {'16'}
		if menu_type == 'movie':
			excluded_genres.update(('99', '10770'))
		else:
			excluded_genres.update(('99', '10763', '10764', '10767'))
		genre_list = {genre: value for genre, value in genre_list.items() if str(value[0]) not in excluded_genres}
		lst_ins = self.make_list_name(menu_type)
		self._add_item({'mode': 'navigator.multiselect_genres', 'genre_list': json.dumps(genre_list), 'menu_type': menu_type, 'name': ls(32789)}, 'genres.png', isFolder=False)
		for genre, value in sorted(genre_list.items()):
			if str(value[0]) == '16': continue
			list_name = '%s: %s %s' % (lst_ins.upper(), genre, ls(32470))
			self._add_item({'mode': mode, 'action': action, 'genre_id': value[0], 'name': genre}, value[1], list_name=list_name)
		self._end_directory()

	def anime_genres(self):
		menu_type = self.params_get('menu_type')
		if menu_type == 'movie':
			from modules.meta_lists import movie_genres as genre_list
			mode, action = 'build_movie_list', 'tmdb_moviesanime_genres'
		else:
			from modules.meta_lists import tvshow_genres as genre_list
			mode, action = 'build_tvshow_list', 'tmdb_tvanime_genres'
		lst_ins = self.make_list_name(menu_type)
		for genre, value in sorted(genre_list.items()):
			list_name = 'ANIME %s: %s %s' % (lst_ins.upper(), genre, ls(32470))
			self._add_item({'mode': mode, 'action': action, 'genre_id': value[0], 'name': genre}, value[1], list_name=list_name)
		self._end_directory()

	def multiselect_genres(self):
		import json
		def _builder():
			for genre, value in genre_list.items():
				function_list_append(value[0])
				yield {'line1': genre, 'icon': '%s%s' % (icon_path, value[1])}
		menu_type, genre_list, icon_path = self.params['menu_type'], self.params['genre_list'], media_path()
		function_list = []
		function_list_append = function_list.append
		genre_list = dict(sorted(json.loads(genre_list).items()))
		list_items = list(_builder())
		kwargs = {'items': json.dumps(list_items), 'heading': ls(32847), 'enumerate': 'false', 'multi_choice': 'true', 'multi_line': 'false'}
		genre_ids = ku.select_dialog(function_list, **kwargs)
		if genre_ids is None: return
		genre_id = ','.join(genre_ids)
		if menu_type == 'movie': url = {'mode': 'build_movie_list', 'action': 'tmdb_movies_genres', 'genre_id': genre_id}
		else: url = {'mode': 'build_tvshow_list', 'action': 'tmdb_tv_genres', 'genre_id': genre_id}
		return ku.execute_builtin('Container.Update(%s)' % build_url(url))

	def networks(self):
		from modules.meta_lists import networks
		lst_ins = self.make_list_name(self.params_get('menu_type'))
		for item in sorted(networks, key=lambda k: k['name']):
			list_name = '%s: %s %s' % (lst_ins.upper(), item['name'], ls(32480))
			self._add_item({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_networks', 'network_id': item['id'], 'name': item['name']}, item['logo'], list_name=list_name)
		self._end_directory()

	def because_you_watched(self):
		from caches.watched_cache import get_watched_info_movie, get_watched_info_tv
		def _convert_alkoflix_watched_episodes_info(watched_indicators):
			seen = set()
			_watched = get_watched_info_tv(watched_indicators)
			_watched.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
			return [(i[0], i[3], i[4], [(i[1], i[2])]) for i in _watched if not (i[0] in seen or seen.add(i[0]))]
		watched_indicators = ks.watched_indicators()
		media_type = self.params_get('menu_type')
		function = get_watched_info_movie if media_type == 'movie' else _convert_alkoflix_watched_episodes_info
		mode = 'build_movie_list' if media_type == 'movie' else 'build_tvshow_list'
		action = 'tmdb_movies_recommendations' if media_type == 'movie' else 'tmdb_tv_recommendations'
		recently_watched = function(watched_indicators)
		recently_watched = sorted(recently_watched, key=lambda k: k[2], reverse=True)
		because_ins = '%s  [B]%s[/B]' % (ls(32474), '%s')
		for item in recently_watched:
			tmdb_id = item[0]
			if media_type == 'movie': name = because_ins % item[1]
			else:
				season, episode = item[3][-1]
				name = because_ins % '%s - %sx%s' % (item[1], season, episode)
			self._add_item({'mode': mode, 'action': action, 'tmdb_id': tmdb_id, 'name': name}, 'because_you_watched.png')
		self._end_directory()

	def folder_navigator(self):
		import os
		from modules.utils import clean_file_name, normalize
		def _process():
			for item, isFolder in items:
				try:
					url = os.path.join(folder_path, item)
					listitem = make_listitem()
					listitem.setLabel(clean_file_name(normalize(item)))
					listitem.setArt({'fanart': fanart})
					yield (url, listitem, isFolder)
				except: pass
		handle, fanart = self.params_get('handle'), self.params_get('fanart')
		folder_path = self.params_get('folder_path')
		sources_folders = self.params_get('sources_folders')
		dirs, files = list_dirs(folder_path)
		items = [(i, True) for i in dirs] + [(i, False) for i in files]
		add_items(handle, list(_process()))
		set_sort_method(handle, 'files')
		self._end_directory()

	def sources_folders(self):
		name_str = '%s (%s): %s\n     %s'
		for source in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5'):
			for media_type in ('movie', 'tvshow'):
				folder_path = ks.source_folders_directory(media_type, source)
				if not folder_path: continue
				name = name_str % (source.upper(), self.make_list_name(media_type).upper(), ku.get_setting('%s.display_name' % source).upper(), folder_path)
				self._add_item({'mode': 'navigator.folder_navigator','sources_folders': 'True', 'folder_path': folder_path, 'name': name}, 'most_collected.png')
		self._end_directory()

	def shortcut_folders(self):
		def _builder():
			for i in folders:
				try:
					cm = []
					cm_append = cm.append
					contents = eval(i[1])
					name, icon = i[0], '%s%s' % (icon_path, 'folder.png')
					display_name = '%s : %s ' % (short_str.upper(), name)
					url_params = {'name': name, 'iconImage': 'folder.png', 'external_list_item': 'True'}
					url = build_url({'mode': 'navigator.build_shortcut_folder_list', 'shortcut_folder': 'True', **url_params})
					cm_append((delete_str, 'RunPlugin(%s)'% build_url({'mode': 'menu_editor.shortcut_folder_delete', 'list_name': name})))
					listitem = make_listitem()
					listitem.setLabel(display_name)
					listitem.addContextMenuItems(cm)
					listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
					yield (url, listitem, True)
				except: pass
		handle, fanart, icon_path = self.params_get('handle'), self.params_get('fanart'), media_path()
		short_str, delete_str, new_folder_str = ls(32514), ls(32703), '%s...' % ls(32702)
		add_dir(handle, {'mode': 'menu_editor.shortcut_folder_make'}, new_folder_str, media_path('new.png'), isFolder=False)
		folders = nc.get_shortcut_folders()
		if folders: add_items(handle, list(_builder()))
		self._end_directory()

	def build_shortcut_folder_list(self):
		def _process():
			for item_position, item in enumerate(contents):
				try:
					cm = []
					cm_append = cm.append
					item_get = item.get
					mode_check = item_get('mode', '')
					if mode_check == 'navigator.downloads' or mode_check == 'downloader' or '_downloads' in mode_check: continue
					name = item_get('name', 'Error: No Name')
					icon = item_get('iconImage') if item_get('network_id', '') != '' else '%s%s' % (icon_path, item_get('iconImage'))
					isFolder = False if item_get('isFolder', '') == 'false' else True
					url = build_url(item)
					edit_params = {'mode': 'menu_editor.edit_menu_shortcut_folder', 'active_list': list_name, 'position': item_position}
					cm_append((edit_str,'RunPlugin(%s)' % build_url(edit_params)))
					listitem = make_listitem()
					listitem.setLabel(name)
					listitem.addContextMenuItems(cm)
					listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
					yield (url, listitem, isFolder)
				except: pass
		handle, fanart, icon_path = self.params_get('handle'), self.params_get('fanart'), media_path()
		list_name = self.params_get('name')
		contents = nc.get_shortcut_folder_contents(list_name)
		add_items(handle, list(_process()))
		self._end_directory()

	def main(self):
		def build_main_lists():
			for item_position, item in enumerate(contents):
				try:
					cm = []
					cm_append = cm.append
					item_get = item.get
					mode_check = item_get('mode', '')
					if mode_check == 'navigator.downloads' or mode_check == 'downloader' or '_downloads' in mode_check: continue
					if item_get('iconImage') in ('', 'None', None, 'DefaultFolder.png'): icon = media_path('myfolder.png')
					elif item_get('iconImage') == 'alkoflix.png': icon = ku.get_addoninfo('icon')
					elif item_get('network_id', '') != '': icon = item_get('iconImage')
					else: icon = '%s%s' % (icon_path, item_get('iconImage'))
					isFolder = False if item_get('isFolder') == 'false' else True
					cm_append((edit_str, 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.edit_menu', 'active_list': self.list_name, 'position': item_position})))
					cm_append((browse_str, 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.browse', 'active_list': self.list_name})))
					listitem = make_listitem()
					listitem.setLabel(ls(item_get('name', '')))
					listitem.addContextMenuItems(cm)
					listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
					yield (build_url(item), listitem, isFolder)
				except: pass
		handle, fanart, icon_path = self.params_get('handle'), self.params_get('fanart'), media_path()
		contents = nc.currently_used_list(self.list_name)
		# Corrige les anciens libellés/icônes déjà stockés dans le cache utilisateur.
		# Cela évite de demander une reconstruction manuelle du menu après la mise à jour.
		if self.list_name in ('RootList', 'MovieList', 'TVShowList', 'DocumentaryList', 'FamilyList', 'AnimeList', 'AnimationList'):
			contents = list(contents)
			anime_name_map = {
				('build_anime_calendar', '', ''): 33155,
				('build_tvshow_list', 'trakt_tvanime_trending', ''): 33156,
				('build_tvshow_list', 'trakt_tvanime_most_watched', ''): 33157,
				('build_tvshow_list', 'tmdb_tvanime_popular', ''): 33158,
				('build_tvshow_list', 'tmdb_tvanime_premieres', ''): 33159,
				('navigator.anime_genres', '', 'tvshow'): 33160,
				('navigator.anime_years', '', 'tvshow'): 33161,
				('build_movie_list', 'trakt_moviesanime_trending', ''): 33162,
				('build_movie_list', 'trakt_moviesanime_most_watched', ''): 33163,
				('build_movie_list', 'tmdb_moviesanime_popular', ''): 33164,
				('build_movie_list', 'tmdb_moviesanime_latest_releases', ''): 33165,
				('navigator.anime_genres', '', 'movie'): 33166,
				('navigator.anime_years', '', 'movie'): 33167
			}
			for item in contents:
				# Force les libellés favoris de premier niveau, même si l'ancien menu
				# est déjà stocké dans le cache navigateur ou dans une liste éditée.
				# Sans cette normalisation, Kodi peut continuer d'afficher « Favoris »
				# ou « Séries » malgré la définition corrigée dans menu_lists.py.
				if self.list_name == 'MovieList' and item.get('action') == 'favourites_movies':
					item['name'] = 'Favoris (Films)'
				if self.list_name == 'TVShowList' and (
					(item.get('mode') == 'navigator.favourites_series' and item.get('fav_group', 'root') == 'root')
					or item.get('action') == 'favourites_tvshows'
				):
					item['name'] = 'Favoris (Séries)'
				if item.get('action') in ('watched_movies', 'watched_tvshows'):
					item['name'] = 32475
				if item.get('action') == 'in_progress_tvshows':
					item['iconImage'] = 'recent.png'
				if self.list_name == 'TVShowList' and item.get('action') == 'favourites_tvshows':
					item['mode'] = 'navigator.favourites_series'
					item['fav_group'] = 'root'
					item.pop('action', None)
					item['name'] = 'Favoris (Séries)'
				if self.list_name == 'TVShowList' and item.get('action') == 'trakt_in_progress_tvshows':
					# Dans le menu Séries racine, « Vos visionnages en cours » doit suivre le suivi actif
					# de l'utilisateur : local alkoFlix, Trakt ou MDBList.
					item.pop('watched_indicators', None)
					item['hide_watched_items'] = 'true'
					item['name'] = 33122
					item['iconImage'] = 'in_progress_tvshow.png'
				if self.list_name == 'RootList':
					if item.get('mode') == 'navigator.premium':
						item['name'] = 'Débrideur(s)'
					if item.get('action') == 'DocumentaryList':
						item['name'] = 'Docus & Télé'
						item['iconImage'] = 'genre_documentary.png'
					if item.get('action') == 'FamilyList':
						item['name'] = 'Famille'
						item['iconImage'] = 'genre_family.png'

				if self.list_name == 'AnimeList':
					key = (item.get('mode', ''), item.get('action', ''), item.get('menu_type', ''))
					if key in anime_name_map:
						item['name'] = anime_name_map[key]
					# Restaure les icônes des nouvelles entrées si un ancien cache les a gardées sans image.
					if item.get('mode') == 'catalogue.native_anime':
						if item.get('native_type') == 'anime_series':
							item['iconImage'] = 'tv.png'
						elif item.get('native_type') == 'anime_movie':
							item['iconImage'] = 'movies.png'




		def _ensure_contextual_favourites_item(contents, mode, name, insert_at=None):
			if any(item.get('mode') == mode for item in contents): return contents
			contents = list(contents)
			new_item = {'name': name, 'iconImage': 'favourites.png', 'mode': mode}
			if insert_at is None: contents.append(new_item)
			else: contents.insert(min(insert_at, len(contents)), new_item)
			return contents

		# Les favoris contextuels ne doivent vivre qu'à la racine du menu thématique.
		# Les anciens caches pouvaient garder des dossiers Favoris dans les sous-arborescences
		# (Films/Séries/Docus/Anime), ce qui donnait un effet de puits sans fin.
		contextual_submenus = (
			'DocumentaryMovieRootList', 'DocumentarySeriesRootList',
			'DocumentaryMovieDocumentaryList', 'DocumentaryTvMovieList',
			'DocumentarySeriesDocumentaryList', 'DocumentarySeriesRealityList',
			'DocumentarySeriesTalkshowList', 'DocumentarySeriesNewsList',
			'FamilyMovieList', 'FamilySeriesList',
			'AnimationMovieList', 'AnimationSeriesList',
			'AnimeMovieList', 'AnimeSeriesList'
		)
		if self.list_name in contextual_submenus:
			contents = [i for i in contents if not str(i.get('mode', '')).startswith('navigator.favourites_')]

		if self.list_name == 'DocumentaryList':
			contents = _ensure_contextual_favourites_item(contents, 'navigator.favourites_documentary', 'Favoris', insert_at=2)
		elif self.list_name == 'FamilyList':
			contents = _ensure_contextual_favourites_item(contents, 'navigator.favourites_family', 'Favoris', insert_at=2)
		elif self.list_name == 'AnimationList':
			contents = _ensure_contextual_favourites_item(contents, 'navigator.favourites_animation', 'Favoris', insert_at=2)
		elif self.list_name == 'AnimeList':
			contents = _ensure_contextual_favourites_item(contents, 'navigator.favourites_anime', 'Favoris', insert_at=2)

		if self.list_name in ('MovieList', 'TVShowList'):
			# Les anciens raccourcis « À venir » peuvent rester dans le cache utilisateur
			# après une mise à jour. Ils sont retirés sans toucher aux autres entrées.
			legacy_upcoming_actions = ('tmdb_movies_upcoming', 'tmdb_tv_upcoming')
			contents = [i for i in contents if i.get('action') not in legacy_upcoming_actions]

		if self.list_name == 'AnimeList':
			# Depuis la v1.3.6, la racine Animés japonais sert uniquement de porte d'entrée.
			# Les accès séries/films restent disponibles dans leurs sous-dossiers dédiés.
			def _is_legacy_anime_root_item(item):
				mode = item.get('mode', '')
				action = item.get('action', '')
				if mode in ('build_anime_calendar', 'catalogue.native_anime_groups', 'catalogue.native_anime_year_groups', 'catalogue.native_anime_provider_groups'):
					return True
				if mode in ('navigator.anime_genres', 'navigator.anime_years'):
					return True
				if mode == 'build_tvshow_list' and action.startswith(('tmdb_tvanime_', 'trakt_tvanime_')):
					return True
				if mode == 'build_movie_list' and action.startswith(('tmdb_moviesanime_', 'trakt_moviesanime_')):
					return True
				return False
			contents = [i for i in contents if not _is_legacy_anime_root_item(i)]

		# Ajoute « Vos visionnages en cours » dans le menu Séries même si l'ancien menu est déjà en cache.
		if self.list_name == 'TVShowList' and not any(i.get('action') == 'trakt_in_progress_tvshows' for i in contents):
			contents = list(contents)
			new_item = {'name': 33122, 'iconImage': 'in_progress_tvshow.png', 'mode': 'build_tvshow_list', 'action': 'trakt_in_progress_tvshows', 'hide_watched_items': 'true'}
			insert_at = len(contents)
			for idx, item in enumerate(contents):
				if item.get('action') == 'in_progress_tvshows':
					insert_at = idx + 1
					break
			contents.insert(insert_at, new_item)
		if self.list_name == 'RootList':
			contents = [i for i in contents if i.get('mode') != 'navigator.discover_main']
		add_items(handle, list(build_main_lists()))
		self._end_directory()

	def make_list_name(self, menu_type):
		return menu_type.replace('tvshow', tv_str).replace('movie', mov_str)

	def _add_item(self, url_params, iconImage='', prefix='', isFolder=True, list_name=''):
		handle, fanart = self.params_get('handle'), self.params_get('fanart')
		if not isFolder: url_params['isFolder'] = 'false'
		if iconImage in ('', 'None', None, 'DefaultFolder.png'): icon = media_path('myfolder.png')
		elif iconImage == 'alkoflix.png': icon = ku.get_addoninfo('icon')
		elif 'network_id' in url_params: icon = iconImage
		else: icon = media_path(iconImage)
		url_params['iconImage'] = icon
		url = build_url(url_params)
		listitem = make_listitem()
		listitem.setLabel(url_params['name'])
		listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon, 'landscape': icon})
		try:
			if isFolder and not str(url_params.get('mode', '')).startswith('menu_editor.'):
				cm = ku.menu_editor_context(url_params, url_params.get('name', ''), url_params.get('iconImage', ''), isFolder)
				if cm: listitem.addContextMenuItems(cm, replaceItems=False)
		except: pass
		add_item(handle, url, listitem, isFolder)

	def _end_directory(self):
		handle, fanart = self.params_get('handle'), self.params_get('fanart')
		set_category(handle, ls(self.params_get('name')))
		set_content(handle, '')
		end_directory(handle)
		set_view_mode('view.main', '')

