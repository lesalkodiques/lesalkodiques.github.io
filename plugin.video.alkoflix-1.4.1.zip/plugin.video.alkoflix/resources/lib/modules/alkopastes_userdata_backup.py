# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/alkopastes_userdata_backup.py

import base64
import gzip
import json
import re
import time
from datetime import datetime

import xbmcvfs

from modules import kodi_utils
from modules.alkopastes_backup import has_user_api_key, _request, _paste_code, _mask_code

PROFILE_DIR = 'special://profile/addon_data/plugin.video.alkoflix/'
BACKUP_SETTING = 'alkopastes.userdata_backup_code'
BACKUP_TYPE = 'alkoflix_userdata_backup'
BACKUP_VERSION = 1

# Fichiers restaurables : settings.xml + bases SQLite de userdata.
# Les caches temporaires, logs, QR et fichiers runtime non essentiels ne sont pas sauvegardés.
ALLOWED_EXACT = ('settings.xml',)
ALLOWED_SUFFIX = ('.db',)
EXCLUDED_SUFFIX = ('-journal', '-wal', '-shm')

# Réglages propres à une autorisation de compte/appareil.
# Ils sont retirés lors d'une restauration « sans autorisations » pour éviter de cloner
# un token Trakt/Débrideur/etc. sur un autre profil Kodi.
AUTH_SETTING_DEFAULTS = {
	# Trakt / indicateurs de visionnage
	'trakt_user': '',
	'trakt.token': '',
	'trakt.refresh': '',
	'trakt.expires': '',
	'trakt_indicators_active': 'false',
	'watched_indicators': '0',

	# MDBList
	'mdblist_user': '',
	'mdblist.token': '',
	'mdbl_indicators_active': 'false',

	# TMDb List / session TMDb utilisateur
	'tmdb.username': '',
	'tmdb.token': '',
	'tmdb.account_id': '',
	'tmdb.session_id': '',
	'tmdb.session_account_id': '',

	# alkoPastes est conservé volontairement.
	# Sa clé API sert à retrouver les sauvegardes/favoris/pastes privés de l'utilisateur ;
	# elle n'est pas une autorisation Trakt/Débrideur propre à un appareil Kodi.

	# Débrideurs / services de liens
	'ad.account_id': '',
	'ad.token': '',
	'rd.username': '',
	'rd.client_id': '',
	'rd.secret': '',
	'rd.refresh': '',
	'rd.token': '',
	'pm.account_id': '',
	'pm.token': '',
	'tb.account_id': '',
	'tb.token': '',
	'oc.account_id': '',
	'oc.token': '',
	'ed.account_id': '',
	'ed.token': '',
	'easynews_user': '',
	'easynews_password': '',
	'provider.easynews': 'false',

	# Clés API personnelles facultatives
	'tmdb.use_own_key': 'false',
	'tmdb_api_user': '',
	'rpdb_api_key': '',
	'subtitles.apikey': '',
	'fanart_client_key_user': '',
	'imdb_user': ''
}


def _request_userdata(method, action, payload=None, params=None, timeout=60.0):
	return _request(method, action, payload=payload, params=params, timeout=timeout, log_name='alkoPastes userdata request')


def _ensure_alkopastes_connected():
	if has_user_api_key(): return True
	text = ('alkoPastes n’est pas connecté.[CR][CR]'
		'Connectez votre clé API dans [B]Mes services[/B] pour utiliser la sauvegarde/restauration alkoFlix.')
	if kodi_utils.confirm_dialog(text=text, ok_label='Mes services', cancel_label='Annuler', top_space=True):
		kodi_utils.execute_builtin('RunPlugin(plugin://plugin.video.alkoflix/?mode=myservices)')
	return False


def _is_backup_file(filename):
	name = str(filename or '')
	lower = name.lower()
	if not name or '/' in name or '\\' in name: return False
	if any(lower.endswith(suffix) for suffix in EXCLUDED_SUFFIX): return False
	if lower in ALLOWED_EXACT: return True
	return any(lower.endswith(suffix) for suffix in ALLOWED_SUFFIX)


def _read_binary(path):
	reader = xbmcvfs.File(path, 'rb')
	try:
		data = reader.readBytes()
	finally:
		reader.close()
	if isinstance(data, bytes): return data
	try: return bytes(data)
	except Exception: return str(data).encode('utf-8')


def _settings_line_id(line):
	match = re.search(r'id=[\"\']([^\"\']+)[\"\']', line)
	return match.group(1) if match else ''


def _replace_settings_value(line, value):
	if ' value=' in line:
		return re.sub(r'value=([\"\'])(.*?)\1', lambda match: 'value=%s%s%s' % (match.group(1), value, match.group(1)), line, count=1)
	if '</setting>' in line:
		return re.sub(r'>(.*?)</setting>', '>%s</setting>' % value, line, count=1)
	return line


def _sanitize_settings_xml(data):
	try:
		text = data.decode('utf-8-sig')
	except Exception:
		try: text = data.decode('utf-8')
		except Exception: return data, 0

	changed = 0
	new_lines = []
	for line in text.splitlines(True):
		setting_id = _settings_line_id(line)
		if setting_id in AUTH_SETTING_DEFAULTS:
			updated = _replace_settings_value(line, AUTH_SETTING_DEFAULTS[setting_id])
			if updated != line: changed += 1
			line = updated
		new_lines.append(line)

	return ''.join(new_lines).encode('utf-8'), changed


def _write_binary(path, data):
	writer = xbmcvfs.File(path, 'wb')
	try:
		writer.write(data)
	finally:
		writer.close()
	return kodi_utils.path_exists(path)


def _collect_files():
	try:
		_, files = kodi_utils.list_dirs(PROFILE_DIR)
	except Exception:
		files = []
	items = []
	for filename in sorted(files):
		if not _is_backup_file(filename): continue
		path = PROFILE_DIR + filename
		try:
			data = _read_binary(path)
		except Exception as exc:
			kodi_utils.logger('alkoPastes userdata backup read skipped', '%s | %s' % (filename, exc))
			continue
		items.append({
			'name': filename,
			'size': len(data),
			'encoding': 'base64+gzip',
			'data': base64.b64encode(gzip.compress(data)).decode('ascii')
		})
	kodi_utils.logger('alkoPastes userdata backup collect', 'files=%s | names=%s' % (len(items), ','.join([item.get('name', '') for item in items]) or 'none'))
	return items


def _build_backup_payload():
	files = _collect_files()
	return {
		'type': BACKUP_TYPE,
		'version': BACKUP_VERSION,
		'addon': 'plugin.video.alkoflix',
		'addon_version': kodi_utils.get_addoninfo('version'),
		'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
		'files': files
	}


def _save_backup_paste(content):
	code = str(kodi_utils.get_setting(BACKUP_SETTING, '')).strip()
	title = 'Sauvegarde alkoFlix userdata - %s' % datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	payload = {'title': title, 'content': content, 'syntax': 'json', 'visibility': 'private', 'expiry': 'NULL'}
	kodi_utils.logger('alkoPastes userdata backup save', 'START | cached=%s | content_len=%s | title=%s' % (_mask_code(code), len(str(content or '')), title))
	created_new = False
	try:
		if code:
			result = _request_userdata('POST', 'update', payload=payload, params={'id': code}, timeout=60.0)
		else:
			result = _request_userdata('POST', 'paste', payload=payload, timeout=60.0)
			created_new = True
	except Exception as exc:
		# Si un ancien code est invalide, on crée une nouvelle sauvegarde propre.
		if not code: raise
		kodi_utils.logger('alkoPastes userdata backup update failed', '%s | recreate | %s' % (_mask_code(code), exc))
		result = _request_userdata('POST', 'paste', payload=payload, timeout=60.0)
		created_new = True
	new_code = _paste_code(result, code)
	kodi_utils.logger('alkoPastes userdata backup save', 'RESULT | old=%s | new=%s | created_new=%s' % (_mask_code(code), _mask_code(new_code), created_new))
	if new_code:
		kodi_utils.set_setting(BACKUP_SETTING, new_code)
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.logger('alkoPastes userdata backup setting', '%s | %s' % ('updated' if new_code != code else 'unchanged', _mask_code(new_code)))
	return new_code


def backup_alkoflix_userdata():
	if not _ensure_alkopastes_connected(): return
	text = ('Cette sauvegarde enverra vers votre compte alkoPastes un paste privé contenant :[CR][CR]'
		'- settings.xml[CR]'
		'- les bases SQLite alkoFlix (.db)[CR][CR]'
		'Attention : settings.xml peut contenir des clés API ou tokens de services connectés.[CR][CR]'
		'Lors de la restauration, alkoFlix pourra retirer ces autorisations pour éviter de les cloner sur un autre appareil.[CR][CR]'
		'Continuer ?')
	if not kodi_utils.confirm_dialog(text=text, ok_label='Sauvegarder', cancel_label='Annuler', top_space=True): return
	kodi_utils.show_busy_dialog()
	try:
		payload = _build_backup_payload()
		if not payload.get('files'):
			kodi_utils.hide_busy_dialog()
			return kodi_utils.ok_dialog(text='Aucun fichier alkoFlix à sauvegarder.', top_space=True)
		content = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
		kodi_utils.logger('alkoPastes userdata backup payload', 'files=%s | content_len=%s' % (len(payload.get('files') or []), len(content)))
		code = _save_backup_paste(content)
		kodi_utils.hide_busy_dialog()
		message = ('Sauvegarde alkoFlix terminée.[CR][CR]'
			'Code : [B]%s[/B][CR]'
			'Fichiers sauvegardés : [B]%s[/B]') % (code or 'inconnu', len(payload.get('files') or []))
		return kodi_utils.ok_dialog(text=message, top_space=True)
	except Exception as exc:
		kodi_utils.hide_busy_dialog()
		kodi_utils.logger('alkoPastes userdata backup error', '%s: %s' % (type(exc).__name__, exc))
		return kodi_utils.ok_dialog(text='Erreur pendant la sauvegarde alkoPastes.[CR][CR]%s' % exc, top_space=True)


def _auto_backup_interval_seconds():
	value = kodi_utils.get_setting('alkopastes.userdata_auto_backup_interval', '0') or '0'
	value = str(value).strip()
	label_map = {
		'0': 0,
		'chaque jour': 0,
		'tous les 3 jours': 1,
		'1': 1,
		'chaque semaine': 2,
		'2': 2,
	}
	index = label_map.get(value.lower(), 0)
	return {0: 86400, 1: 259200, 2: 604800}.get(index, 86400)


def automatic_alkoflix_userdata_backup(force=False):
	if not force and kodi_utils.get_setting('alkopastes.userdata_auto_backup', 'false') != 'true': return 'disabled'
	current_time = int(time.time())
	interval = _auto_backup_interval_seconds()
	try: due_time = int(kodi_utils.get_setting('alkopastes.userdata_auto_backup_due', '0') or 0)
	except Exception: due_time = 0
	if not force and current_time < due_time: return 'not needed'
	if not has_user_api_key():
		# Évite de relancer la vérification à chaque boucle si alkoPastes n'est pas connecté.
		kodi_utils.set_setting('alkopastes.userdata_auto_backup_due', str(current_time + 3600))
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.logger('alkoPastes automatic userdata backup skipped', 'alkoPastes not connected')
		return 'no account'
	try:
		payload = _build_backup_payload()
		if not payload.get('files'):
			kodi_utils.set_setting('alkopastes.userdata_auto_backup_due', str(current_time + 3600))
			kodi_utils.clear_property('alkoflix_settings')
			kodi_utils.logger('alkoPastes automatic userdata backup skipped', 'no userdata files')
			return 'empty'
		content = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
		kodi_utils.logger('alkoPastes userdata backup payload', 'files=%s | content_len=%s' % (len(payload.get('files') or []), len(content)))
		code = _save_backup_paste(content)
		kodi_utils.set_setting('alkopastes.userdata_auto_backup_due', str(current_time + interval))
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.logger('alkoPastes automatic userdata backup success', 'code=%s files=%s next=%s' % (code or 'unknown', len(payload.get('files') or []), current_time + interval))
		return 'success'
	except Exception as exc:
		# En cas d'erreur réseau/API, on réessaie plus tard sans harceler le service.
		kodi_utils.set_setting('alkopastes.userdata_auto_backup_due', str(current_time + 3600))
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.logger('alkoPastes automatic userdata backup failed', '%s: %s' % (type(exc).__name__, exc))
		return 'failed'


def _get_backup_content(code):
	kodi_utils.logger('alkoPastes userdata restore get', 'START | code=%s' % _mask_code(code))
	result = _request_userdata('GET', 'get', params={'id': code}, timeout=60.0)
	paste = result.get('paste') or {}
	content = paste.get('content') or ''
	if isinstance(content, (dict, list)):
		content = json.dumps(content, ensure_ascii=False)
	else:
		content = str(content or '')
	kodi_utils.logger('alkoPastes userdata restore get', 'OK | code=%s | content_len=%s | title=%s' % (_mask_code(code), len(content), str(paste.get('title') or '')[:80]))
	return content


def _parse_backup(content):
	data = json.loads(content)
	if data.get('type') != BACKUP_TYPE:
		raise Exception('Le paste indiqué n’est pas une sauvegarde userdata alkoFlix valide.')
	kodi_utils.logger('alkoPastes userdata restore parse', 'OK | version=%s | files=%s | created=%s' % (data.get('version'), len(data.get('files') or []), data.get('created') or ''))
	return data


def _restore_files(data, restore_authorizations=False):
	files = data.get('files') or []
	if not kodi_utils.path_exists(PROFILE_DIR): kodi_utils.make_directorys(PROFILE_DIR)
	count, sanitized = 0, 0
	for item in files:
		filename = item.get('name')
		if not _is_backup_file(filename): continue
		raw = base64.b64decode(item.get('data') or '')
		if item.get('encoding') == 'base64+gzip': raw = gzip.decompress(raw)
		if filename == 'settings.xml' and not restore_authorizations:
			raw, sanitized = _sanitize_settings_xml(raw)
		if _write_binary(PROFILE_DIR + filename, raw):
			count += 1
			kodi_utils.logger('alkoPastes userdata restore write', 'OK | %s | bytes=%s' % (filename, len(raw)))
		else:
			kodi_utils.logger('alkoPastes userdata restore write', 'FAIL | %s' % filename)
	kodi_utils.logger('alkoPastes userdata restore write', 'DONE | restored=%s | received=%s | restore_auth=%s | sanitized_settings=%s' % (count, len(files), restore_authorizations, sanitized))
	return count, sanitized


def restore_alkoflix_userdata():
	if not _ensure_alkopastes_connected(): return
	code = str(kodi_utils.get_setting(BACKUP_SETTING, '')).strip()
	if not code:
		code = kodi_utils.dialog.input('Code de sauvegarde alkoPastes :')
		if not code: return
		kodi_utils.set_setting(BACKUP_SETTING, code.strip())
		kodi_utils.clear_property('alkoflix_settings')
	text = ('Cette restauration remplacera les settings et bases locales alkoFlix par ceux de la sauvegarde.[CR][CR]'
		'Code : [B]%s[/B][CR][CR]'
		'Un redémarrage de Kodi est recommandé après la restauration.[CR][CR]'
		'Continuer ?') % _mask_code(code)
	if not kodi_utils.confirm_dialog(text=text, ok_label='Restaurer', cancel_label='Annuler', top_space=True): return

	choice = kodi_utils.dialog.select('Restauration alkoFlix', [
		'Restaurer sans autorisations de comptes (recommandé)',
		'Tout restaurer, incluant les autorisations'
	])
	if choice < 0: return
	restore_authorizations = choice == 1
	if restore_authorizations:
		warning = ('À utiliser seulement pour restaurer le même profil Kodi sur le même appareil.[CR][CR]'
			'Restaurer les autorisations peut cloner des tokens Trakt, débrideurs, TMDb, MDBList, alkoPastes, etc.[CR][CR]'
			'Sur un autre appareil, choisissez plutôt une restauration sans autorisations.')
		if not kodi_utils.confirm_dialog(text=warning, ok_label='Tout restaurer', cancel_label='Annuler', top_space=True): return

	kodi_utils.show_busy_dialog()
	try:
		data = _parse_backup(_get_backup_content(code))
		count, sanitized = _restore_files(data, restore_authorizations=restore_authorizations)
		kodi_utils.clear_property('alkoflix_settings')
		kodi_utils.hide_busy_dialog()
		mode = 'avec autorisations' if restore_authorizations else 'sans autorisations'
		extra = '' if restore_authorizations else '[CR]Autorisations retirées : [B]%s[/B][CR]' % sanitized
		message = ('Restauration alkoFlix terminée ([B]%s[/B]).[CR][CR]'
			'Fichiers restaurés : [B]%s[/B]%s[CR]'
			'Voulez-vous redémarrer Kodi maintenant ?') % (mode, count, extra)
		if kodi_utils.confirm_dialog(text=message, ok_label='Redémarrer', cancel_label='Plus tard', top_space=True):
			kodi_utils.execute_builtin('RestartApp')
		return
	except Exception as exc:
		kodi_utils.hide_busy_dialog()
		kodi_utils.logger('alkoPastes userdata restore error', '%s: %s' % (type(exc).__name__, exc))
		return kodi_utils.ok_dialog(text='Erreur pendant la restauration alkoPastes.[CR][CR]%s' % exc, top_space=True)
