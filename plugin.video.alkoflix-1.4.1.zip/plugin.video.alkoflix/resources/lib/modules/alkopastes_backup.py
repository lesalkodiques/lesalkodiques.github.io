# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/alkopastes_backup.py

import json
import sys
import time
from datetime import datetime
from urllib.parse import quote, unquote

from modules import kodi_utils
from caches.favourites_cache import (
	favourites_cache,
	MOVIE_FAVOURITE_TYPES,
	TV_FAVOURITE_TYPES,
	SEASON_FAVOURITE_TYPES,
	EPISODE_FAVOURITE_TYPES,
	COLLECTION_FAVOURITE_TYPES,
	LIST_FAVOURITE_TYPES
)

get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting
logger = kodi_utils.logger

API_URL = 'https://paste.lesalkodiques.com/api.php'
BACKUP_SETTING = 'alkopastes.favourites_backup_code'
SYNC_SETTING = 'alkopastes.favourites_sync_enabled'
AUTO_RESTORE_SETTING = 'alkopastes.favourites_auto_restore_enabled'
AUTO_RESTORE_INTERVAL_SETTING = 'alkopastes.favourites_auto_restore_interval'
AUTO_RESTORE_DUE_SETTING = 'alkopastes.favourites_auto_restore_due'
BACKUP_TITLE = 'alkoFlix favoris - sauvegarde'
BACKUP_VERSION = 3

# Les favoris restent la source locale principale dans favourites.db.
# alkoPastes sert uniquement de miroir optionnel, avec un seul paste privé caché.
FAVOURITE_COUNT_GROUPS = {
	'movies': MOVIE_FAVOURITE_TYPES,
	'tvshows': TV_FAVOURITE_TYPES,
	'seasons': SEASON_FAVOURITE_TYPES,
	'episodes': EPISODE_FAVOURITE_TYPES,
	'people': ('person',),
	'lists': LIST_FAVOURITE_TYPES,
	'collections': COLLECTION_FAVOURITE_TYPES
}

ALL_BACKUP_TYPES = tuple(dict.fromkeys(
	MOVIE_FAVOURITE_TYPES + TV_FAVOURITE_TYPES + SEASON_FAVOURITE_TYPES + EPISODE_FAVOURITE_TYPES + ('person',) + LIST_FAVOURITE_TYPES + COLLECTION_FAVOURITE_TYPES
))

# Anciens champs invisibles issus du système à plusieurs codes paste.
# Ils ne sont plus utilisés et sont vidés automatiquement quand le backup unique est créé/mis à jour.
OBSOLETE_FAVOURITE_BACKUP_SETTINGS = (
	'alkopastes.favourites_movies_code',
	'alkopastes.favourites_tvshows_code',
	'alkopastes.favourites_seasons_code',
	'alkopastes.favourites_episodes_code',
	'alkopastes.favourites_people_code',
	'alkopastes.favourites_collections_code'
)


def has_user_api_key():
	try: return bool(str(get_setting('alkopastes.api_key_user', '')).strip())
	except Exception: return False


def api_key():
	return str(get_setting('alkopastes.api_key_user', '')).strip()


def favourites_sync_enabled():
	try: return str(get_setting(SYNC_SETTING, 'false')).lower() == 'true'
	except Exception: return False


def _backup_code():
	return str(get_setting(BACKUP_SETTING, '')).strip()


def codes_configured():
	return bool(_backup_code())


def core_codes_configured():
	# Compatibilité avec les anciens appels internes : aucun code n'est saisi par l'utilisateur.
	return codes_configured()


def _headers():
	return {
		'X-API-Key': api_key(),
		'Content-Type': 'application/json',
		'User-Agent': 'alkoFlix/%s' % kodi_utils.get_addoninfo('version')
	}


def _mask_code(code):
	code = str(code or '').strip()
	if not code: return ''
	if len(code) <= 6: return code[:2] + '***'
	return code[:3] + '***' + code[-3:]


def _translated_path(path):
	try: return kodi_utils.translate_path(path)
	except Exception: return str(path or '')


def _debug_context(action):
	try:
		logger('alkoPastes favourites debug', '%s | addon=%s | platform=%s | db_path=%s | backup=%s | api_key=%s | sync=%s' % (
			action,
			kodi_utils.get_addoninfo('version'),
			sys.platform,
			_translated_path(getattr(favourites_cache, 'db_file', '')),
			_mask_code(_backup_code()) or 'empty',
			'yes' if has_user_api_key() else 'no',
			'yes' if favourites_sync_enabled() else 'no'
		))
	except Exception as exc:
		logger('alkoPastes favourites debug failed', '%s | %s: %s' % (action, type(exc).__name__, exc))


def _request(method, action, payload=None, params=None, timeout=30.0, log_name='alkoPastes favourites request'):
	import requests
	params = dict(params or {})
	params['action'] = action
	safe_params = dict(params)
	if 'api_key' in safe_params: safe_params['api_key'] = '***'
	if 'id' in safe_params: safe_params['id'] = _mask_code(safe_params.get('id'))
	if 'p_code' in safe_params: safe_params['p_code'] = _mask_code(safe_params.get('p_code'))
	if 'slug' in safe_params: safe_params['slug'] = _mask_code(safe_params.get('slug'))
	payload_keys = sorted(list((payload or {}).keys())) if isinstance(payload, dict) else []
	logger(log_name, 'START | method=%s | action=%s | params=%s | payload_keys=%s' % (method, action, safe_params, payload_keys))
	if method == 'GET':
		response = requests.get(API_URL, params=params, headers=_headers(), timeout=timeout)
	elif method == 'POST':
		response = requests.post(API_URL, params=params, data=json.dumps(payload or {}, ensure_ascii=False).encode('utf-8'), headers=_headers(), timeout=timeout)
	else:
		response = requests.delete(API_URL, params=params, headers=_headers(), timeout=timeout)
	try: data = response.json()
	except Exception:
		data = {'success': False, 'error': response.text[:500] if hasattr(response, 'text') else 'Réponse invalide'}
	if response.status_code not in (200, 201) or not data.get('success'):
		error = data.get('error') or data.get('message') or 'Erreur HTTP %s' % response.status_code
		logger(log_name, 'FAIL | method=%s | action=%s | status=%s | error=%s' % (method, action, response.status_code, error))
		raise Exception(error)
	logger(log_name, 'OK | method=%s | action=%s | status=%s | keys=%s' % (method, action, response.status_code, sorted(list(data.keys()))))
	return data


def _safe_text(value):
	value = str(value or '')
	return value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').strip()


def _encode(value):
	return quote(_safe_text(value), safe='')


def _decode(value):
	try: return unquote(str(value or ''))
	except Exception: return str(value or '')


def _summary_code(paste):
	paste = paste or {}
	return str(paste.get('slug') or paste.get('p_code') or paste.get('id') or '').strip()


def _paste_code(result, previous_code=''):
	paste = (result or {}).get('paste') or {}
	return _summary_code(paste) or str(previous_code or '').strip()


def _refresh_settings_cache():
	try: kodi_utils.clear_property('alkoflix_settings')
	except Exception: pass


def _set_backup_code(code):
	code = str(code or '').strip()
	old_code = _backup_code()
	set_setting(BACKUP_SETTING, code)
	_refresh_settings_cache()
	if old_code != code:
		logger('alkoPastes favourites backup setting', 'changed | %s -> %s' % (_mask_code(old_code), _mask_code(code)))
	else:
		logger('alkoPastes favourites backup setting', 'unchanged | %s' % (_mask_code(code) or 'empty'))
	return code


def _clear_obsolete_backup_settings(reason=''):
	cleared = []
	for setting_id in OBSOLETE_FAVOURITE_BACKUP_SETTINGS:
		try:
			if str(get_setting(setting_id, '')).strip():
				set_setting(setting_id, '')
				cleared.append(setting_id)
		except Exception:
			pass
	if cleared:
		_refresh_settings_cache()
		logger('alkoPastes favourites obsolete settings cleared', '%s | %s' % (reason or 'cleanup', ', '.join(cleared)))
	return cleared


def _delete_backup_paste(code, reason=''):
	code = str(code or '').strip()
	if not code: return False
	try:
		_request('DELETE', 'delete', params={'id': code})
		logger('alkoPastes favourites backup delete', 'OK | %s | %s' % (_mask_code(code), reason or 'cleanup'))
		return True
	except Exception as exc:
		logger('alkoPastes favourites backup delete failed', '%s | %s | %s' % (_mask_code(code), reason or 'cleanup', exc))
		return False


def _raw_favourites_rows(favourite_types=None):
	try: favourites_cache._ensure_schema()
	except Exception as exc: logger('alkoPastes favourites backup schema failed', '%s: %s' % (type(exc).__name__, exc))
	favourite_types = tuple(favourite_types or ALL_BACKUP_TYPES)
	if not favourite_types: return []
	try:
		placeholders = ','.join('?' for _ in favourite_types)
		favourites_cache.dbcur.execute("""SELECT db_type, tmdb_id, title, added_at FROM favourites WHERE db_type IN (%s) ORDER BY db_type, title COLLATE NOCASE, tmdb_id""" % placeholders, favourite_types)
		return favourites_cache.dbcur.fetchall() or []
	except Exception as exc:
		logger('alkoPastes favourites backup rows failed', 'types=%s | %s: %s' % (','.join(favourite_types), type(exc).__name__, exc))
		return []


def _build_backup_text(favourite_types=None, header_only=False):
	lines = [
		'# alkoFlix favourites backup',
		'# version: %s' % BACKUP_VERSION,
		'# created: %s' % datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
		'db_type\ttmdb_id\ttitle\tadded_at'
	]
	if header_only: return '\n'.join(lines) + '\n'
	for db_type, tmdb_id, title, added_at in _raw_favourites_rows(favourite_types or ALL_BACKUP_TYPES):
		tmdb_id = _safe_text(tmdb_id)
		if not tmdb_id: continue
		lines.append('%s\t%s\t%s\t%s' % (db_type, _encode(tmdb_id), _encode(title), _encode(added_at)))
	return '\n'.join(lines) + '\n'


def _backup_items_count(favourite_types):
	count = 0
	for row in _raw_favourites_rows(favourite_types):
		try:
			if _safe_text(row[1]): count += 1
		except Exception: pass
	return count


def _backup_counts():
	return {group: _backup_items_count(types) for group, types in FAVOURITE_COUNT_GROUPS.items()}


def _parse_backup_text(text):
	items = []
	if not text:
		logger('alkoPastes favourites backup parse', 'empty content')
		return items
	for raw_line in str(text).splitlines():
		line = raw_line.strip('\ufeff').strip()
		if not line or line.startswith('#'): continue
		parts = line.split('\t')
		if parts and parts[0] == 'db_type': continue
		if len(parts) < 3: continue
		db_type = _safe_text(parts[0])
		tmdb_id = _decode(parts[1])
		title = _decode(parts[2])
		added_at = _decode(parts[3]) if len(parts) > 3 else ''
		if db_type and tmdb_id:
			items.append({'db_type': db_type, 'tmdb_id': tmdb_id, 'title': title, 'added_at': added_at})
	logger('alkoPastes favourites backup parse', 'content_len=%s | items=%s' % (len(str(text)), len(items)))
	return items


def _get_paste_content(code):
	logger('alkoPastes favourites backup get', 'START | code=%s' % _mask_code(code))
	result = _request('GET', 'get', params={'id': code})
	paste = result.get('paste') or {}
	content = paste.get('content') or ''
	if isinstance(content, (dict, list)): content = json.dumps(content, ensure_ascii=False)
	logger('alkoPastes favourites backup get', 'OK | code=%s | content_len=%s | title=%s' % (_mask_code(code), len(str(content)), str(paste.get('title') or '')[:80]))
	return content


def _matches_backup_title(paste):
	title = str((paste or {}).get('title') or '').strip()
	return title == BACKUP_TITLE or title.startswith(BACKUP_TITLE)


def _find_backup_code():
	logger('alkoPastes favourites backup find', 'START | cached=%s | title=%s' % (_mask_code(_backup_code()), BACKUP_TITLE))
	for page in range(1, 6):
		try:
			result = _request('GET', 'list', params={'page': page, 'limit': 100})
		except Exception as exc:
			logger('alkoPastes favourites backup list failed', 'page=%s | %s' % (page, exc))
			break
		pastes = result.get('pastes') or []
		logger('alkoPastes favourites backup find', 'list page=%s | pastes=%s' % (page, len(pastes)))
		for paste in pastes:
			if not _matches_backup_title(paste): continue
			code = _summary_code(paste)
			if code:
				_set_backup_code(code)
				logger('alkoPastes favourites backup found', 'list | single=%s | page=%s' % (_mask_code(code), page))
				return code
		pagination = result.get('pagination') or {}
		try: pages = int(pagination.get('pages') or 0)
		except Exception: pages = 0
		if not pastes or (pages and page >= pages): break

	for query in (BACKUP_TITLE, 'alkoFlix favoris'):
		try:
			result = _request('GET', 'search', params={'q': query, 'limit': 50})
		except Exception as exc:
			logger('alkoPastes favourites backup search failed', '%s | %s' % (query, exc))
			continue
		search_pastes = result.get('pastes') or []
		logger('alkoPastes favourites backup find', 'search query=%s | pastes=%s' % (query, len(search_pastes)))
		for paste in search_pastes:
			if not _matches_backup_title(paste): continue
			code = _summary_code(paste)
			if code:
				_set_backup_code(code)
				logger('alkoPastes favourites backup found', 'search | single=%s | query=%s' % (_mask_code(code), query))
				return code
	logger('alkoPastes favourites backup find', 'MISS | no matching private backup found')
	return ''


def _save_single_backup(content):
	old_code = _backup_code()
	logger('alkoPastes favourites backup save', 'START | cached=%s | content_len=%s' % (_mask_code(old_code), len(str(content or ''))))
	code = old_code or _find_backup_code()
	payload = {'title': BACKUP_TITLE, 'content': content, 'syntax': 'text', 'visibility': 'private', 'expiry': 'NULL'}
	created_new = False
	if code:
		try:
			result = _request('POST', 'update', payload=payload, params={'id': code})
		except Exception as exc:
			logger('alkoPastes favourites backup update failed', '%s | recreate | %s' % (_mask_code(code), exc))
			result = _request('POST', 'paste', payload=payload)
			created_new = True
	else:
		result = _request('POST', 'paste', payload=payload)
		created_new = True
	new_code = _paste_code(result, code)
	logger('alkoPastes favourites backup save', 'RESULT | old=%s | target=%s | new=%s | created_new=%s' % (_mask_code(old_code), _mask_code(code), _mask_code(new_code), created_new))
	if new_code:
		_set_backup_code(new_code)
		_clear_obsolete_backup_settings('single=%s' % _mask_code(new_code))
		if created_new and code and new_code != code:
			_delete_backup_paste(code, 'replaced_by=%s' % _mask_code(new_code))
	return new_code


def ensure_backup_pastes(header_only=True, dynamic_only=True, force=False):
	# Ancienne entrée interne conservée pour compatibilité ; elle écrit maintenant le backup unique.
	_debug_context('ensure start | header_only=%s | dynamic_only=%s' % (header_only, dynamic_only))
	if not has_user_api_key():
		logger('alkoPastes favourites backup ensure', 'SKIP | not_authorized')
		return {'success': False, 'provider': 'alkoPastes', 'error': 'not_authorized'}
	if not force and not favourites_sync_enabled():
		logger('alkoPastes favourites backup ensure', 'SKIP | sync_disabled')
		return {'success': False, 'provider': 'alkoPastes', 'error': 'sync_disabled'}
	content = _build_backup_text(ALL_BACKUP_TYPES, header_only=header_only)
	code = _save_single_backup(content)
	logger('alkoPastes favourites backup ensure', 'OK | single=%s' % (_mask_code(code) or ''))
	return {'success': True, 'provider': 'alkoPastes', 'code': code, 'counts': _backup_counts()}


def _normal_excluded_keys(excluded_keys=None):
	keys = set()
	for item in excluded_keys or ():
		try:
			db_type, tmdb_id = item
		except Exception:
			continue
		db_type = _safe_text(db_type)
		tmdb_id = _safe_text(tmdb_id)
		if db_type and tmdb_id: keys.add((db_type, tmdb_id))
	return keys


def _merge_remote_favourites_into_local(excluded_types=None, excluded_keys=None):
	# Avant d'écrire le paste, on récupère d'abord son contenu pour éviter qu'un
	# appareil avec une base locale incomplète écrase les favoris ajoutés ailleurs.
	excluded_types = set(str(i or '').strip() for i in (excluded_types or ()) if str(i or '').strip())
	excluded_keys = _normal_excluded_keys(excluded_keys)
	code = _backup_code() or _find_backup_code()
	if not code:
		logger('alkoPastes favourites backup merge', 'SKIP | no remote backup')
		return 0
	try:
		items = _parse_backup_text(_get_paste_content(code))
	except Exception as exc:
		logger('alkoPastes favourites backup merge failed', '%s | %s' % (_mask_code(code), exc))
		return 0
	if excluded_types or excluded_keys:
		filtered = []
		for item in items:
			db_type = _safe_text(item.get('db_type'))
			tmdb_id = _safe_text(item.get('tmdb_id'))
			if db_type in excluded_types: continue
			if (db_type, tmdb_id) in excluded_keys: continue
			filtered.append(item)
		items = filtered
	count = _import_items(items, ALL_BACKUP_TYPES)
	logger('alkoPastes favourites backup merge', 'DONE | single=%s | merged=%s | excluded_types=%s | excluded_keys=%s' % (_mask_code(code), count, len(excluded_types), len(excluded_keys)))
	return count


def export_local_favourites_to_alkopastes(force=False, merge_remote=True, excluded_types=None, excluded_keys=None):
	_debug_context('export start')
	if not has_user_api_key():
		logger('alkoPastes favourites backup export', 'SKIP | not_authorized')
		return {'success': False, 'provider': 'alkoPastes', 'error': 'not_authorized'}
	if not force and not favourites_sync_enabled():
		logger('alkoPastes favourites backup export', 'SKIP | sync_disabled')
		return {'success': False, 'provider': 'alkoPastes', 'error': 'sync_disabled'}
	merged = 0
	if merge_remote:
		merged = _merge_remote_favourites_into_local(excluded_types=excluded_types, excluded_keys=excluded_keys)
	counts = _backup_counts()
	content = _build_backup_text(ALL_BACKUP_TYPES, header_only=False)
	code = _save_single_backup(content)
	logger('alkoPastes favourites backup export', 'OK | single=%s | merged=%s | %s' % (_mask_code(code) or '', merged, counts))
	return {'success': True, 'provider': 'alkoPastes', 'counts': counts, 'code': code, 'merged': merged}


def _import_items(items, allowed_types=None):
	allowed = set(allowed_types or ALL_BACKUP_TYPES)
	count = 0
	skipped = 0
	for item in items or []:
		if item.get('db_type') not in allowed:
			skipped += 1
			continue
		try:
			if favourites_cache.add_to_favourites_at(item.get('db_type'), item.get('tmdb_id'), item.get('title'), item.get('added_at')):
				count += 1
		except Exception as exc:
			logger('alkoPastes favourites backup import item failed', '%s | %s' % (item, exc))
	logger('alkoPastes favourites backup import items', 'DONE | imported=%s | skipped=%s | received=%s' % (count, skipped, len(items or [])))
	return count


def _import_single_backup(code):
	logger('alkoPastes favourites backup import', 'START | single=%s' % _mask_code(code))
	items = _parse_backup_text(_get_paste_content(code))
	count = _import_items(items, ALL_BACKUP_TYPES)
	logger('alkoPastes favourites backup import', 'OK | single=%s | imported=%s' % (_mask_code(code), count))
	return {'success': True, 'provider': 'alkoPastes', 'count': count, 'code': code}


def import_alkopastes_favourites():
	_debug_context('import start')
	if not has_user_api_key():
		logger('alkoPastes favourites backup import', 'SKIP | not_authorized')
		return {'success': False, 'provider': 'alkoPastes', 'count': 0, 'error': 'not_authorized'}
	code = _backup_code()
	logger('alkoPastes favourites backup import', 'cached code | %s' % (_mask_code(code) or 'empty'))
	if code:
		try: return _import_single_backup(code)
		except Exception as exc:
			logger('alkoPastes favourites backup import cached code failed', '%s | %s' % (_mask_code(code), exc))
			try: _set_backup_code('')
			except Exception: pass
	code = _find_backup_code()
	if code:
		try: return _import_single_backup(code)
		except Exception as exc:
			logger('alkoPastes favourites backup import searched code failed', '%s | %s' % (_mask_code(code), exc))
	_clear_obsolete_backup_settings('missing_backup')
	logger('alkoPastes favourites backup import', 'No backup found | normal before first export | cached=%s' % (_mask_code(_backup_code()) or 'empty'))
	return {'success': False, 'provider': 'alkoPastes', 'count': 0, 'error': 'missing_backup'}


def _auto_restore_interval_seconds():
	value = str(get_setting(AUTO_RESTORE_INTERVAL_SETTING, '0') or '0').strip().lower()
	label_map = {
		'0': 0,
		'chaque jour': 0,
		'tous les 3 jours': 1,
		'1': 1,
		'tous les 7 jours': 2,
		'chaque semaine': 2,
		'2': 2
	}
	index = label_map.get(value, 0)
	return {0: 86400, 1: 259200, 2: 604800}.get(index, 86400)


def automatic_alkopastes_favourites_restore(force=False):
	if not force and str(get_setting(AUTO_RESTORE_SETTING, 'false')).lower() != 'true': return 'disabled'
	current_time = int(time.time())
	interval = _auto_restore_interval_seconds()
	try: due_time = int(get_setting(AUTO_RESTORE_DUE_SETTING, '0') or 0)
	except Exception: due_time = 0
	if not force and current_time < due_time: return 'not needed'
	if not has_user_api_key():
		set_setting(AUTO_RESTORE_DUE_SETTING, str(current_time + 3600))
		_refresh_settings_cache()
		logger('alkoPastes automatic favourites restore skipped', 'alkoPastes not connected')
		return 'no account'
	try:
		result = import_alkopastes_favourites()
		if result.get('success'):
			set_setting(AUTO_RESTORE_DUE_SETTING, str(current_time + interval))
			_refresh_settings_cache()
			logger('alkoPastes automatic favourites restore success', 'count=%s next=%s' % (result.get('count', 0), current_time + interval))
			return 'success'
		error = result.get('error') or 'unknown'
		next_try = current_time + (interval if error == 'missing_backup' else 3600)
		set_setting(AUTO_RESTORE_DUE_SETTING, str(next_try))
		_refresh_settings_cache()
		logger('alkoPastes automatic favourites restore skipped', '%s | next=%s' % (error, next_try))
		return error
	except Exception as exc:
		set_setting(AUTO_RESTORE_DUE_SETTING, str(current_time + 3600))
		_refresh_settings_cache()
		logger('alkoPastes automatic favourites restore failed', '%s: %s' % (type(exc).__name__, exc))
		return 'failed'
