# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/indexers/fanarttv_api.py
# © Les alKODIques

import requests
from urllib.parse import urlsplit, urlunsplit, quote
# from modules.kodi_utils import logger

# Clé API publique offerte par Les alKODIques.
API_KEY = '30006d06f4d124007f5de4f568bd7bca'
base_url = 'https://webservice.fanart.tv/v3.2/%s/%s'
default_fanart_meta = {'poster2': '', 'fanart2': '', 'banner': '', 'clearart': '', 'clearlogo': '', 'landscape': '', 'discart': '', 'fanart_added': True}
default_fanart_nometa = {'poster2': '', 'fanart2': '', 'banner': '', 'clearart': '', 'clearlogo': '', 'landscape': '', 'discart': '', 'fanart_added': False}
timeout = 3.05
session = requests.Session()
session.mount('https://webservice.fanart.tv', requests.adapters.HTTPAdapter(pool_maxsize=100))

# Nettoie et encode une URL d’image pour éviter les erreurs Kodi.
def clean_art_url(url):
	if not url or 'http' not in url:
		return ''
	try:
		parts = urlsplit(url)
		path = quote(parts.path, safe='/%._-~')
		query = quote(parts.query, safe='=&%._-~')
		return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))
	except:
		return url

# Récupère les visuels Fanart.tv d’un média selon la langue demandée.
def get(media_type, language, media_id, client_key):
	if not media_id:
		return default_fanart_meta

	query = base_url % (media_type, media_id)

	headers = {'api-key': API_KEY}
	if client_key:
		headers['client-key'] = client_key

	try:
		response = session.get(query, headers=headers, timeout=timeout)
		response.raise_for_status()
		art = response.json()
	except:
		return default_fanart_meta

	if not isinstance(art, dict):
		return default_fanart_meta

	if art.get('status') == 'error' or 'error message' in art or 'error_message' in art:
		return default_fanart_meta

	art_get = art.get
	if media_type == 'movies':
		fanart_data = {
			'poster2': parse_art(art_get('movieposter'), language),
			'fanart2': parse_art(art_get('moviebackground'), language, prefer_neutral=True),
			'banner': parse_art(art_get('moviebanner'), language),
			'clearart': parse_art(art_get('movieart', []) + art_get('hdmovieclearart', []), language),
			'clearlogo': parse_art(art_get('movielogo', []) + art_get('hdmovielogo', []), language),
			'landscape': parse_art(art_get('moviethumb'), language),
			'discart': parse_art(art_get('moviedisc'), language),
			'fanart_added': True
		}
	else:
		fanart_data = {
			'poster2': parse_art(art_get('tvposter'), language),
			'fanart2': parse_art(art_get('showbackground'), language, prefer_neutral=True),
			'banner': parse_art(art_get('tvbanner'), language),
			'clearart': parse_art(art_get('clearart', []) + art_get('hdclearart', []), language),
			'clearlogo': parse_art(art_get('hdtvlogo', []) + art_get('clearlogo', []), language),
			'landscape': parse_art(art_get('tvthumb'), language),
			'discart': '',
			'fanart_added': True
		}
	return fanart_data

def _normalize_art_language(language):
	language = str(language or '').lower()
	if language.startswith('en'):
		return 'en'
	return 'fr'

# Sélectionne l’image la plus pertinente selon la langue prioritaire demandée.
def parse_art(art, language, prefer_neutral=False):
	if art is None:
		return ''

	try:
		primary = _normalize_art_language(language)
		fallback = 'en' if primary == 'fr' else 'fr'
		if prefer_neutral:
			lang_order = ('00', '', None, primary, fallback)
		else:
			lang_order = (primary, '00', '', None, fallback)
		result = []

		for lang in lang_order:
			result = [(x['url'], x['likes']) for x in art if x.get('lang') == lang]
			if result:
				break

		if result:
			result.sort(key=lambda x: int(x[1]), reverse=True)
			result = result[0][0]
		else:
			result = ''
	except:
		result = ''

	if 'http' not in result:
		result = ''

	return clean_art_url(result)

# Ajoute les visuels Fanart.tv aux métadonnées du média.
def add(media_type, language, media_id, client_key, meta):
	if not media_id:
		meta.update(default_fanart_meta)
	else:
		try:
			meta.update(get(media_type, language, media_id, client_key))
		except:
			meta.update(default_fanart_meta)
	return meta
