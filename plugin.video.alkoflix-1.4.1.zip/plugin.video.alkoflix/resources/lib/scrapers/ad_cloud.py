from threading import Thread
from debrids.alldebrid_api import AllDebridAPI as Debrid
from modules import source_utils
from modules.source_objects import clean_file_name_preserve_extension
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name
from modules.source_objects import _is_blocked_file_source
# from modules.kodi_utils import logger

internal_results, check_title, clean_title = source_utils.internal_results, source_utils.check_title, source_utils.clean_title
get_file_info, release_info_format, seas_ep_filter = source_utils.get_file_info, source_utils.release_info_format, source_utils.seas_ep_filter
extensions, extras_filter = source_utils.supported_video_extensions(), source_utils.extras_filter()

class source(Debrid):
	scrape_provider = 'ad_cloud'
	def results(self, info):
		try:
			self.sources = []
			sources_append = self.sources.append
			if not enabled_debrids_check('ad'): return internal_results(self.scrape_provider, self.sources)
			self.scrape_results = []
			title_filter = filter_by_name(self.scrape_provider)
			self.media_type, title = info.get('media_type'), info.get('title')
			self.year, self.season, self.episode = int(info.get('year')), info.get('season'), info.get('episode')
			if self.media_type == 'episode': self.seas_ep_query_list = source_utils.seas_ep_query_list(self.season, self.episode)
			self.folder_query, self.year_query_list = clean_title(normalize(title)), tuple(map(str, range(self.year - 1, self.year + 2)))
			self._scrape_cloud()
			if not self.scrape_results: return internal_results(self.scrape_provider, self.sources)
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			extras_filtering_list = tuple(i for i in extras_filter if not i in title.lower())
			for item in self.scrape_results:
				try:
					if _is_blocked_file_source(item): continue
					if not item['filename'].lower().endswith(tuple(extensions)): continue
					formalized = normalize(item['folder_name'])
					foldername = clean_title(formalized)
					normalized = normalize(item['filename'])
					filename = clean_title(normalized)
					if self.media_type == 'movie':
						if any(x in filename for x in extras_filtering_list): continue
						# Les liens AllDebrid sauvegardés/historiques sont déjà des liens directs.
						# Plusieurs entrées de /user/links ne contiennent pas l'année dans leur
						# nom, contrairement à l'historique. On garde donc le filtre titre,
						# mais on ne bloque plus ces liens uniquement parce que l'année manque.
						if not item.get('ad_direct_link') and not any(x in filename for x in self.year_query_list): continue
					elif not seas_ep_filter(self.season, self.episode, normalized): continue
					if not (self.folder_query in filename or self.folder_query in foldername): continue

					if title_filter and not check_title(title, normalized, self.aliases, self.year, self.season, self.episode): continue
					direct_debrid_link, URLName = item.get('downloads', False), clean_file_name_preserve_extension(normalized)
					file_dl, size = item.get('link_dl') if direct_debrid_link else item.get('link'), round(float(int(item.get('size') or 0))/1073741824, 2)
					if not file_dl: continue
					video_quality, details = get_file_info(name_info=release_info_format(normalized))
					sources_append({
						'source': self.scrape_provider, 'direct': True, 'direct_debrid_link': direct_debrid_link,
						'scrape_provider': self.scrape_provider, 'id': file_dl, 'url_dl': file_dl, 'name': normalized, 'title': normalized,
						'URLName': URLName, 'extraInfo': details, 'quality': video_quality, 'size': size, 'size_label': '%.2f GB' % size
					})
				except: pass
		except Exception as e:
			from modules.kodi_utils import logger
			logger(f"alkoFlix {self.scrape_provider} Exception", e)
		internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _scrape_cloud(self):
		try:
			results_append = self.scrape_results.append
			threads = []
			append = threads.append
			cloud_files = self.user_cloud()
			for item in cloud_files.get('magnets', []):
				if _is_blocked_file_source({'filename': item.get('filename')}): continue
				normalized = normalize(item.get('filename', ''))
				folder_name = clean_title(normalized)
				if folder_name and not self.folder_query in folder_name: continue
				append(i := Thread(target=self._scrape_folders, args=(item,)))
				i.start()
			# Les liens sauvegardés (/user/links) restent accessibles dans l'arbo AllDebrid,
			# mais on ne les scrape plus dans le sélecteur pour l’instant.
			# La recherche cloud revient à la logique stable : magnets + historique.
			self._scrape_downloads()
			[i.join() for i in threads]
		except: pass

	def _scrape_folders(self, folder_info):
		try:
			results_append = self.scrape_results.append
			folder = self.torrent_info(folder_info['id'])
			folder['links'] = self.flatten_magnet_files(folder['files'])
			for item in folder['links']:
				if _is_blocked_file_source({'filename': item.get('n'), 'folder_name': folder_info.get('filename')}): continue
				try: item.update({
					'filename': item['n'], 'folder_name': folder_info['filename'],
					'size': item['s'], 'link': item['l']
				})
				except: pass
				else: results_append(item)
		except: pass

	def _extract_link_items(self, result):
		try:
			if isinstance(result, list): return result
			if isinstance(result, dict):
				for key in ('links', 'history', 'downloads', 'items'):
					value = result.get(key)
					if isinstance(value, list): return value
				data = result.get('data')
				if isinstance(data, list): return data
				if isinstance(data, dict):
					for key in ('links', 'history', 'downloads', 'items'):
						value = data.get(key)
						if isinstance(value, list): return value
		except: pass
		return []

	def _append_link_results(self, items, saved=False):
		# /user/links et /user/history sont des liens directs déjà présents
		# dans le compte AllDebrid. On les traite donc exactement pareil pour
		# l'arbo Liens et pour le scraping du sélecteur.
		try:
			results_append = self.scrape_results.append
			for item in items or []:
				try:
					filename = item.get('filename') or item.get('name') or item.get('file') or item.get('link') or item.get('link_dl') or item.get('url') or ''
					link = item.get('link') or item.get('link_dl') or item.get('url') or item.get('download') or ''
					if not filename or not link: continue
					item.update({
						'filename': filename, 'folder_name': filename,
						'link': link, 'link_dl': link,
						'downloads': True, 'saved_links': saved,
						'ad_direct_link': True, 'ad_cloud_section': 'links' if saved else 'history'
					})
				except: pass
				else: results_append(item)
		except: pass

	def _scrape_saved_links(self):
		try:
			cloud_links = self.saved_links()
			self._append_link_results(self._extract_link_items(cloud_links), saved=True)
		except: pass

	def _scrape_downloads(self):
		try:
			cloud_downloads = self.downloads()
			self._append_link_results(self._extract_link_items(cloud_downloads), saved=False)
		except: pass

