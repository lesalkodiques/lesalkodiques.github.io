# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/debrids/alldebrid_api.py

import requests
from caches.main_cache import cache_object
from modules import kodi_utils
# logger = kodi_utils.logger

ls, get_setting = kodi_utils.local_string, kodi_utils.get_setting
base_url = 'https://api.alldebrid.com/'
timeout = 10.0
session = requests.Session()
session.custom_errors = requests.exceptions.ConnectionError, requests.exceptions.Timeout
session.mount('https://api.alldebrid.com', requests.adapters.HTTPAdapter(max_retries=1))

class AllDebridAPI:
	icon = 'alldebrid.png'

	@staticmethod
	def flatten_magnet_files(files_list):
		def flatten(items):
			for i in items:
				if not isinstance(i, dict): continue
				if 'e' in i: flatten(i['e'])
				else: files_append(i)
		files = []
		files_append = files.append
		flatten(files_list)
		return files

	def __init__(self):
		self.token = get_setting('ad.token')
		session.headers.update(self.headers())

	def _request(self, method, path, params=None, data=None):
		url = base_url + path
		try: response = session.request(method, url, params=params, data=data, timeout=timeout)
		except session.custom_errors: return kodi_utils.notification('%s timeout' % __name__)
		if not response.ok: kodi_utils.logger(__name__, f"{response.reason}\n{response.url}")
		response = response.json() if 'json' in response.headers.get('Content-Type', '') else response
		if 'data' in response and response.get('status') == 'success': response = response['data']
		return response

	def _get(self, path, params=None):
		return self._request('get', path, params=params)

	def _post(self, path, data=None):
		return self._request('post', path, data=data)


	def _response_preview(self, result, limit=700):
		try:
			import json
			preview = json.dumps(result, ensure_ascii=False, sort_keys=True)
		except:
			try: preview = str(result)
			except: preview = 'réponse illisible'
		token = self.token or ''
		if token: preview = preview.replace(token, '***')
		return preview[:limit]

	def _format_api_error(self, result):
		try:
			if isinstance(result, dict) and 'error' in result:
				error = result.get('error') or {}
				if isinstance(error, dict):
					code = error.get('code') or error.get('type') or 'UNKNOWN'
					message = error.get('message') or error.get('details') or error.get('description') or 'message absent'
					return '%s - %s' % (code, message)
				return str(error)
		except:
			pass
		return ''

	def _raise_unexpected_magnets_response(self, context, result):
		error = self._format_api_error(result)
		if error: message = 'AllDebrid: %s | erreur API=%s' % (context, error)
		else: message = 'AllDebrid: %s | réponse sans clé magnets' % context
		kodi_utils.logger('AllDebrid resolve', '%s | réponse=%s' % (message, self._response_preview(result)))
		raise Exception(message)

	def _extract_magnets(self, result, context):
		try:
			if isinstance(result, dict) and 'magnets' in result:
				magnets = result.get('magnets') or []
				if isinstance(magnets, dict): magnets = [magnets]
				return magnets
		except:
			pass
		self._raise_unexpected_magnets_response(context, result)

	def headers(self):
		return {'Authorization': 'Bearer %s' % self.token}

	def days_remaining(self):
		import datetime
		try:
			account_info = self.account_info()['user']
			expires = datetime.datetime.fromtimestamp(account_info['premiumUntil'])
			days = (expires - datetime.datetime.today()).days
		except: days = None
		return days

	def account_info(self):
		url = 'v4/user'
		result = self._get(url)
		return result

	def torrent_info(self, transfer_id):
		url = 'v4.1/magnet/status'
		params = {'id': transfer_id}
		result = self._get(url, params)
		magnets = self._extract_magnets(result, 'statut magnet introuvable')
		return magnets[0] if isinstance(magnets, list) and magnets else {}

	def delete_torrent(self, transfer_id):
		url = 'v4/magnet/delete'
		data = {'id': transfer_id}
		result = self._post(url, data)
		return True if not result is None and not 'error' in result else False

	def _iter_response_values(self, item):
		try:
			if isinstance(item, dict):
				for value in item.values():
					for nested_value in self._iter_response_values(value):
						yield nested_value
			elif isinstance(item, (list, tuple)):
				for value in item:
					for nested_value in self._iter_response_values(value):
						yield nested_value
			else:
				yield item
		except:
			return

	def _magnet_matches_hash(self, magnet, info_hash):
		try:
			for value in self._iter_response_values(magnet):
				if info_hash in str(value or '').lower():
					return True
		except:
			pass
		return False

	def delete_torrent_by_hash(self, info_hash, filename=None, attempts=1, sleep_ms=0, retry_delays_ms=None):
		try:
			info_hash = str(info_hash or '').strip().lower()
			if not info_hash: return False
			if retry_delays_ms is None:
				attempts = max(1, int(attempts or 1))
				sleep_ms = max(0, int(sleep_ms or 0))
				retry_delays_ms = [sleep_ms] * (attempts - 1)
			else:
				retry_delays_ms = [max(0, int(i or 0)) for i in retry_delays_ms]
				attempts = len(retry_delays_ms) + 1
			for attempt in range(attempts):
				result = self._get('v4.1/magnet/status') or {}
				magnets = result.get('magnets', []) if isinstance(result, dict) else []
				if isinstance(magnets, dict): magnets = [magnets]
				for magnet in magnets or []:
					try:
						magnet_id = magnet.get('id')
						if not magnet_id: continue
						if self._magnet_matches_hash(magnet, info_hash):
							deleted = self.delete_torrent(magnet_id)
							if deleted:
								kodi_utils.logger('AllDebrid cloud cleanup', 'Magnet supprimé -> tentative=%s/%s | id=%s | hash=%s | fichier=%s' % (attempt + 1, attempts, magnet_id, info_hash, filename or 'N/A'))
							else:
								kodi_utils.logger('AllDebrid cloud cleanup', 'Suppression refusée -> tentative=%s/%s | id=%s | hash=%s | fichier=%s' % (attempt + 1, attempts, magnet_id, info_hash, filename or 'N/A'))
							return deleted
					except:
						pass
				if attempt < attempts - 1:
					delay_ms = retry_delays_ms[attempt]
					kodi_utils.logger('AllDebrid cloud cleanup', 'Magnet pas encore visible -> tentative=%s/%s | prochaine vérification dans %.1fs | hash=%s | fichier=%s' % (attempt + 1, attempts, delay_ms / 1000.0, info_hash, filename or 'N/A'))
					if delay_ms: kodi_utils.sleep(delay_ms)
			kodi_utils.logger('AllDebrid cloud cleanup', 'Aucun magnet à supprimer après %s essai(s) -> hash=%s | fichier=%s' % (attempts, info_hash, filename or 'N/A'))
			return False
		except Exception as e:
			kodi_utils.logger('AllDebrid delete_torrent_by_hash', f'{e} | {info_hash} | {filename}')
			return False

	def unrestrict_link(self, link):
		url = 'v4/link/unlock'
		params = {'link': link}
		result = self._get(url, params)
		try: return result['link']
		except: return None

	def check_cache(self, hashes):
		data = {'v4/magnets[]': hashes}
		result = self._post('magnet/instant', data)
		return result

	def create_transfer(self, magnet):
		url = 'v4/magnet/upload'
		params = {'magnet': magnet}
		result = self._get(url, params)
		magnets = self._extract_magnets(result, 'upload magnet refusé')
		if not magnets: self._raise_unexpected_magnets_response('upload magnet sans élément exploitable', result)
		return magnets[0].get('id', '')

	def parse_magnet_pack(self, magnet_url, info_hash, errors=False):
		from modules.source_utils import supported_video_extensions
		from modules.source_objects import _is_blocked_file_source, _blocked_file_value
		torrent_id = None
		try:
			if _is_blocked_file_source({'url': magnet_url, 'hash': info_hash}):
				blocked_value = _blocked_file_value({'url': magnet_url, 'hash': info_hash})
				kodi_utils.logger('Sécurité AllDebrid', 'Magnet bloqué avant upload | hash=%s | valeur=%s' % (info_hash, blocked_value or 'N/A'))
				raise Exception('blocked executable magnet: %s' % (blocked_value or 'N/A'))
			extensions = supported_video_extensions()
			kodi_utils.logger('AllDebrid resolve', 'Upload magnet pour analyse | hash=%s' % (info_hash or 'N/A'))
			torrent_id = self.create_transfer(magnet_url)
			kodi_utils.logger('AllDebrid resolve', 'Magnet créé pour analyse | id=%s | hash=%s' % (torrent_id or 'N/A', info_hash or 'N/A'))
			if not torrent_id: raise Exception('AllDebrid: upload magnet sans identifiant exploitable')
			for key in ['completionDate'] * 3:
				kodi_utils.sleep(500)
				torrent_info = self.torrent_info(torrent_id)
				if not isinstance(torrent_info, dict):
					self._raise_unexpected_magnets_response('statut magnet invalide', torrent_info)
				if torrent_info.get(key): break
			else: raise Exception('AllDebrid: magnet non cache ou non prêt après analyse')
			files = torrent_info.get('files') or []
			if not files: raise Exception('AllDebrid: pack magnet sans liste de fichiers exploitable')
			torrent_info['links'] = self.flatten_magnet_files(files)
			blocked_item = next((item for item in torrent_info['links'] if _is_blocked_file_source({'filename': item.get('n'), 'path': item.get('n')})), None)
			if blocked_item:
				blocked_value = _blocked_file_value({'filename': blocked_item.get('n'), 'path': blocked_item.get('n')}) or blocked_item.get('n') or 'N/A'
				kodi_utils.logger('Sécurité AllDebrid', 'Fichier exécutable détecté dans le pack | id=%s | hash=%s | fichier=%s' % (torrent_id or 'N/A', info_hash or 'N/A', blocked_value))
				raise Exception('blocked executable file in magnet pack: %s' % blocked_value)
			kodi_utils.logger('AllDebrid resolve', 'Pack analysé | id=%s | hash=%s | fichiers=%s' % (torrent_id or 'N/A', info_hash or 'N/A', len(torrent_info['links'] or [])))
			return [
				{'link': item['l'],
				 'size': item['s'],
				 'torrent_id': torrent_id,
				 'filename': item['n']}
				for item in torrent_info['links']
				if item['n'].lower().endswith(tuple(extensions))
			]
		except Exception as e:
			if torrent_id:
				deleted = self.delete_torrent(torrent_id)
				kodi_utils.logger('AllDebrid resolve', 'Nettoyage après refus/erreur | id=%s | hash=%s | supprimé=%s | erreur=%s' % (torrent_id, info_hash or 'N/A', deleted, e))
			if errors: raise

	def downloads(self):
		# Historique récent des liens AllDebrid.
		url = 'v4/user/history'
		string = 'alkoflix_ad_downloads'
		return cache_object(self._get, string, url, False, 0.5)

	def saved_links(self):
		# Liens sauvegardés par l'utilisateur dans son compte AllDebrid.
		url = 'v4/user/links'
		string = 'alkoflix_ad_saved_links'
		return cache_object(self._get, string, url, False, 0.5)

	def delete_saved_link(self, link):
		url = 'v4/user/links/delete'
		data = {'links[]': [link]}
		# Certaines versions de requests encodent mieux les tableaux PHP si on passe une liste de tuples.
		try: result = self._post(url, data=[('links[]', link)])
		except: result = self._post(url, data)
		return True if not result is None and not 'error' in result else False

	def user_cloud(self, completed=True):
		url = 'v4.1/magnet/status'
		string = 'alkoflix_ad_user_cloud'
		result = cache_object(self._get, string, url, False, 0.5)
		if completed: result['magnets'] = [i for i in result['magnets'] if i['statusCode'] == 4]
		return result

	def clear_cache(self):
		from modules.kodi_utils import clear_property, path_exists, database_connect, maincache_db
		try:
			if not path_exists(maincache_db): return True
			from caches.debrid_cache import DebridCache
			dbcon = database_connect(maincache_db)
			dbcur = dbcon.cursor()
			# USER CLOUD
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id = ?""", ('alkoflix_ad_user_cloud',))
				clear_property('alkoflix_ad_user_cloud')
				dbcon.commit()
				user_cloud_success = True
			except: user_cloud_success = False
			# DOWNLOAD LINKS
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id = ?""", ('alkoflix_ad_downloads',))
				clear_property('alkoflix_ad_downloads')
				dbcon.commit()
				download_links_success = True
			except: download_links_success = False
			# SAVED LINKS
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id = ?""", ('alkoflix_ad_saved_links',))
				clear_property('alkoflix_ad_saved_links')
				dbcon.commit()
				saved_links_success = True
			except: saved_links_success = False
			# HOSTERS
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id = ?""", ('alkoflix_ad_valid_hosts',))
				clear_property('alkoflix_ad_valid_hosts')
				dbcon.commit()
				hoster_links_success = True
			except: hoster_links_success = False
			dbcon.close()
			# HASH CACHED STATUS
			try:
				DebridCache().clear_debrid_results('ad')
				hash_cache_status_success = True
			except: hash_cache_status_success = False
		except: return False
		if False in (user_cloud_success, download_links_success, saved_links_success, hoster_links_success, hash_cache_status_success): return False
		return True

