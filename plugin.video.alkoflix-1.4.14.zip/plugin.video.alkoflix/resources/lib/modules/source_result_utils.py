# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/source_result_utils.py

import re

try:
	from modules.source_objects import PERSONAL_EXTERNAL_PROVIDERS
except Exception:
	PERSONAL_EXTERNAL_PROVIDERS = ('aiostreams', 'aiostreams_custom', 'custom_1', 'custom_2', 'custom_stremio1', 'custom_stremio2')

PERSONAL_SOURCE_FLAGS = ('aiostreams_direct', 'custom_stremio1_direct', 'custom_stremio2_direct')
DIRECT_SOURCE_FLAGS = PERSONAL_SOURCE_FLAGS + ('usenetstreams_direct',)

QUALITY_RANKS = {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}
FRENCH_MULTI_PATTERN = (
	r'(^|[^a-z0-9])('
	r'fr|fra|fre|frn|french|truefrench|true\.french|true-french|'
	r'vf|vfi|vff|vfq|vf2|vof|vf-fr|vf-fq|vf-i|'
	r'multi'
	r')([^a-z0-9]|$)'
)
VOSTFR_PATTERN = r'(^|[^a-z0-9])(vostfr|vo\.?stfr|subfrench|french\.?sub|fr\.?sub)([^a-z0-9]|$)'

PERSONAL_PROVIDER_ORDER = {
	'aiostreams': 0,
	'aiostreams_custom': 0,
	'custom_1': 1,
	'custom_stremio1': 1,
	'custom_2': 2,
	'custom_stremio2': 2
}

SOURCE_RESULT_DEFAULTS = {
	'provider': '',
	'provider_name': '',
	'debrid': '',
	'cache_provider': '',
	'source': '',
	'scrape_provider': '',
	'quality': 'SD',
	'language': '',
	'extraInfo': '',
	'name': '',
	'URLName': '',
	'name_info': '',
	'size': 0.0,
	'size_label': ''
}

SOURCE_DEBUG_FIELDS = ('provider', 'debrid', 'cache_provider', 'source', 'scrape_provider', 'quality', 'size', 'size_label', 'hash', 'name', 'URLName')

BLANK_DISPLAY_VALUES = ('', 'none', 'null', 'false')

def display_value(value, default='N/A'):
	# Valeur destinée aux logs/debug uniquement : n'altère jamais les champs métier.
	try:
		if value is None: return default
		if isinstance(value, (int, float)):
			return default if value == 0 else str(value)
		value = str(value).strip()
		return default if value.lower() in BLANK_DISPLAY_VALUES else value
	except Exception:
		return default

def source_debug_value(item, key, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		debug_key = '_debug_%s' % key
		if debug_key in item: return display_value(item.get(debug_key), default)
		return display_value(item.get(key), default)
	except Exception:
		return default

def source_debug_file(item, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		return display_value(item.get('_debug_file') or item.get('name') or item.get('URLName') or item.get('name_info'), default)
	except Exception:
		return default

def source_debug_size(item, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		value = display_value(item.get('size_label'), None)
		if value: return value
		value = display_value(item.get('_debug_size'), None)
		if value: return value
		return display_value(item.get('size'), default)
	except Exception:
		return default


CUSTOM_PROVIDER_KEYS = ('custom_1', 'custom_2', 'custom_stremio1', 'custom_stremio2')

def upper_display(value, default='N/A'):
	try:
		value = display_value(value, default)
		return str(value).upper() if value != default else default
	except Exception:
		return default

def selector_custom_source_label(item):
	# Libellé UI court pour les sources personnalisées.
	# Ne modifie pas les champs métier : cache_provider reste disponible pour le tri/cache.
	try:
		if not isinstance(item, dict): return ''
		provider_key = _clean_key(item.get('provider'))
		if item.get('custom_stremio1_direct'): provider_key = 'custom_stremio1'
		elif item.get('custom_stremio2_direct'): provider_key = 'custom_stremio2'
		if provider_key not in CUSTOM_PROVIDER_KEYS: return ''
		label = item.get('provider_name') or item.get('display_name') or ''
		return upper_display(label, '')
	except Exception:
		return ''

CACHE_STATUS_COLORS = {
	'cached': 'FF43D17A',
	'uncached': 'FFFF5A5F',
	'unchecked': 'FFFFC857'
}

DEBRID_SHORT_LABELS = (
	('alldebrid', 'AD'), ('all-debrid', 'AD'),
	('real-debrid', 'RD'), ('realdebrid', 'RD'),
	('premiumize', 'PM'), ('torbox', 'TB'), ('easynews', 'EN')
)

def _cache_provider_short_label(cache_provider):
	try:
		value = str(cache_provider or '').lower()
		for key, label in DEBRID_SHORT_LABELS:
			if key in value: return label
		value = value.replace('unchecked', '').replace('uncached', '').strip()
		return upper_display(value[:3], 'DB') if value else 'DB'
	except Exception:
		return 'DB'

def _colored_cache_label(label, status):
	try: return '[COLOR %s][B]%s[/B][/COLOR]' % (CACHE_STATUS_COLORS[status], label)
	except Exception: return label

def selector_cache_status_label(item, pack=False):
	# Libellé court strictement visuel pour la colonne type/source du sélecteur.
	# Le statut non contrôlé reste volontairement distinct du non-caché : il évite
	# d'interroger le débrideur pour tous les résultats seulement pour colorer la liste.
	try:
		cache_provider = str((item or {}).get('cache_provider') or '')
		label = _cache_provider_short_label(cache_provider)
		if 'Unchecked' in cache_provider:
			return _colored_cache_label(label, 'unchecked')
		if 'Uncached' in cache_provider:
			return _colored_cache_label(label, 'uncached')
		label = _colored_cache_label(label, 'cached')
		if pack:
			package = upper_display((item or {}).get('package'), '')
			if package: return '%s PCK' % label
		return label
	except Exception:
		return 'N/A'


def selector_cache_status_icon(item):
	# Icône strictement visuelle pour signaler un magnet non vérifié dans le sélecteur.
	# Aucun appel débrideur n'est déclenché par cet indicateur.
	try:
		cache_provider = str((item or {}).get('cache_provider') or '')
		if 'Unchecked' in cache_provider: return 'magnet.png'
		return ''
	except Exception:
		return ''

def selector_cache_status_icon_color(item):
	try:
		cache_provider = str((item or {}).get('cache_provider') or '')
		if 'Unchecked' in cache_provider: return CACHE_STATUS_COLORS['unchecked']
		return ''
	except Exception:
		return ''

def selector_source_type_label(item, source=None, pack=False):
	# Priorité UI : nom custom court > état cache court > source brute.
	try:
		custom_label = selector_custom_source_label(item)
		if custom_label: return custom_label
		if isinstance(item, dict) and 'cache_provider' in item:
			return selector_cache_status_label(item, pack=pack)
		return upper_display(source if source is not None else (item or {}).get('source'), 'N/A')
	except Exception:
		return 'N/A'

def source_progress_line1(item):
	# Libellé court pour les fenêtres de progression : évite les champs vides et les textes cache trop longs.
	try:
		if not isinstance(item, dict): return 'N/A'
		custom_label = selector_custom_source_label(item)
		parts = []
		scrape_provider = item.get('scrape_provider')
		if scrape_provider and scrape_provider != 'external': parts.append(scrape_provider)
		if custom_label: parts.append(custom_label)
		elif item.get('cache_provider'): parts.append(selector_cache_status_label(item, pack=item.get('package') in ('true', 'show', 'season')))
		provider = item.get('provider')
		if provider and provider != 'external' and not custom_label: parts.append(provider)
		parts = [upper_display(p, '') for p in parts if display_value(p, '')]
		return ' | '.join(parts) if parts else 'N/A'
	except Exception:
		return 'N/A'

def _clean_key(value):
	try: return str(value or '').strip().lower()
	except Exception: return ''

def is_personal_result(item):
	try:
		if not isinstance(item, dict): return False
		# Les trackers intégrés/privés natifs (C411/Torr9/YGG/Comet/Nyaa) ne sont pas
		# des sources personnelles externes. Ils doivent passer dans le tri global
		# demandé dans les réglages, contrairement à AIOStreams/Custom.
		native_providers = ('c411', 'torr9', 'ygg', 'comet', 'nyaa')
		for key in ('provider', 'scrape_provider'):
			if _clean_key(item.get(key)) in native_providers: return False
		if item.get('personal_source'): return True
		if any(item.get(flag) for flag in PERSONAL_SOURCE_FLAGS): return True
		for key in ('provider', 'debrid', 'source'):
			if _clean_key(item.get(key)) in PERSONAL_EXTERNAL_PROVIDERS: return True
	except Exception:
		pass
	return False

def is_direct_source_result(item):
	try: return any(item.get(flag) for flag in DIRECT_SOURCE_FLAGS)
	except Exception: return False

def personal_result_order(item):
	try:
		if item.get('aiostreams_direct'): return 0
		if item.get('custom_stremio1_direct'): return 1
		if item.get('custom_stremio2_direct'): return 2
		for key in ('provider', 'debrid', 'source'):
			provider = _clean_key(item.get(key))
			if provider in PERSONAL_PROVIDER_ORDER: return PERSONAL_PROVIDER_ORDER[provider]
	except Exception:
		pass
	return 99

def sort_personal_results(results):
	try: return sorted(results, key=personal_result_order)
	except Exception: return results

def get_provider_rank(item, provider_sort_ranks=None, default=11):
	try:
		provider = item.get('scrape_provider') or item.get('provider') or ''
		debrid = item.get('debrid') or ''
		account_type = str(debrid if provider == 'external' else provider).lower()
		return (provider_sort_ranks or {}).get(account_type, default)
	except Exception:
		return default

def get_quality_rank(quality, default=99):
	try: return QUALITY_RANKS.get(str(quality or 'SD'), default)
	except Exception: return default

def set_sort_ranks(results, provider_sort_ranks=None):
	try:
		for item in results or []:
			item['provider_rank'] = get_provider_rank(item, provider_sort_ranks)
			item['quality_rank'] = get_quality_rank(item.get('quality', 'SD'))
	except Exception:
		pass
	return results

def release_text(item):
	try: return ' '.join(str(item.get(k) or '') for k in ('name_info', 'name', 'URLName', 'extraInfo')).lower()
	except Exception: return ''

def is_vostfr_result(item):
	try: return bool(re.search(VOSTFR_PATTERN, release_text(item), re.I))
	except Exception: return False


def _has_explicit_french_audio_marker(text):
	# Différencie une vraie piste audio française/VF/MULTI d'un simple tag
	# sous-titres français (VOSTFR, French.Sub, FR.Sub).
	try:
		return bool(re.search(
			r'(^|[^a-z0-9])('
			r'multi|multilangue|multilanguage|'
			r'truefrench|true\.french|true-french|'
			r'vf|vfi|vff|vfq|vf2|vof|vf-fr|vf-fq|vf-i'
			r')([^a-z0-9]|$)',
			text or '',
			re.I
		))
	except Exception:
		return False


def is_french_multi_result(item):
	try:
		text = release_text(item)
		# Un résultat explicitement VOSTFR ne doit jamais être absorbé dans le
		# groupe FR/MULTI uniquement parce que certains providers remplissent
		# language='fr' pour signaler des sous-titres français.
		if is_vostfr_result(item) and not _has_explicit_french_audio_marker(text):
			return False
		if str(item.get('language') or '').lower() == 'fr': return True
		return bool(re.search(FRENCH_MULTI_PATTERN, text, re.I))
	except Exception:
		return False


def language_priority_rank(item):
	# Rang francophone centralisé : FR/MULTI avant VOSTFR, puis le reste.
	try:
		if is_french_multi_result(item): return 0
		if is_vostfr_result(item): return 1
		return 2
	except Exception:
		return 2

PRIVATE_TRACKER_PROVIDERS = ('c411', 'torr9')
SOURCE_PRIORITY_WHEN_PRIVATE_FIRST = {
	# Priorité interne à langue équivalente quand l'option trackers privés est activée.
	# Le tri utilisateur reste conservé dans chaque groupe grâce au tri stable.
	# C411 passe avant Torr9 afin que le dédoublonnage conserve C411 quand
	# plusieurs trackers retournent exactement le même hash.
	'c411': 0,
	'torr9': 1,
	'ygg': 2,
	'comet': 3,
	'nyaa': 4,
}


def _source_identity(item):
	try:
		return str(
			(item or {}).get('scrape_provider')
			or (item or {}).get('provider')
			or (item or {}).get('tracker')
			or (item or {}).get('tracker_name')
			or ''
		).lower()
	except Exception:
		return ''


def is_private_tracker_result(item):
	try:
		provider = str((item or {}).get('scrape_provider') or (item or {}).get('provider') or '').lower()
		tracker = str((item or {}).get('tracker') or (item or {}).get('tracker_name') or '').lower()
		return provider in PRIVATE_TRACKER_PROVIDERS or tracker in PRIVATE_TRACKER_PROVIDERS
	except Exception:
		return False


def _source_priority_when_private_first(item):
	try:
		provider = str((item or {}).get('scrape_provider') or (item or {}).get('provider') or '').lower()
		tracker = str((item or {}).get('tracker') or (item or {}).get('tracker_name') or '').lower()
		if provider in PRIVATE_TRACKER_PROVIDERS or tracker in PRIVATE_TRACKER_PROVIDERS:
			return 0
		return min(
			SOURCE_PRIORITY_WHEN_PRIVATE_FIRST.get(provider, 9),
			SOURCE_PRIORITY_WHEN_PRIVATE_FIRST.get(tracker, 9),
			SOURCE_PRIORITY_WHEN_PRIVATE_FIRST.get(_source_identity(item), 9)
		)
	except Exception:
		return 9


def _source_priority_group(items, enabled=False):
	try:
		if not enabled: return items
		# Tri stable : on regroupe seulement par source souhaitée, sans défaire le tri
		# qualité/fournisseur/taille déjà appliqué à l'intérieur de chaque groupe.
		return sorted(items, key=_source_priority_when_private_first)
	except Exception:
		return items


def sort_french_streaming_priority(results, private_trackers_first=False):
	# Priorité absolue de langue : FR/MULTI en premier, VOSTFR ensuite, puis le reste.
	# Si demandé, l'ordre à langue équivalente devient : C411/Torr9 > YGG > Comet > Nyaa > autres.
	try:
		french_multi = [i for i in results if language_priority_rank(i) == 0]
		vostfr = [i for i in results if language_priority_rank(i) == 1]
		others = [i for i in results if language_priority_rank(i) == 2]
		return (
			_source_priority_group(french_multi, private_trackers_first) +
			_source_priority_group(vostfr, private_trackers_first) +
			_source_priority_group(others, private_trackers_first)
		)
	except Exception:
		return results


def filter_french_vostfr_results(results):
	# Filtre strict d'affichage : garde VF/MULTI et VOSTFR seulement.
	# Il s'applique après la collecte et le tri, donc il ne multiplie aucun appel source.
	try: return [i for i in results if language_priority_rank(i) in (0, 1)]
	except Exception: return results


def _resolution_bucket(item):
	try:
		quality = str((item or {}).get('quality') or '').strip().lower()
		text = release_text(item)
		if quality in ('4k', '2160p') or re.search(r'(^|[^0-9])(2160p|4k|uhd)([^0-9]|$)', text, re.I): return '4K'
		if quality == '1080p' or re.search(r'(^|[^0-9])1080p([^0-9]|$)', text, re.I): return '1080p'
		if quality == '720p' or re.search(r'(^|[^0-9])720p([^0-9]|$)', text, re.I): return '720p'
		return 'SD'
	except Exception:
		return 'SD'


def _select_best_items_preserve_order(results, max_count=0, bucket_func=None):
	# Sélectionne les meilleurs candidats selon cache/seeders, mais retourne toujours
	# les éléments dans l'ordre déjà trié par les réglages utilisateur.
	# Le seed aide donc à choisir quoi conserver lorsque les limites coupent la liste,
	# sans jamais devenir un tri visible dans le sélecteur.
	try: max_count = int(max_count or 0)
	except Exception: max_count = 0
	if max_count <= 0: return results
	try:
		if not bucket_func:
			indexed = list(enumerate(results or []))
			if len(indexed) <= max_count: return results
			selected_indexes = set(i for i, item in sorted(indexed, key=lambda pair: (language_priority_rank(pair[1]), _cache_status_rank(pair[1]), pair[0]))[:max_count])
			return [item for i, item in indexed if i in selected_indexes]

		buckets = {}
		for index, item in enumerate(results or []):
			buckets.setdefault(bucket_func(item), []).append((index, item))
		selected_indexes = set()
		for indexed_items in buckets.values():
			if len(indexed_items) <= max_count:
				selected_indexes.update(index for index, item in indexed_items)
				continue
			selected_indexes.update(
				index for index, item in sorted(indexed_items, key=lambda pair: (language_priority_rank(pair[1]), _cache_status_rank(pair[1]), pair[0]))[:max_count]
			)
		return [item for index, item in enumerate(results or []) if index in selected_indexes]
	except Exception:
		return results


def limit_results_per_resolution(results, max_per_resolution=0):
	try: return _select_best_items_preserve_order(results, max_per_resolution, _resolution_bucket)
	except Exception: return results


def limit_total_results(results, max_total=0):
	try: return _select_best_items_preserve_order(results, max_total)
	except Exception: return results

def is_comet_result(item):
	try:
		provider = str((item or {}).get('scrape_provider') or (item or {}).get('provider') or '').lower()
		tracker = str((item or {}).get('tracker') or (item or {}).get('tracker_name') or '').lower()
		source = str((item or {}).get('source') or '').lower()
		return provider == 'comet' or tracker == 'comet' or source == 'comet'
	except Exception:
		return False


def _seeders_count(item):
	# Aucun appel réseau : on utilise seulement le nombre de seeders déjà fourni
	# par la source. Les champs varient selon les providers, donc on accepte
	# plusieurs noms possibles sans rendre ce tri fragile.
	try:
		for key in ('seeders', 'seeds', 'seed', 'seeder'):
			value = (item or {}).get(key)
			if value in (None, ''): continue
			try: return max(0, int(float(str(value).replace(',', '.'))))
			except Exception: continue
		return 0
	except Exception:
		return 0


def _cache_status_rank(item):
	# Priorité d'affichage avant les limites :
	# 1) liens déjà confirmés cachés ;
	# 2) magnets non vérifiés, classés par seeders décroissants ;
	# 3) vrais non cachés, aussi classés par seeders décroissants.
	# Aucun appel débrideur n'est déclenché ici : on évite de bombarder AllDebrid.
	try:
		cache_provider = str((item or {}).get('cache_provider') or '').lower()
		if 'uncached' in cache_provider: status_rank = 2
		elif 'unchecked' in cache_provider: status_rank = 1
		elif cache_provider: status_rank = 0
		else: status_rank = 1
		return (status_rank, -_seeders_count(item))
	except Exception:
		return (1, 0)


def prioritize_cached_results(results):
	try:
		return sorted(results or [], key=_cache_status_rank)
	except Exception:
		return results

def limit_results_with_comet_fallback(results, max_per_resolution=0, max_total=0, enabled=False):
	# Secours strict : Comet ne doit pas compléter une liste déjà alimentée
	# par les autres sources. Si d'autres résultats existent, les résultats
	# Comet sont ignorés. Si Comet est seul, on applique simplement les limites.
	try:
		try: max_per_resolution = int(max_per_resolution or 0)
		except Exception: max_per_resolution = 0
		try: max_total = int(max_total or 0)
		except Exception: max_total = 0

		if enabled:
			primary = [i for i in results if not is_comet_result(i)]
			if primary:
				results = primary

		# Important : les limites choisissent les meilleurs candidats selon cache/seeders,
		# mais l'ordre visible reste celui déjà produit par les réglages utilisateur.
		if max_per_resolution: results = limit_results_per_resolution(results, max_per_resolution)
		if max_total: results = limit_total_results(results, max_total)
		return results
	except Exception:
		return results

def sort_uncached_torrents(results, display_uncached=False, filterless_search=False):
	try:
		results.sort(key=lambda k: 'Unchecked' in k.get('cache_provider', ''), reverse=False)
		if display_uncached or filterless_search:
			results.sort(key=lambda k: 'Uncached' in k.get('cache_provider', ''), reverse=False)
			return results
		return [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
	except Exception:
		return results

def source_passes_result_filters(item, quality_filter, include_3d=True, size_filter=0, include_unknown_size=True, max_size=None):
	try:
		if item.get('bypass_filter'): return True
		if item.get('quality') not in quality_filter: return False
		if not include_3d and '3D' in item.get('extraInfo', ''): return False
		if not size_filter: return True
		if item.get('scrape_provider', '').startswith('folder'): return True
		size = item.get('size', 0)
		try: size = float(size or 0)
		except Exception: size = 0
		if include_unknown_size: return size <= max_size
		return 0.01 < size <= max_size
	except Exception:
		return False

def apply_source_special_filter(results, key, enable_setting, autoplay=False, hybrid_allowed=False, hdr_key='[B]HDR[/B]', uncached_label='Uncached'):
	try:
		if enable_setting == 1:
			if 'D/VISION' in key and hybrid_allowed:
				return [
					i for i in results
					if i.get('bypass_filter') or all(x in i.get('extraInfo', '') for x in (key, hdr_key)) or key not in i.get('extraInfo', '')
				]
			return [i for i in results if i.get('bypass_filter') or key not in i.get('extraInfo', '')]
		if enable_setting == 2 and autoplay:
			priority_list = [i for i in results if not i.get('bypass_filter') and key in i.get('extraInfo', '')]
			remainder_list = [i for i in results if i not in priority_list]
			return priority_list + remainder_list
		if enable_setting == 3:
			priority_key = lambda k: not k.get('bypass_filter') and key in k.get('extraInfo', '') and uncached_label not in k.get('cache_provider', '')
			results.sort(key=priority_key, reverse=True)
			return results
	except Exception:
		pass
	return results

def normalize_source_result(item):
	# Normalisation défensive et légère : ne modifie pas les valeurs métier existantes,
	# mais garantit les champs de base consommés par le tri, les filtres, le debug et les fenêtres.
	if not isinstance(item, dict): return None
	try:
		result = dict(item)
		original_result = dict(result)
	except Exception: return None
	for key, value in SOURCE_RESULT_DEFAULTS.items():
		if result.get(key) is None: result[key] = value
		elif key not in result: result[key] = value
	try:
		if not result.get('scrape_provider'):
			result['scrape_provider'] = result.get('provider') or result.get('source') or ''
	except Exception:
		pass
	try:
		if not isinstance(result.get('size'), (int, float)):
			result['size'] = float(result.get('size') or 0)
	except Exception:
		result['size'] = 0.0
	try:
		if not result.get('name') and result.get('URLName'):
			result['name'] = result.get('URLName')
		if not result.get('URLName') and result.get('name'):
			result['URLName'] = result.get('name')
	except Exception:
		pass
	try:
		# Champs de debug prêts à afficher : les valeurs vides deviennent N/A sans toucher aux valeurs métier.
		# Ils se basent sur le résultat original pour éviter qu'une valeur interne par défaut
		# comme quality=SD ne donne une fausse impression dans le diagnostic.
		for key in SOURCE_DEBUG_FIELDS:
			result['_debug_%s' % key] = display_value(original_result.get(key))
		result['_debug_file'] = source_debug_file(result)
		result['_debug_size'] = source_debug_size(result)
	except Exception:
		pass
	return result

def normalize_source_results(results):
	normalized = []
	for item in results or []:
		item = normalize_source_result(item)
		if item is not None: normalized.append(item)
	return normalized
