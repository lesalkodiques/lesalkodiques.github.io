# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/c411.py

from modules.private_torznab import PrivateTorznabSource


class source(PrivateTorznabSource):
	provider_key = 'c411'
	provider_name = 'C411'
	api_setting = 'private.c411.api_key'
	base_url = 'https://c411.org/api'
	response_mode = 'xml'
	auth_mode = 'query_apikey'
	auth_modes = ('query_apikey',)
	trust_api_results = True
	priority = 2
