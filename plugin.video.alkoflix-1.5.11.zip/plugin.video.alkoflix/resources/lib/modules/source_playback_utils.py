# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/source_playback_utils.py

"""Helpers défensifs pour le chemin résultat source -> résolution -> lecture.

Ce module ne résout aucun lien directement. Il regroupe seulement les petites
conditions répétées autour du type de source, du contexte média et des chemins
de lecture afin d'éviter que la logique de résolution se disperse dans plusieurs
branches.
"""

EXTERNAL_SCRAPER = 'external'
DIRECT_EXTERNAL_FLAGS = (
	'aiostreams_direct',
	'usenetstreams_direct',
	'custom_stremio1_direct',
	'custom_stremio2_direct'
)
CUSTOM_DIRECT_CLEANUP_FLAGS = ('custom_stremio1_direct', 'custom_stremio2_direct')
HOSTER_DEBRID_PROVIDERS = ('real-debrid', 'alldebrid')


def source_attr(source, name, default=None):
	try: return getattr(source, name, default)
	except Exception: return default


def source_url(source):
	try: return source_attr(source, 'url', '') or ''
	except Exception: return ''


def source_hash(source):
	try: return source_attr(source, 'hash', None)
	except Exception: return None


def scrape_provider(source):
	try: return source_attr(source, 'scrape_provider', '') or ''
	except Exception: return ''


def is_external_source(source):
	return scrape_provider(source) == EXTERNAL_SCRAPER


def is_internal_source(source, internal_scrapers):
	try: return scrape_provider(source) in internal_scrapers
	except Exception: return False


def has_direct_external_flag(source):
	try: return any(source_attr(source, flag, False) for flag in DIRECT_EXTERNAL_FLAGS)
	except Exception: return False


def direct_external_url(source):
	# Lien déjà lisible fourni par AIOStreams/Custom/UsenetStreams.
	try:
		url = source_url(source)
		if url and has_direct_external_flag(source): return url
	except Exception:
		pass
	return ''


def direct_external_needs_cleanup(source):
	# Les sources custom directes peuvent créer un magnet temporaire chez AllDebrid.
	try: return bool(source_url(source) and any(source_attr(source, flag, False) for flag in CUSTOM_DIRECT_CLEANUP_FLAGS))
	except Exception: return False


def is_magnet_url(value):
	try: return str(value or '').lower().startswith('magnet')
	except Exception: return False


def is_source_magnet(source):
	return is_magnet_url(source_url(source))


def is_hoster_source(source, hoster_providers=HOSTER_DEBRID_PROVIDERS):
	try:
		debrid = str(source_attr(source, 'debrid', '') or '').lower()
		source_type = str(source_attr(source, 'source', '') or '').lower()
		return debrid in hoster_providers and source_type not in ('torrent', 'magnet', 'usenet', 'nzb')
	except Exception:
		return False


def media_resolution_context(meta, title_resolver):
	# Retourne titre/saison/épisode pour les API de résolution de pack.
	try:
		meta = meta or {}
		if meta.get('media_type') == 'episode':
			title = meta.get('ep_name') or meta.get('title') or ''
			return (
				title,
				meta.get('custom_season') or meta.get('season'),
				meta.get('custom_episode') or meta.get('episode')
			)
		return title_resolver(meta) or '', None, None
	except Exception:
		return '', None, None
