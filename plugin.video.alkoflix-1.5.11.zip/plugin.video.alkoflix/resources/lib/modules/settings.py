# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/settings.py

from modules import kodi_utils
# from modules.kodi_utils import logger

ls, translate_path, get_setting, set_setting = kodi_utils.local_string, kodi_utils.translate_path, kodi_utils.get_setting, kodi_utils.set_setting

# Raccourcis utilisés partout dans ce module pour éviter de répéter kodi_utils.

# ---------------------------------------------------------------------------
# Apparence et chemins de base
# ---------------------------------------------------------------------------

def addon_fanart(fallback='alkoflix_fanart.jpg'):
	fanart = get_setting('fanart_image', fallback)
	# Ne pas renvoyer le fanart officiel comme fallback de menu.
	# Si aucun vrai fanart personnalisé n'est défini, on laisse Kodi/skin gérer
	# son fond naturel. Retourner transparent.png provoquerait un fond noir
	# dans certains skins.
	if fanart in ('alkoflix_fanart.jpg', 'alkoflix_fanart.png', 'transparent.png', ''): return ''
	return translate_path(fanart)

# ---------------------------------------------------------------------------
# Lecture automatique, reprise et épisode suivant
# ---------------------------------------------------------------------------

def auto_resume(media_type):
	auto_resume = get_setting('auto_resume_%s' % media_type)
	if auto_resume == '1': return True
	if auto_resume == '2' and auto_play(media_type): return True
	else: return False

def auto_play(media_type):
	return get_setting('auto_play_%s' % media_type) == 'true'

def media_click_action():
	# false/0 = afficher les liens, true/1 = ouvrir la fenêtre d'information.
	value = get_setting('media.click_action', 'false')
	if value in ('true', '1'): return 1
	return 0


def media_click_opens_info():
	return media_click_action() == 1


def use_upnext_episode():
	# Un seul réglage visible contrôle maintenant Up Next pour les deux modes.
	return get_setting('autoplay_next_episode', 'true') == 'true'

def autoplay_next_episode():
	# Mode lecture automatique : Up Next enchaîne directement l’épisode suivant.
	return auto_play('episode') and use_upnext_episode()

def autoplay_next_check_threshold():
	return int(get_setting('autoplay_next_check_threshold', '3'))

def autoplay_next_show_window():
	# Le plugin Up Next gère maintenant l'affichage de la fenêtre.
	# Les anciens réglages masqués ne doivent plus empêcher son déclenchement.
	return True

def autoplay_next_window_time():
	return int(get_setting('autoplay_next_window_time', '40'))

def autoplay_next_window_percentage():
	# Conservé pour compatibilité avec l'ancien retour de configuration.
	return int(get_setting('autoplay_next_window_percentage', '95'))

def autoplay_next_window_timer_method():
	# Mode fixe : temps restant. Le mode pourcentage est volontairement ignoré.
	return 'time'

def autoplay_next_settings():
	# Regroupe les réglages nécessaires à l'enchaînement automatique des épisodes.
	scraper_time = int(get_setting('scrapers.timeout.1', '60')) + 20
	threshold = autoplay_next_check_threshold()
	run_popup = autoplay_next_show_window()
	timer_method = autoplay_next_window_timer_method()
	window_time = autoplay_next_window_time() + 1
	window_percentage = 100 - autoplay_next_window_percentage()
	autoscrape_time = int(get_setting('autoscrape_next_window_time', '20'))
	return {
		'scraper_time': scraper_time, 'threshold': threshold, 'run_popup': run_popup,
		'timer_method': timer_method, 'window_time': window_time, 'window_percentage': window_percentage,
		'autoscrape_next_window_time': autoscrape_time
	}


# ---------------------------------------------------------------------------
# Calendrier, menus contextuels et affichage général
# ---------------------------------------------------------------------------

def autoscrape_next_episode():
	# Mode sélection de source : le même réglage Up Next ouvre le choix des liens.
	return not auto_play('episode') and use_upnext_episode()

def calendar_focus_today():
	return get_setting('trakt.calendar_focus_today') == 'true'

def calendar_sort_order():
	return int(get_setting('trakt.calendar_sort_order', '0'))

def context_menu_sort():
	# Ordre automatique du menu contextuel natif.
	# Les anciens réglages context.* ne sont plus lus : les entrées visibles
	# sont déterminées par les services réellement autorisés.
	return {
		'options': 10,
		'extras': 20,
		'mark': 30,
		'trakt': 40,
		'mdblist': 50,
		'tmdblist': 60,
		'rating': 70,
		'favourites': 21,
		'exit': 100
	}


def service_active(service):
	# État d'autorisation des services utilisés dans les menus contextuels.
	if service == 'trakt': return bool(get_setting('trakt_user', ''))
	if service == 'mdblist': return bool(get_setting('mdblist.access_token', '') or get_setting('mdblist.token', '') or get_setting('mdblist_user', ''))
	if service in ('tmdb', 'tmdblist'): return bool(get_setting('tmdb.token', ''))
	return False


def context_menu_services():
	return {
		'trakt': service_active('trakt'),
		'mdblist': service_active('mdblist'),
		'tmdblist': service_active('tmdb')
	}


def context_rating_enabled(media_type='movie'):
	provider = max(0, min(ratings_provider(), 3))
	# 3 = aucune notation utilisateur.
	if provider == 3: return False
	# TMDb ne permet pas de noter une saison individuellement.
	if media_type == 'season' and provider == 2: return False
	return (service_active('trakt'), service_active('mdblist'), service_active('tmdb'))[provider]


def context_favourites_enabled():
	# Les favoris alkoFlix sont toujours locaux.
	# Le fournisseur sélectionné sert uniquement de sauvegarde externe films/séries.
	return True

def date_offset():
	return int(get_setting('datetime.offset', '0')) + 5

def default_all_episodes():
	# Réglage conservé dans l'interface : Aplatir les saisons.
	# Les anciennes valeurs invalides éventuelles sont ramenées au comportement sûr.
	try: value = int(get_setting('default_all_episodes', '1'))
	except: value = 1
	return value if value in (0, 1, 2) else 1

def display_sleep_time():
	return 100

def display_uncached_torrents():
	return get_setting('torrent.display.uncached', 'false') == 'true'

# ---------------------------------------------------------------------------
# Répertoires et services externes
# ---------------------------------------------------------------------------

def download_directory(media_type):
	if media_type == 'movie': setting = 'movie_download_directory'
	elif media_type == 'episode': setting = 'tvshow_download_directory'
	elif media_type in ('thumb_url', 'image_url', 'image'): setting = 'image_download_directory'
	else: setting = 'premium_download_directory'
	if get_setting(setting) != '': return translate_path(get_setting(setting))
	else: return False

def easynews_active():
	# EasyNews n'est plus proposé par alkoFlix.
	return False

def easynews_language_filter():
	# Retourne l'état du filtre de langue Easynews et la liste des langues ciblées.
	enabled = get_setting('easynews.filter_lang') == 'true'
	filters = get_setting('easynews.lang_filters').split(', ') if enabled else []
	return enabled, filters

def enabled_debrids_check(debrid_service):
	# Un service de débridage est considéré actif seulement s'il est activé et authentifié.
	enabled = get_setting('%s.enabled' % debrid_service) == 'true'
	if not enabled: return False
	authed = get_setting('%s.token' % debrid_service)
	if authed in ('', None): return False
	return True


# ---------------------------------------------------------------------------
# Réglages des extras
# ---------------------------------------------------------------------------

def extras_enable_scrollbars():
	return get_setting('extras.enable_scrollbars', 'true')

def extras_exclude_non_acting():
	return get_setting('extras.exclude_non_acting_roles', 'true') == 'true'

def extras_enabled_menus():
	# La fenêtre Info & Extra moderne doit rester utile même si l'ancien réglage
	# extras.enabled_menus n'existe pas dans le profil utilisateur.
	# Par défaut, on affiche les deux sections visibles de cette fenêtre :
	# Distribution (2050) et recommandations (2051).
	setting = get_setting('extras.enabled_menus')
	if setting in ('', None, 'noop', []): setting = '2050,2051'
	return [int(i) for i in setting.split(',') if str(i).strip()]

def extras_open_action(media_type):
	# Ancien réglage neutralisé : les Extras passent maintenant par la fenêtre d'information native du skin.
	return False


def info_extra_window():
	# false/0 = fenêtre d'information du skin, true/1 = fenêtre d'information alkoFlix.
	value = get_setting('info_extra.window', 'true')
	if value in ('true', '1'): return 1
	return 0


def use_alkoflix_info_window():
	return info_extra_window() == 1


# ---------------------------------------------------------------------------
# Métadonnées, images et filtres
# ---------------------------------------------------------------------------

def fanarttv_client_key():
	default_key = get_setting('fanart_client_key', '30006d06f4d124007f5de4f568bd7bca')
	if get_setting('fanarttv.use_own_key') == 'true':
		return get_setting('fanart_client_key_user') or default_key
	return default_key

def filter_by_name(scraper):
	return get_setting('%s.title_filter' % scraper, 'false') == 'true'

def filter_status(filter_type):
	return int(get_setting('filter_%s' % filter_type, '0'))

def get_art_provider():
	# Détermine l'ordre de priorité entre TMDb et Fanart.tv selon les réglages.
	if not get_fanart_data(): return ('poster', 'poster2', 'fanart', 'fanart2')
	return {
		True: ('poster2', 'poster', 'fanart2', 'fanart'),
		False: ('poster', 'poster2', 'fanart', 'fanart2')
	}[get_setting('fanarttv.default') == 'true']

# Retourne True si Fanart.tv est activé et défini comme fournisseur principal.
def fanarttv_default():
	return get_fanart_data() and get_setting('fanarttv.default') == 'true'

# Résout le poster final selon la logique choisie par l'utilisateur.
# Si Fanart.tv est prioritaire, on tente d'abord ses visuels textuels,
# puis TMDb textuel, avant de retomber sur les variantes sans texte.
def resolve_poster_art(meta, fallback=''):
	if fanarttv_default():
		return meta.get('poster2_text') or meta.get('poster_text') or meta.get('poster2') or meta.get('poster') or fallback
	return meta.get('poster') or meta.get('poster2') or fallback

# Résout l'image landscape finale selon la même logique.
def resolve_landscape_art(meta, fallback=''):
	if fanarttv_default():
		return meta.get('landscape_text') or meta.get('landscape_tmdb_text') or meta.get('landscape') or meta.get('landscape_tmdb') or fallback
	return meta.get('landscape_tmdb') or meta.get('landscape') or fallback

def get_fanart_data():
	return get_setting('get_fanart_data') == 'true'

def get_language():
	# Langue des métadonnées TMDb. alkoFlix expose uniquement français et anglais.
	# Les anciennes installations peuvent encore contenir "fr", "fr-CA" ou une autre langue.
	# Tout ce qui n'est pas anglais est ramené sécuritairement vers fr-FR.
	language = get_setting('meta_language', 'fr-FR') or 'fr-FR'
	normalized = {
		'fr': 'fr-FR', 'fr-CA': 'fr-FR', 'fr_CA': 'fr-FR', 'fr-ca': 'fr-FR',
		'en-US': 'en', 'en_GB': 'en', 'en-GB': 'en'
	}.get(language, language)
	if normalized not in ('fr-FR', 'en'):
		normalized = 'fr-FR'
	if normalized != language:
		set_setting('meta_language', normalized)
		set_setting('meta_language_display', 'Anglais' if normalized == 'en' else 'Français')
	return normalized

def get_image_language():
	# Langue prioritaire des images TMDb. Seuls français et anglais sont exposés
	# dans les réglages afin de garder un comportement simple et prévisible.
	language = (get_setting('image_language', 'fr') or 'fr').lower()
	if language not in ('fr', 'en'):
		language = 'fr'
		set_setting('image_language', language)
		set_setting('image_language_display', 'Français')
	return language

def image_language_query():
	# TMDb retourne uniquement les langues demandées avec include_image_language.
	# Ordre voulu : langue choisie, fallback anglais/français, puis neutre.
	primary = get_image_language()
	fallback = 'en' if primary == 'fr' else 'fr'
	return '%s,%s,null' % (primary, fallback)

def certification_country():
	# Pays utilisé pour récupérer les classifications d'âge TMDb (MPAA, CSA, BBFC, etc.).
	# Accepte les anciens index numériques ET les codes pays directs (FR, CA, US...).
	countries = ('US', 'CA', 'FR', 'GB', 'DE', 'ES', 'IT', 'AU', 'BR')
	labels = (33203, 33204, 33205, 33206, 33207, 33208, 33209, 33210, 33211)
	value = (get_setting('certification.country', 'FR') or 'FR').strip()
	if value.upper() in countries:
		index = countries.index(value.upper())
	else:
		try: index = int(value)
		except: index = 2
		if index < 0 or index >= len(countries): index = 2
	try:
		display = ls(labels[index])
		if get_setting('certification.country_display', '') != display:
			set_setting('certification.country_display', display)
		if get_setting('parental.certification_country_display', '') != display:
			set_setting('parental.certification_country_display', display)
	except: pass
	return countries[index]

def get_resolution():
	return (
		{'poster': 'w185', 'fanart': 'w300', 'still': 'w185', 'profile': 'w185'},
		{'poster': 'w342', 'fanart': 'w780', 'still': 'w300', 'profile': 'w342'},
		{'poster': 'w780', 'fanart': 'w1280', 'still': 'original', 'profile': 'h632'},
		{'poster': 'original', 'fanart': 'original', 'still': 'original', 'profile': 'original'}
	)[int(get_setting('image_resolutions', '2'))]

def get_rpdb_data():
	return get_setting('get_rpdb_movies') == 'true', get_setting('get_rpdb_series') == 'true'

def ignore_articles():
	return get_setting('ignore_articles', 'true') == 'true'

def ignore_results_filter():
	return get_setting('ignore_results_filter') == 'true'

def include_prerelease_3d_results():
	return get_setting('include_prerelease_results') == 'true', get_setting('include_3d_results') == 'true'

def include_year_in_title(media_type):
	# Option retirée de l'interface : l'année n'est plus ajoutée aux libellés.
	# Les anciennes valeurs conservées dans addon_data sont ignorées pour éviter
	# des affichages différents d'un profil Kodi à l'autre.
	return False

DEFAULT_PERSONAL_SORT_CHOICES = (
	'title_asc', 'title_desc', 'date_desc', 'date_asc', 'added_desc', 'added_asc'
)


def default_list_sort(setting):
	# Réglage visible dans Affichage & Navigation > TRAKT / MDBLIST / TMDB / FAVORIS.
	# Il remplace les anciens tris globaux cachés pour les watchlists et favoris.
	defaults = {'watchlist': 4, 'favorites': 4}
	try:
		selected = int(get_setting('default_sort.%s' % setting, str(defaults.get(setting, 4))))
	except:
		selected = int(defaults.get(setting, 4))
	if selected < 0 or selected >= len(DEFAULT_PERSONAL_SORT_CHOICES):
		selected = int(defaults.get(setting, 4))
	return DEFAULT_PERSONAL_SORT_CHOICES[selected]


def _legacy_sort_type_from_key(sort_key):
	if str(sort_key or '').startswith('title'): return 0
	if str(sort_key or '').startswith('added'): return 1
	if str(sort_key or '').startswith('date'): return 2
	return 1

def lists_sort_order(setting):
	defaults = {'progress': 1, 'watched': 1, 'collection': 0, 'watchlist': 1, 'favorites': 1}
	if setting in ('watchlist', 'favorites'):
		return _legacy_sort_type_from_key(default_list_sort(setting))
	if setting in ('progress', 'watched', 'collection'):
		# Les réglages globaux de tri ont été retirés de l'interface.
		# On ignore donc les anciennes valeurs stockées dans le profil Kodi
		# pour éviter des tris invisibles impossibles à corriger.
		return defaults.get(setting, 0)
	try: return int(get_setting('sort.%s' % setting, str(defaults.get(setting, 0))))
	except: return int(defaults.get(setting, 0))

def lists_sort_reverse(setting):
	if setting == 'collection': return False
	if setting in ('watchlist', 'favorites'):
		return str(default_list_sort(setting)).endswith('_desc')
	if setting in ('progress', 'watched'): return True
	default_value = '0'
	try:
		value = int(get_setting('sort.%s.order' % setting, default_value))
	except:
		value = int(default_value)
	# Anciens tris : 0 = décroissant, 1 = croissant.
	return value == 0

def metadata_user_info():
	# Prépare le bloc de configuration transmis aux modules de métadonnées.
	tmdb_api = tmdb_api_key()
	image_resolution = get_resolution()
	meta_language = get_language()
	image_language = get_image_language()
	hide_watched = widget_hide_watched()
	menu_hide_watched_enabled = menu_hide_watched()
	fanart_client_key = fanarttv_client_key()
	if fanart_client_key: extra_fanart_enabled = get_fanart_data()
	else: extra_fanart_enabled = False
	rpdb_api = rpdb_api_key()
	if rpdb_api: extra_rpdb_movies, extra_rpdb_series = get_rpdb_data()
	else: extra_rpdb_movies, extra_rpdb_series = False, False
	return {
		'image_resolution': image_resolution , 'language': meta_language, 'image_language': image_language, 'widget_hide_watched': hide_watched,
		'menu_hide_watched': menu_hide_watched_enabled,
		'tmdb_api': tmdb_api, 'fanart_client_key': fanart_client_key, 'extra_fanart_enabled': extra_fanart_enabled,
		'certification_country': certification_country(),
		'rpdb_api_key': rpdb_api, 'extra_rpdb_movies': extra_rpdb_movies, 'extra_rpdb_series': extra_rpdb_series
	}

def movies_directory():
	return translate_path(get_setting('movies_directory'))

def nav_jump_use_alphabet():
	# Réglage retiré : l'accès direct à une page se fait maintenant depuis le menu contextuel de "Page suivante".
	# On retourne toujours 0 pour ignorer sans risque les anciennes valeurs stockées dans les profils existants.
	return 0


# ---------------------------------------------------------------------------
# Réglages Next Episode / widgets
# ---------------------------------------------------------------------------

def nextep_content_settings():
	include_unaired = get_setting('nextep.include_unaired') == 'true'
	include_unwatched = False # Ancien réglage désactivé volontairement : get_setting('nextep.include_unwatched') == 'true'
	sort_type = int(get_setting('nextep.sort_type'))
	sort_order = int(get_setting('nextep.sort_order'))
	sort_direction = sort_order == 0
	sort_key = 'alkoflix_last_played' if sort_type == 0 else 'alkoflix_first_aired' if sort_type == 1 else 'alkoflix_name'
	sort_airing_today_to_top = get_setting('nextep.sort_airing_today_to_top', 'false') == 'true'
	return {
		'include_unaired': include_unaired, 'include_unwatched': include_unwatched,
		'sort_type': sort_type, 'sort_order': sort_order, 'sort_direction': sort_direction, 'sort_key': sort_key,
		'sort_airing_today_to_top': sort_airing_today_to_top
	}

def nextep_display_settings():
	include_airdate = get_setting('nextep.include_airdate') == 'true'
	return {'unaired_color': 'cyan', 'unwatched_color': 'darkgoldenrod', 'include_airdate': include_airdate}

def paginate():
	# Portée volontairement limitée : longues listes personnelles/locales
	# (Trakt, MDBList, TMDb compte, favoris alkoFlix, suivis/vus).
	# Les menus publics TMDb/Discover gardent leur pagination API native.
	return get_setting('paginate.lists', 'true') == 'true'

def page_limit():
	# Nombre d'éléments par page pour les longues listes personnelles uniquement.
	# Les pages publiques TMDb restent sur des blocs API de 20 éléments.
	try: limit = int(get_setting('page_limit', '20'))
	except: limit = 20
	return max(1, min(limit, 500))

def tmdb_try_full_pages():
	# Réglage retiré de l'interface : alkoFlix complète maintenant les pages
	# TMDb/Discover en interne quand des filtres retirent trop d'éléments.
	return True


# ---------------------------------------------------------------------------
# Tri et affichage des résultats
# ---------------------------------------------------------------------------

def quality_filter(setting):
	return get_setting(setting).split(', ')

def results_priority_quality():
	quality = str(get_setting('results.priority_quality', '4K') or '4K').strip()
	if quality not in ('4K', '1080p', '720p'):
		quality = '4K'
		set_setting('results.priority_quality', quality)
	try:
		if get_setting('results.priority_quality_display', '4K') != quality:
			set_setting('results.priority_quality_display', quality)
	except Exception:
		pass
	return quality


def results_sort_priority():
	# Priorité principale du sélecteur pour les sources alkoFlix intégrées.
	# language = comportement francophone historique ; quality = qualité choisie avant langue.
	priority = str(get_setting('results.sort_priority', 'language') or 'language').strip().lower()
	if priority not in ('language', 'quality'):
		priority = 'language'
		set_setting('results.sort_priority', priority)
	try:
		display = 'Qualité' if priority == 'quality' else 'Langue'
		if get_setting('results.sort_priority_display', 'Langue') != display:
			set_setting('results.sort_priority_display', display)
	except Exception:
		pass
	return priority


def results_sort_order():
	# Tri secondaire fixe pour éviter les combinaisons trompeuses
	# Qualité/Fournisseur/Taille.
	# La priorité principale est gérée ensuite dans sources.py : Langue ou Qualité.
	direction = -1
	priority_quality = results_priority_quality()

	def priority_rank(item):
		try: return 0 if str(item.get('quality') or 'SD') == priority_quality else 1
		except Exception: return 1

	return lambda k: (priority_rank(k), k['quality_rank'], k['provider_rank'], direction*k['size'])


def results_only_fr_vostfr():
	return get_setting('results.only_fr_vostfr', 'false') == 'true'


def results_apply_to_external_sources():
	# Option volontairement désactivée par défaut : AIOStreams / Custom 1 / Custom 2
	# gardent leur ordre et leurs filtres de manifest sauf si l'utilisateur demande
	# explicitement à alkoFlix d'appliquer ses filtres/limites/tri globaux.
	return get_setting('results.apply_to_external_sources', 'false') == 'true'


def results_exclude_vfq_only():
	return get_setting('results.exclude_vfq_only', 'false') == 'true'


def results_exclude_vostfr_only():
	return get_setting('results.exclude_vostfr_only', 'false') == 'true'


def results_private_trackers_first():
	return get_setting('results.private_trackers_first', 'false') == 'true'


def results_comet_fallback():
	return get_setting('results.comet_fallback', 'false') == 'true'


def results_max_per_resolution():
	try: return max(0, int(get_setting('results.max_per_resolution', '0')))
	except: return 0


def results_max_total():
	try: return max(0, int(get_setting('results.max_total', '0')))
	except: return 0

RESULTS_XML_STYLE_MAP = {
	'list default': ('List Default', 'Liste'),
	'list contrast default': ('List Default', 'Liste'),
	'liste': ('List Default', 'Liste'),
	'liste par défaut': ('List Default', 'Liste'),
	'infolist default': ('InfoList Default', 'InfoListe'),
	'infolist contrast default': ('InfoList Default', 'InfoListe'),
	'infoliste': ('InfoList Default', 'InfoListe'),
	'infoliste par défaut': ('InfoList Default', 'InfoListe'),
	'widelist default': ('WideList Default', 'Liste large'),
	'widelist contrast default': ('WideList Default', 'Liste large'),
	'liste large': ('WideList Default', 'Liste large'),
	'liste large par défaut': ('WideList Default', 'Liste large')
}


def _results_xml_style_pair(value=None):
	style = str(value if value not in (None, '') else get_setting('results.xml_style', 'Liste large')).strip()
	return RESULTS_XML_STYLE_MAP.get(style.lower(), ('WideList Default', 'Liste large'))


def normalize_results_xml_style_display():
	current = get_setting('results.xml_style', 'Liste large')
	display = _results_xml_style_pair(current)[1]
	if current != display:
		set_setting('results.xml_style', display)
	return display


def results_xml_style():
	return _results_xml_style_pair()[0].lower()

def results_xml_window_number(window_style=None):
	if not window_style: window_style = results_xml_style()
	return {'list': 2000, 'infolist': 2001, 'widelist': 2002}[window_style.split(' ')[0]]

def favourites_import_source():
	# Ancienne compatibilité : le sélecteur a été retiré de l'interface.
	# Les actions dédiées transmettent maintenant directement le fournisseur voulu.
	try: selected = int(get_setting('favourites.import_service', '0'))
	except: selected = 0
	return {0: 4, 1: 1, 2: 3}.get(selected, 4)

def favourites_sync_source():
	# La synchronisation des favoris alkoFlix passe uniquement par alkoPastes.
	return 4

def root_favourites_source():
	# Les ajouts/retraits mettent à jour uniquement le backup alkoPastes.
	return 4

def ratings_provider():
	# 0 = Trakt, 1 = MDBList, 2 = TMDb, 3 = aucune notation utilisateur.
	try: return int(get_setting('ratings.provider', '3'))
	except: return 3

def rpdb_api_key():
	return get_setting('rpdb_api_key')


# ---------------------------------------------------------------------------
# Stockage cloud, dossiers et indicateurs de lecture
# ---------------------------------------------------------------------------

def store_resolved_torrent_to_cloud(debrid_service):
	return get_setting('store_torrent.%s' % debrid_service.lower()) == 'true'

def store_resolved_usenet_to_cloud(debrid_service):
	return get_setting('store_usenet.%s' % debrid_service.lower()) == 'true'

def show_specials():
	return get_setting('show_specials', 'false') == 'true'

def show_unaired():
	return get_setting('show_unaired', 'true') == 'true'

def show_unaired_watchlist():
	return get_setting('show_unaired_watchlist', 'true') == 'true'

def single_ep_display_title():
	# Option retirée de l'interface : TITRE : SXE - ÉPISODE.
	return 0

def single_ep_format():
	# Option retirée de l'interface : jour-mois-année.
	return '%d-%m-%Y'

def source_folders_directory(media_type, source):
	# Les dossiers locaux comme sources ne sont plus pris en charge par alkoFlix.
	# Retourne toujours False afin d'ignorer les anciens réglages conservés dans le profil Kodi.
	return False

def sync_kodi_library_watchstatus():
	return get_setting('sync_kodi_library_watchstatus') == 'true'

def thumb_fanart():
	# Option retirée de l'interface : les miniatures d'épisode ne sont pas
	# utilisées comme arrière-plan par défaut, même si un ancien profil les avait activées.
	return False

def tmdb_api_key():
	default_key = get_setting('tmdb_api', '14e469d80e2ff91a051f769dbd936757')
	if get_setting('tmdb.use_own_key') == 'true':
		return get_setting('tmdb_api_user') or default_key
	return default_key

def trakt_sync_interval():
	setting = get_setting('trakt.sync_interval', '25')
	interval = int(setting) * 60
	return setting, interval

def trakt_sync_refresh_widgets():
	# Depuis 1.4.16, le rafraîchissement automatique des widgets après
	# synchronisation Trakt/MDBList est désactivé. Sur les skins avec beaucoup
	# de widgets, Container.Refresh force Kodi à reconstruire toutes les
	# arborescences et peut rendre l'ouverture séries/saisons très lente.
	return False

def trakt_token():
	return get_setting('trakt.token')

def tv_show_directory():
	return translate_path(get_setting('tv_shows_directory'))

def use_season_title():
	# Option retirée de l'interface : utiliser le titre des saisons si disponible.
	return True

def watched_indicators():
	if get_setting('trakt_user') == '' and get_setting('mdblist_user') == '': return 0
	return int(get_setting('watched_indicators', '0'))

def widget_hide_watched():
	return get_setting('widget_hide_watched') == 'true'

def menu_hide_watched():
	return get_setting('menu_hide_watched') == 'true'

def hide_unreleased_movies():
	return get_setting('hide_unreleased_movies', 'false') == 'true'

def hide_unreleased_tvshows():
	return get_setting('hide_unreleased_tvshows', 'false') == 'true'


# ---------------------------------------------------------------------------
# Scrapers internes et services de débridage
# ---------------------------------------------------------------------------

default_internal_scrapers, cloud_scrapers = (
	'ad_cloud', 'rd_cloud', 'tb_cloud'
), ('ad_cloud', 'rd_cloud', 'tb_cloud')

def active_internal_scrapers():
	# Le système de sources alkoFlix est toujours disponible, sans écrire
	# d'ancien réglage caché dans addon_data/settings.xml.
	active = ['external']
	settings = [item[1] for item in (
		('ad', 'provider.ad_cloud'),
		('rd', 'provider.rd_cloud'),
		('tb', 'provider.tb_cloud')
	) if enabled_debrids_check(item[0])]
	active.extend(i.split('.')[1] for i in settings if get_setting(i) == 'true')
	return active

def check_prescrape_sources(scraper, media_type):
	# Indique si une source doit être vérifiée avant le scrape principal.
	if scraper in default_internal_scrapers: return get_setting('check.%s' % scraper) == 'true'
	if get_setting('check.%s' % scraper) == 'true' and get_setting('auto_play_%s' % media_type) != 'true': return True
	else: return False

def provider_sort_ranks():
	# Plus le rang est bas, plus le fournisseur remonte dans les résultats triés.
	ad_priority = int(get_setting('ad.priority', '9'))
	tb_priority = int(get_setting('tb.priority', '9'))
	rd_priority = int(get_setting('rd.priority', '10'))
	# Les débrideurs gardent leurs priorités configurées.
	# Les fournisseurs natifs reçoivent aussi un rang stable afin que le choix
	# « Fournisseur » dans l'ordre de tri ait un effet réel dans le sélecteur.
	return {
		'alldebrid': ad_priority, 'ad_cloud': ad_priority,
		'real-debrid': rd_priority, 'rd_cloud': rd_priority,
		'torbox': tb_priority, 'tb_cloud': tb_priority,
		'folders': 0,
		'ygg': 1, 'alkopaste': 2, 'comet': 3, 'nyaa': 4,
		'c411': 5, 'torr9': 6, 'tr4ker': 7, 'yggreborn': 8, 'hydracker': 9,
		'movix': 10, 'free_telecharger': 11,
		# Utilisés seulement lorsque l'option d'application des tris/filtres aux
		# sources externes personnelles est activée. Par défaut, ces sources restent
		# hors tri global et conservent l'ordre du manifest.
		'aiostreams': 20, 'aiostreams_custom': 20,
		'custom_1': 21, 'custom_stremio1': 21,
		'custom_2': 22, 'custom_stremio2': 22
	}

def sort_to_top(provider):
	return get_setting({
		'ad_cloud': 'results.sort_adcloud_first',
		'rd_cloud': 'results.sort_rdcloud_first',
		'tb_cloud': 'results.sort_tbcloud_first',
		'folders': 'results.sort_folders_first'
	}[provider]) == 'true'


# ---------------------------------------------------------------------------
# Couleurs et icônes des résultats
# ---------------------------------------------------------------------------

def scraping_settings():
	# Depuis 1.4.30, la mise en évidence du sélecteur est uniquement basée
	# sur la qualité vidéo. Les anciens modes Type de source / Fournisseur
	# sont conservés seulement sous forme de clés vides pour compatibilité
	# avec la fenêtre de résultats, mais ils ne pilotent plus l'affichage.
	highlight_4K = get_setting('scraper_4k_highlight', 'fuchsia')
	highlight_1080P = get_setting('scraper_1080p_highlight', 'lawngreen')
	highlight_720P = get_setting('scraper_720p_highlight', 'gold')
	highlight_SD = get_setting('scraper_SD_highlight', 'lightsaltegray')
	blank = ''
	return {
		'alldebrid': blank, 'ad_cloud': blank,
		'real-debrid': blank, 'rd_cloud': blank,
		'torbox': blank, 'tb_cloud': blank,
		'aiostreams': blank, 'aiostreams_custom': blank, 'ygg': blank,
		'c411': blank, 'torr9': blank, 'tr4ker': blank, 'yggreborn': blank, 'hydracker': blank,
		'custom_1': blank, 'custom_2': blank,
		'custom_stremio1': blank, 'custom_stremio2': blank,
		'uncached': 'dimgray', 'highlight_type': 2, 'folders': blank,
		'hoster_highlight': blank, 'torrent_highlight': blank,
		'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P,
		'sd': highlight_SD, 'cam': highlight_SD, 'tele': highlight_SD, 'scr': highlight_SD,
	}

def info_icons():
	# Associe chaque type de source ou de qualité à son icône d'affichage.
	return (
		('alldebrid', 'alldebrid.png'), ('ad_cloud', 'alldebrid.png'),
		('real-debrid', 'realdebrid.png'), ('rd_cloud', 'realdebrid.png'),
		('torbox', 'torbox.png'), ('tb_cloud', 'torbox.png'),
		('folders', 'myfolder.png'),
		('4k', 'flag4k.png'), ('1080p', 'flag1080p.png'), ('720p', 'flag720p.png'),
		('sd', 'flagSD.png'), ('cam', 'flagSD.png'), ('tele', 'flagSD.png'), ('scr', 'flagSD.png')
	)
