# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/hydracker.py

import re
from alko.control import setting as getSetting
from modules.private_torznab import PrivateTorznabSource


class source(PrivateTorznabSource):
	provider_key = 'hydracker'
	provider_name = 'Hydracker'
	api_setting = 'private.hydracker.api_key'
	base_url = 'https://hydracker.com/api/v1/torznab'
	response_mode = 'xml'

	# Hydracker expose un indexeur Generic Torznab compatible *arr.
	# L'URL est fixe côté alkoFlix ; l'utilisateur renseigne uniquement sa clé API.
	auth_mode = 'query_apikey'
	auth_modes = ('query_apikey',)
	try_next_auth_on_empty = False

	# Comportement proche de YGGReborn : IDs en premier, puis recherche texte avec
	# validation locale stricte pour éviter les faux positifs.
	trust_api_results = False
	allow_loose_private_match = False

	# Limite indiquée par Hydracker : 300 requêtes / heure, donc 5 / minute maximum.
	max_requests_per_minute = 5
	# Ne jamais bloquer le sélecteur : si la limite locale est atteinte, on saute Hydracker.
	max_rate_limit_wait = 0
	# Quand Hydracker ne trouve rien, on évite de multiplier les fallbacks pendant trop longtemps.
	max_empty_chain_requests = 3
	timeout = 5
	priority = 4

	def __init__(self):
		PrivateTorznabSource.__init__(self)

	def _api_key(self):
		try:
			return (getSetting(self.api_setting) or '').strip()
		except:
			return ''

	def _request_attempts(self, params, api_key):
		# Hydracker est présenté comme Generic Torznab. Prowlarr/arr utilisent
		# l'API avec apikey en query string, mais le site peut refuser les
		# requêtes trop "python-requests". On utilise donc des en-têtes propres
		# et on ne force pas de paramètre non documenté comme extended=1.
		base_headers = {
			'User-Agent': 'Prowlarr/1.0 (compatible; alkoFlix)',
			'Accept': 'application/rss+xml, application/xml, text/xml, */*',
			'Referer': 'https://hydracker.com/',
		}
		request_params = dict(params or {})
		attempts = []
		if api_key:
			query_params = dict(request_params)
			query_params['apikey'] = api_key
			attempts.append((self.base_url, query_params, dict(base_headers), 'query_apikey'))

			header_params = dict(request_params)
			header_headers = dict(base_headers)
			header_headers['X-Api-Key'] = api_key
			attempts.append((self.base_url, header_params, header_headers, 'x_api_key'))
		return attempts

	def _configured(self):
		return bool(self._api_key())

	def _clean_tmdb_id(self, data):
		try:
			value = str((data or {}).get('tmdb') or (data or {}).get('tmdb_id') or '').strip()
			if not value: return ''
			match = re.search(r'(\d+)', value)
			return match.group(1) if match else ''
		except:
			return ''

	def _clean_imdb_id(self, data):
		try:
			value = str((data or {}).get('imdb') or (data or {}).get('imdb_id') or '').strip()
			if not value: return ''
			if value.lower() in ('none', 'null', 'false', '0'): return ''
			match = re.search(r'tt\d+', value, re.I)
			if match: return match.group(0).lower()
			match = re.search(r'\d+', value)
			return 'tt%s' % match.group(0) if match else ''
		except:
			return ''

	def _query_text(self, *parts):
		try:
			text = ' '.join(str(i or '').strip() for i in parts if str(i or '').strip())
			return re.sub(r'\s+', ' ', text).strip()
		except:
			return ''

	def _id_params_chain(self, data, search_type, include_episode=False, season_only=False):
		params_list = []
		try:
			base = {'t': search_type}
			if include_episode or season_only:
				season = (data or {}).get('season')
				if season not in ('', None): base['season'] = str(season)
			if include_episode:
				episode = (data or {}).get('episode')
				if episode not in ('', None): base['ep'] = str(episode)

			imdb = self._clean_imdb_id(data)
			if imdb:
				params = dict(base)
				params['imdbid'] = imdb
				self._append_unique_params(params_list, params)

			tmdb = self._clean_tmdb_id(data)
			if tmdb:
				params = dict(base)
				params['tmdbid'] = tmdb
				self._append_unique_params(params_list, params)
		except:
			pass
		return params_list

	def _movie_params(self, data):
		params_list = self._id_params_chain(data, 'movie')
		try:
			query = self._query_text(data.get('title'), data.get('year'))
			if query:
				self._append_unique_params(params_list, {'t': 'search', 'q': query})
			title_only = self._query_text(data.get('title'))
			if title_only and title_only != query:
				self._append_unique_params(params_list, {'t': 'search', 'q': title_only})
		except:
			pass
		return params_list

	def _episode_params(self, data):
		params_list = self._id_params_chain(data, 'tvsearch', include_episode=True)
		try:
			season = int(data.get('season') or 0)
			episode = int(data.get('episode') or 0)
			show = self._query_text(data.get('tvshowtitle'))
			if show and season and episode:
				self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show, 'season': str(season), 'ep': str(episode)})
				self._append_unique_params(params_list, {'t': 'search', 'q': '%s S%02dE%02d' % (show, season, episode)})
				self._append_unique_params(params_list, {'t': 'search', 'q': '%s %dx%02d' % (show, season, episode)})
		except:
			pass
		return params_list

	def _season_params(self, data):
		params_list = self._id_params_chain(data, 'tvsearch', season_only=True)
		try:
			season = int(data.get('season') or 0)
			show = self._query_text(data.get('tvshowtitle'))
			if show and season:
				self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show, 'season': str(season)})
				self._append_unique_params(params_list, {'t': 'search', 'q': '%s S%02d' % (show, season)})
		except:
			pass
		return params_list

	def _show_params(self, data):
		params_list = self._id_params_chain(data, 'tvsearch')
		try:
			show = self._query_text(data.get('tvshowtitle'))
			if show:
				self._append_unique_params(params_list, {'t': 'tvsearch', 'q': show})
				self._append_unique_params(params_list, {'t': 'search', 'q': show})
		except:
			pass
		return params_list

	def sources(self, data, hostDict):
		if not self._configured(): return []
		return PrivateTorznabSource.sources(self, data, hostDict)

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None):
		if not self._configured(): return []
		return PrivateTorznabSource.sources_packs(self, data, hostDict, search_series, total_seasons)
