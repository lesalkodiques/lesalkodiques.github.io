# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/service.py

import time
import json
from threading import Thread
from modules import kodi_utils, settings

logger, path_exists, translate_path = kodi_utils.logger, kodi_utils.path_exists, kodi_utils.translate_path
monitor, is_playing, get_visibility = kodi_utils.monitor, kodi_utils.player.isPlaying, kodi_utils.get_visibility
get_property, set_property, clear_property = kodi_utils.get_property, kodi_utils.set_property, kodi_utils.clear_property
get_setting, set_setting, make_settings_dict = kodi_utils.get_setting, kodi_utils.set_setting, kodi_utils.make_settings_dict

def initializeDatabases():
	from modules.cache import check_databases
	logger('alkoFlix', 'InitializeDatabases Service Starting')
	check_databases()
	return logger('alkoFlix', 'InitializeDatabases Service Finished')

def checkSettingsFile():
	logger('alkoFlix', 'CheckSettingsFile Service Starting')
	clear_property('alkoflix_settings')
	profile_dir = kodi_utils.get_addoninfo('profile')
	profile_xml = profile_dir + 'settings.xml'
	if not path_exists(profile_xml):
		kodi_utils.make_directorys(profile_dir)
		kodi_utils.addon().setSetting('kodi_menu_cache', 'true')
		kodi_utils.sleep(500)
	make_settings_dict()
	set_property('alkoflix_kodi_menu_cache', get_setting('kodi_menu_cache'))
	set_property('alkoflix_rli_fix', get_setting('rli_fix'))
	return logger('alkoFlix', 'CheckSettingsFile Service Finished')

def handleCatalogueManifestChange(previous_url='', current_url=''):
	previous_url = (previous_url or '').strip()
	current_url = (current_url or '').strip()
	if previous_url == current_url: return
	logger('alkoFlix', 'Catalogue custom manifest setting changed')
	try:
		from catalogue.catalogs import clear_catalogue_cache
		clear_catalogue_cache()
	except Exception as e:
		logger('Catalogue manifest cache clear failed', str(e))
	try:
		from caches.navigator_cache import navigator_cache
		# Force la prochaine ouverture du menu racine à relire la DB au lieu de
		# réutiliser les propriétés de fenêtre déjà en mémoire.
		navigator_cache.delete_memory_cache('RootList', 'default')
		navigator_cache.delete_memory_cache('RootList', 'edited')
	except Exception as e:
		logger('Catalogue root menu cache clear failed', str(e))
	try:
		if 'alkoflix' in kodi_utils.get_infolabel('Container.PluginName').lower():
			kodi_utils.container_refresh()
	except Exception as e:
		logger('Catalogue root refresh skipped', str(e))

def databaseMaintenance():
	from modules.cache import clean_databases
	current_time = int(time.time())
	next_clean = current_time + 259200 # 3 days
	due_clean = int(get_setting('database.maintenance.due', '0'))
	if current_time < due_clean: return
	logger('alkoFlix', 'Database Maintenance Service Starting')
	clean_databases(current_time, database_check=False, silent=True)
	set_setting('database.maintenance.due', str(next_clean))
	return logger('alkoFlix', 'Database Maintenance Service Finished')

def viewsSetWindowProperties():
	logger('alkoFlix', 'ViewsSetWindowProperties Service Starting')
	kodi_utils.set_view_properties()
	return logger('alkoFlix', 'ViewsSetWindowProperties Service Finished')

def reuseLanguageInvokerCheck():
	import xml.etree.ElementTree as ET
	logger('alkoFlix', 'ReuseLanguageInvokerCheck Service Starting')
	addon_xml = translate_path('special://home/addons/plugin.video.alkoflix/addon.xml')
	tree = ET.parse(addon_xml)
	root = tree.getroot()
	current_addon_setting = get_setting('reuse_language_invoker', 'false')
	text = '[B]ReuseLanguageInvoker[/B] PARAMÈTRE INCOMPATIBLE [CR]alkoFlix rechargera votre profil pour actualiser le fichier addon.xml'
	item, refresh = next(root.iter('reuselanguageinvoker'), None), False
	if item is None: kodi_utils.notification(text.split('[CR]')[0])
	if not item is None and not item.text == current_addon_setting:
		item.text = current_addon_setting
		tree.write(addon_xml)
		refresh = True
	if refresh and kodi_utils.confirm_dialog(text=text):
		kodi_utils.execute_builtin('LoadProfile(%s)' % kodi_utils.get_infolabel('system.profilename'))
	return logger('alkoFlix', 'ReuseLanguageInvokerCheck Service Finished')

def autoRun():
	logger('alkoFlix', 'AutoRun Service Starting')
	if settings.auto_start_alkoflix(): kodi_utils.execute_builtin('RunAddon(plugin.video.alkoflix)')
	return logger('alkoFlix', 'AutoRun Service Finished')

def clearSubs():
	logger('alkoFlix', 'Clear Subtitles Service Starting')
	sub_formats = ('.srt', '.ssa', '.smi', '.sub', '.idx')
	subtitle_path = 'special://temp/'
	for i in kodi_utils.list_dirs(subtitle_path)[1]:
		if i.startswith('alkoFlixSubs_') or i.endswith(sub_formats):
			kodi_utils.delete_file(subtitle_path + i)
	return logger('alkoFlix', 'Clear Subtitles Service Finished')

def cleanObsoleteUiFiles():
	logger('alkoFlix', 'Obsolete UI Cleanup Service Starting')
	obsolete_files = (
		'special://home/addons/plugin.video.alkoflix/resources/skins/Default/1080i/extras.xml',
	)
	for obsolete_file in obsolete_files:
		try:
			if path_exists(obsolete_file):
				kodi_utils.delete_file(obsolete_file)
				logger('alkoFlix', 'Obsolete UI Cleanup Removed: %s' % obsolete_file)
		except Exception as exc:
			logger('alkoFlix', 'Obsolete UI Cleanup Failed: %s - %s' % (obsolete_file, exc))
	return logger('alkoFlix', 'Obsolete UI Cleanup Service Finished')

def _version_tuple(version):
	import re
	numbers = [int(i) for i in re.findall(r'\d+', str(version or ''))]
	while len(numbers) < 3: numbers.append(0)
	return tuple(numbers)

def _installed_alkoflix_version():
	import xml.etree.ElementTree as ET
	try:
		addon_xml = translate_path('special://home/addons/plugin.video.alkoflix/addon.xml')
		root = ET.parse(addon_xml).getroot()
		return root.get('version') or kodi_utils.get_addoninfo('version')
	except Exception:
		return kodi_utils.get_addoninfo('version')

def _remote_alkoflix_version():
	import re, requests
	version_url = 'https://paste.lesalkodiques.com/raw/GvhcmrrZ'
	response = requests.get(version_url, headers={'Cache-Control': 'no-cache'}, timeout=15.0)
	response.raise_for_status()
	match = re.search(r'\d+(?:\.\d+)*', response.text.strip())
	return match.group(0) if match else ''

def _open_install_from_zip():
	logger('alkoFlix', 'Update Check Service Opening InstallFromZip')
	kodi_utils.execute_builtin('InstallFromZip')

def checkAlkoFlixUpdate(force=False):
	current_time = int(time.time())
	next_check = int(get_setting('alkoflix.update_check.due', '0'))
	if not force and current_time < next_check: return
	set_setting('alkoflix.update_check.due', str(current_time + 43200)) # 12 heures
	logger('alkoFlix', 'Update Check Service Starting')
	try:
		installed_version = _installed_alkoflix_version()
		remote_version = _remote_alkoflix_version()
		if not remote_version:
			return logger('alkoFlix', 'Update Check Service Finished - No remote version found')
		if _version_tuple(remote_version) <= _version_tuple(installed_version):
			return logger('alkoFlix', 'Update Check Service Finished - No update available')

		text = (
			'Une nouvelle version de alkoFlix est disponible.[CR][CR]'
			'Votre version : %s[CR]'
			'Nouvelle version : %s[CR][CR]'
			'Voulez-vous ouvrir l\'écran d\'installation depuis un fichier ZIP ?'
		) % (installed_version, remote_version)
		logger('alkoFlix', 'Update Check Service Update Available - Installed: %s / Remote: %s' % (installed_version, remote_version))
		if not kodi_utils.confirm_dialog(heading='alkoFlix', text=text, ok_label='Oui', cancel_label='Non', top_space=True):
			return logger('alkoFlix', 'Update Check Service Finished - Update declined by user')
		_open_install_from_zip()

	except Exception as exc:
		logger('alkoFlix', 'Update Check Service Failed: %s' % exc)
		kodi_utils.notification('Vérification de mise à jour impossible', 3000)
	return logger('alkoFlix', 'Update Check Service Finished')

def alkoFlixUpdateMonitor():
	logger('alkoFlix', 'Update Monitor Service Starting')
	while not monitor.abortRequested():
		while is_playing() or get_visibility('Container().isUpdating') or get_property('alkoflix_pause_services') == 'true':
			if monitor.waitForAbort(10): return
		try: checkAlkoFlixUpdate()
		except Exception as exc: logger('alkoFlix', 'Update Monitor Loop Failed: %s' % exc)
		if monitor.waitForAbort(3600): break
	return logger('alkoFlix', 'Update Monitor Service Finished')

def traktMonitor():
	from caches.trakt_cache import clear_trakt_list_contents_data
	from indexers.trakt_api import trakt_sync_activities
	from indexers.mdblist_api import mdbl_sync_activities, clear_mdbl_cache
	from indexers.tmdb_api import tmdb_clean_watchlist, clear_tmdbl_cache
	logger('alkoFlix', 'TraktMonitor Service Starting')
	trakt_service_string = 'TraktMonitor Service Update %s - %s'
	update_string = 'Next Update in %s minutes...'
	if not kodi_utils.get_property('alkoflix_traktmonitor_first_run') == 'true':
		for i in ('user_lists', 'liked_lists', 'my_lists'): clear_trakt_list_contents_data(i)
		clear_mdbl_cache()
		clear_tmdbl_cache()
		kodi_utils.set_property('alkoflix_traktmonitor_first_run', 'true')
	while not monitor.abortRequested():
		while is_playing() or get_visibility('Container().isUpdating') or get_property('alkoflix_pause_services') == 'true':
			monitor.waitForAbort(10)
		if not kodi_utils.get_property('alkoflix_traktmonitor_first_run') == 'true':
			monitor.waitForAbort(5)
		value, interval = settings.trakt_sync_interval()
		next_update_string = update_string % value
		try: status = trakt_sync_activities()
		except: status = 'failed'
		if status == 'success':
			logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Success', 'Trakt Update Performed'))
			if settings.trakt_sync_refresh_widgets():
				kodi_utils.widget_refresh()
				logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Widgets Refresh', 'Setting Activated. Widget Refresh Performed'))
			else: logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Widgets Refresh', 'Setting Disabled. Skipping Widget Refresh'))
		elif status == 'no account':
			logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Aborted. No Trakt Account Active', next_update_string))
		elif status == 'failed':
			logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Failed. Error from Trakt', next_update_string))
		else:# 'not needed'
			logger('alkoFlix', trakt_service_string % ('alkoFlix TraktMonitor - Success. No Changes Needed', next_update_string))
		try: status = mdbl_sync_activities()
		except: status = 'failed'
		if status == 'success':
			logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Success', 'MDBList Update Performed'))
			if settings.trakt_sync_refresh_widgets():
				kodi_utils.widget_refresh()
				logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Widgets Refresh', 'Setting Activated. Widget Refresh Performed'))
			else: logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Widgets Refresh', 'Setting Disabled. Skipping Widget Refresh'))
		elif status == 'no account':
			logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Aborted. No MDBList Account Active', next_update_string))
		elif status == 'failed':
			logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Failed. Error from MDBList', next_update_string))
		else:# 'not needed'
			logger('alkoFlix', trakt_service_string % ('alkoFlix MDBListMonitor - Success. No Changes Needed', next_update_string))
		try:
			if get_setting('tmdb.token') and get_setting('tmdblist.watchlist_sync') == 'true':
				status = tmdb_clean_watchlist(silent=True)
				if status: logger('alkoFlix', 'TMDB Lists Service Update - Success. %s' % status)
		except: pass
		monitor.waitForAbort(interval)
	return logger('alkoFlix', 'TraktMonitor Service Finished')

def premAccntNotification():
	logger('alkoFlix', 'Debrid Account Expiry Notification Service Starting')
	from importlib import import_module
	for user, expires, module, cls in (
		('ad.account_id', 'ad.expires', 'alldebrid_api', 'AllDebridAPI'),
		('pm.account_id', 'pm.expires', 'premiumize_api', 'PremiumizeAPI'),
		('rd.username', 'rd.expires', 'real_debrid_api', 'RealDebridAPI'),
		('tb.account_id', 'tb.expires', 'torbox_api', 'TorBoxAPI')
	):
		try:
			if not get_setting(user): continue
			if limit := int(get_setting(expires, '7')):
				module = 'debrids.%s' % module
				cls = getattr(import_module(module), cls)
				days_remaining = cls().days_remaining()
				if not days_remaining is None and days_remaining <= limit:
					kodi_utils.notification('%s expires in %s days' % (cls.__name__, days_remaining))
		except: pass
	return logger('alkoFlix', 'Debrid Account Expiry Notification Service Finished')

def checkUndesirablesDatabase():
	from alko.undesirables import Undesirables, add_new_default_keywords
	logger('alkoFlix', 'CheckUndesirablesDatabase Service Starting')
	old_database = Undesirables().check_database()
	if old_database: add_new_default_keywords()
	return logger('alkoFlix', 'CheckUndesirablesDatabase Service Finished')

def upnextPlayAction(data):
	def _run(params):
		try:
			if isinstance(params, str):
				try: params = json.loads(params)
				except: pass
			if isinstance(params, list) and params:
				params = params[0]
			if not isinstance(params, dict):
				logger('alkoFlix', 'UpNext Play Action Failed - Invalid data: %s' % str(params))
				return kodi_utils.notification('Up Next : données invalides', 3000)

			params = dict(params)
			handoff = params.pop('nextep_handoff', '')
			if handoff: kodi_utils.set_property('alkoflix_nextep_handoff', handoff)
			# Up Next peut maintenant servir autant le mode lecture automatique
			# que le mode sélection de source. On respecte donc l'intention
			# transmise dans play_info, avec une exception volontaire : si un
			# bingeGroup est transmis, l'enchaînement Up Next peut choisir
			# automatiquement un lien similaire au premier lien sélectionné.
			requested_autoplay = str(params.get('autoplay', 'true')).lower()
			binge_autoplay = str(params.get('upnext_binge_autoplay', 'false')).lower() in ('true', '1', 'yes', 'on')
			params['autoplay'] = 'true' if binge_autoplay else ('false' if requested_autoplay in ('false', '0', 'no', 'off') else 'true')
			params['media_type'] = 'episode'

			from modules.sources import SourceSelect
			try: SourceSelect.nextep_params.clear()
			except: pass

			logger('alkoFlix', 'UpNext Plugin Play Action Starting - S%sE%s' % (params.get('season'), params.get('episode')))
			if handoff:
				# Laisse au lecteur courant le temps de finaliser le scrobble Trakt
				# avant de lancer la sélection/lecture de l’épisode suivant.
				kodi_utils.sleep(1500)
			SourceSelect.factory(params)
			logger('alkoFlix', 'UpNext Plugin Play Action Finished')
		except Exception as exc:
			logger('alkoFlix', 'UpNext Play Action Failed: %s' % exc)
			try: kodi_utils.notification('Up Next : lecture impossible', 3000)
			except: pass

	Thread(target=_run, args=(data,)).start()

def registerUpNextProvider():
	try:
		try:
			import AddonSignals
		except Exception:
			from addon import signals as AddonSignals

		signal = '%s_play_action' % kodi_utils.get_addoninfo('id')
		AddonSignals.registerSlot('upnextprovider', signal, upnextPlayAction)
		logger('alkoFlix', 'UpNext Provider Registered: %s' % signal)
	except Exception as exc:
		logger('alkoFlix', 'UpNext Provider Registration Failed: %s' % exc)

class AlkoFlixMonitor(kodi_utils.xbmc_monitor):
	def __enter__(self):
		self.threads = (Thread(target=traktMonitor), Thread(target=premAccntNotification), Thread(target=alkoFlixUpdateMonitor))
		return self

	def __exit__(self, exc_type, exc_value, traceback):
		for i in self.threads: i.join()

	def startUpServices(self):
		try: initializeDatabases()
		except: pass
		try: checkSettingsFile()
		except: pass
		try: databaseMaintenance()
		except: pass
		try: viewsSetWindowProperties()
		except: pass
		try: reuseLanguageInvokerCheck()
		except: pass
		for i in self.threads: i.start()
		try: autoRun()
		except: pass
		try: clearSubs()
		except: pass
		try: cleanObsoleteUiFiles()
		except: pass
		try: registerUpNextProvider()
		except: pass
		try: checkUndesirablesDatabase()
		except: pass

	def onScreensaverActivated(self):
		set_property('alkoflix_pause_services', 'true')

	def onScreensaverDeactivated(self):
		clear_property('alkoflix_pause_services')

	def onSettingsChanged(self):
		previous_catalogue_manifest = get_setting('catalogue.custom.manifest_url', '')
		clear_property('alkoflix_settings')
		kodi_utils.sleep(50)
		make_settings_dict()
		current_catalogue_manifest = get_setting('catalogue.custom.manifest_url', '')
		set_property('alkoflix_kodi_menu_cache', get_setting('kodi_menu_cache'))
		set_property('alkoflix_rli_fix', get_setting('rli_fix'))
		handleCatalogueManifestChange(previous_catalogue_manifest, current_catalogue_manifest)

	def onNotification(self, sender, method, data):
		if method == 'System.OnSleep': set_property('alkoflix_pause_services', 'true')
		elif method == 'System.OnWake': clear_property('alkoflix_pause_services')


logger('alkoFlix', 'Main Monitor Service Starting')
logger('alkoFlix', 'Settings Monitor Service Starting')

with AlkoFlixMonitor() as alkoflix:
	alkoflix.startUpServices()
	alkoflix.waitForAbort()

logger('alkoFlix', 'Settings Monitor Service Finished')
logger('alkoFlix', 'Main Monitor Service Finished')
