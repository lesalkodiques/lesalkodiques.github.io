import json
import sys
import unicodedata
from urllib.parse import unquote
from windows import open_window
from indexers.tmdb_api import tmdb_people_info, tmdb_people_popular_media, tmdb_image_base
from menus.images import Images
from modules.kodi_utils import media_path, select_dialog, dialog, notification, build_url, make_listitem, add_item, add_items, add_dir, end_directory, set_category, set_content, set_view_mode, get_addoninfo, local_string
# from modules.kodi_utils import logger



NON_LATIN_PERSON_SCRIPTS = (
	'CJK', 'HIRAGANA', 'KATAKANA', 'HANGUL', 'BOPOMOFO',
	'THAI', 'LAO', 'KHMER', 'MYANMAR', 'DEVANAGARI', 'BENGALI',
	'GURMUKHI', 'GUJARATI', 'ORIYA', 'TAMIL', 'TELUGU', 'KANNADA',
	'MALAYALAM', 'SINHALA', 'TIBETAN', 'MONGOLIAN'
)

# Évite les noms en écritures non latines qui peuvent être illisibles selon la police du skin.
def _valid_person_name(name):
	try:
		name = str(name or '').strip()
		if not name: return False
		for char in name:
			if char.isspace() or char in "-.'’`´": continue
			unicode_name = unicodedata.name(char, '')
			if any(script in unicode_name for script in NON_LATIN_PERSON_SCRIPTS): return False
		return True
	except: return False


def _known_for_text(item, media_type=None):
	try:
		known_for = item.get('known_for', []) or []
		if media_type: known_for = [i for i in known_for if i.get('media_type') == media_type]
		titles = [i.get('title') or i.get('name') for i in known_for if (i.get('title') or i.get('name'))]
		return ', '.join(titles[:3])
	except: return ''

poster_empty = media_path('people.png')

def popular_people():
	Images().run({'mode': 'popular_people_image_results', 'page_no': 1})

def person_data_dialog(params):
	if 'query' in params: query = unquote(params['query'])
	else: query = None
	open_window(
		('windows.people', 'People'),
		'people.xml',
		query=query,
		actor_id=params.get('actor_id'),
		actor_name=params.get('actor_name'),
		actor_image=params.get('actor_image')
	)

def person_search(query=None):
	try: actors = tmdb_people_info(query)
	except: actors = None
	if not actors: return notification(32760)
	for item in actors:
		known_for_list = [i['title'] for i in item['known_for'] if 'title' in i and i['title']]
		item['icon'] = tmdb_image_base % ('h632', item['profile_path']) if item['profile_path'] else poster_empty
		item['line1'] = item['name']
		item['line2'] = ', '.join(known_for_list) if known_for_list else ''
	if len(actors) > 1:
		kwargs = {'items': json.dumps(actors), 'heading': 'alkoFlix', 'multi_line': 'true'}
		selection = select_dialog(actors, **kwargs)
		if selection is None: return
	else: selection = actors[0]
	actor = int(selection['id']), selection['name'], selection['icon']
	if not actor: return
	return person_data_dialog({'actor_id': actor[0], 'actor_name': actor[1], 'actor_image': actor[2]})



class PeopleMenu:
	def __init__(self, params):
		params['handle'] = int(sys.argv[1])
		params['fanart'] = get_addoninfo('fanart')
		self.params = params
		self.params_get = params.get
		self.handle = params['handle']
		self.fanart = params['fanart']
		self.next_icon = media_path('item_next.png')

	def root(self):
		n_ins = 'Personnes'
		add_dir(self.handle, {'mode': 'search_history', 'action': 'people', 'name': 'Recherche'}, 'Recherche', media_path('search.png'))
		add_dir(self.handle, {'mode': 'people.results', 'action': 'popular_movies', 'name': 'Personnes populaires dans les films'}, 'Personnes populaires dans les films', media_path('movies.png'))
		add_dir(self.handle, {'mode': 'people.results', 'action': 'popular_tvshows', 'name': 'Personnes populaires dans les séries'}, 'Personnes populaires dans les séries', media_path('tv.png'))
		set_category(self.handle, n_ins)
		set_content(self.handle, '')
		end_directory(self.handle)
		set_view_mode('view.main', '')

	def results(self):
		action = self.params_get('action', 'popular_movies')
		try: page_no = int(self.params_get('new_page', '1'))
		except: page_no = 1
		media_type = 'tv' if 'tvshow' in action else 'movie'
		data = tmdb_people_popular_media(media_type, page_no) or {}
		items = self._build_people_items(data.get('results', []), media_type)
		if items: add_items(self.handle, items)
		try:
			if int(data.get('total_pages', 1)) > page_no:
				next_params = {
					'mode': 'people.results', 'action': action, 'new_page': str(page_no + 1),
					'name': self.params_get('name', 'Personnes')
				}
				add_dir(self.handle, next_params, local_string(32799), self.next_icon)
		except: pass
		set_category(self.handle, self.params_get('name', 'Personnes'))
		set_content(self.handle, 'actors')
		end_directory(self.handle)
		set_view_mode('view.main', '')

	def _build_people_items(self, people, media_type):
		built = []
		for item in people:
			try:
				name = item.get('name') or ''
				if not _valid_person_name(name): continue
				profile = item.get('profile_path')
				poster = tmdb_image_base % ('w185', profile) if profile else poster_empty
				image = tmdb_image_base % ('h632', profile) if profile else poster_empty
				url = build_url({'mode': 'person_data_dialog', 'actor_name': name, 'actor_id': item.get('id'), 'actor_image': image})
				known_for = _known_for_text(item, media_type)
				listitem = make_listitem()
				listitem.setLabel(name)
				listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': self.fanart, 'banner': poster})
				try:
					listitem.setInfo('video', {'title': name, 'plot': known_for, 'mediatype': 'actor'})
				except: pass
				built.append((url, listitem, False))
			except: pass
		return built
