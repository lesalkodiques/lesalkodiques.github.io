import sqlite3 as database
from pathlib import Path
from datetime import datetime, timedelta
import xbmc, xbmcaddon, xbmcgui, xbmcvfs

def ls(string):
	try: return xbmcaddon.Addon().getLocalizedString(int(string))
	except: return str(string)

def notification(line1, time=3000, sound=False):
	addon_info = xbmcaddon.Addon().getAddonInfo
	xbmcgui.Dialog().notification(addon_info('name'), line1, addon_info('icon'), time, sound)

def thumb_cleaner():
	current_date = datetime.date(datetime.utcnow())
	thumbs_folder = Path(xbmcvfs.translatePath('special://thumbnails'))
	dbfile = Path(xbmcvfs.translatePath('special://database'), 'Textures13.db')
	if not dbfile.exists(): return notification(ls(32575))
	item_list = []
	minimum_uses = 30
	days = xbmcgui.Dialog().numeric(0 , ls(33188), defaultt=str(minimum_uses))
	if not days: return notification(ls(33189))
	back_date = (current_date - timedelta(days=int(days))).strftime('%Y-%m-%d %H:%M:%S')
	dbcon = database.connect(str(dbfile), isolation_level=None)
	dbcur = dbcon.cursor()
	dbcur.execute('''PRAGMA synchronous = OFF''')
	dbcur.execute('''PRAGMA journal_mode = OFF''')
#	dbcur.execute(
#		"SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?",
#		(minimum_uses, str(back_date))
#	)
	dbcur.execute("SELECT idtexture FROM sizes WHERE lastusetime < ?", (str(back_date), ))
	result = dbcur.fetchall()
	result_length = len(result)
	if not result_length > 0: return notification(ls(33190))
	progress_dialog = xbmcgui.DialogProgress()
	progress_dialog.create(ls(33191), '')
	progress_dialog.update(0, ls(33192))
	for count, item in enumerate(result):
		if progress_dialog.iscanceled(): break
		_id = item[0]
		dbcur.execute("SELECT cachedurl FROM texture WHERE id = ?", (_id, ))
		url = dbcur.fetchall()[0][0]
		path = thumbs_folder.joinpath(url)
		path.unlink(missing_ok=True)
		item_list.append((_id,))
		percent = int(count / result_length * 100)
		line = '[B]%s:[/B] %s[CR][B]%s:[/B] %02d - %s[CR][B]%s:[/B] %s'
		line = line % (ls(33197), result_length, ls(33198), count, str(path.name), ls(33199), str(path.parent))
		progress_dialog.update(max(1, percent), line)
	line = '%s %s[CR]%s[CR]%%s' % (ls(33193), result_length, ls(32577).replace('[B]', '').replace('[/B]', ''))
	progress_dialog.update(33, line % ls(33194))
	dbcur.executemany("DELETE FROM sizes WHERE idtexture = ?", item_list)
	progress_dialog.update(66, line % ls(33196))
	dbcur.executemany("DELETE FROM texture WHERE id = ?", item_list)
	progress_dialog.update(99, line % ls(33195))
	dbcon.commit()
	dbcur.execute("VACUUM")
	xbmc.sleep(1500)
	try: progress_dialog.close()
	except: pass
	return notification(ls(33200))

