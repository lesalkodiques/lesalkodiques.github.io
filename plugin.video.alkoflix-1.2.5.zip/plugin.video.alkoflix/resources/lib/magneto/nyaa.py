# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/magneto/nyaa.py

import json
import re
from urllib.parse import quote, urlparse

from alko import client
from alko import source_utils


class source:
	timeout = 7
	priority = 5
	pack_capable = False
	hasMovies = True
	hasEpisodes = True

	def __init__(self):
		self.language = ['en', 'fr']
		self.manifest_url = 'https://nyaa-scraper-stremio-addon.nmtl.app/manifest.json'
		self.base_link = self._base_from_manifest(self.manifest_url)
		self.movieSearch_link = '/stream/movie/%s.json'
		self.movieAnimeSearch_link = '/stream/anime/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		self.tvAnimeSearch_link = '/stream/anime/%s:%s:%s.json'
		self.min_seeders = 0

	def _base_from_manifest(self, manifest_url):
		try:
			parsed = urlparse(manifest_url)
			path = parsed.path or ''
			for suffix in ('/manifest.json', '/manifest'):
				if path.endswith(suffix):
					path = path[:-len(suffix)]
					break
			return '%s://%s%s' % (parsed.scheme, parsed.netloc, path.rstrip('/'))
		except:
			return None

	def _valid_id(self, value):
		try:
			value = str(value or '').strip()
			if value.lower() in ('', 'none', 'null', 'false', '0'): return ''
			return value
		except:
			return ''

	def _id_candidates(self, data, is_episode=False):
		candidates = []
		append = candidates.append

		catalogue_id = self._valid_id(data.get('catalogue_id'))
		imdb = self._valid_id(data.get('imdb'))
		tmdb = self._valid_id(data.get('tmdb') or data.get('tmdb_id'))
		tvdb = self._valid_id(data.get('tvdb') or data.get('tvdb_id'))

		if catalogue_id: append(catalogue_id)
		if imdb: append(imdb)
		if is_episode:
			if tvdb and not tvdb.startswith('tvdb:'): append('tvdb:%s' % tvdb)
			elif tvdb: append(tvdb)
			if tmdb and not tmdb.startswith('tmdb:'): append('tmdb:%s' % tmdb)
			elif tmdb: append(tmdb)
		else:
			if tmdb:
				if not tmdb.startswith(('tmdb:', 'tmdbmovie:')):
					append('tmdbmovie:%s' % tmdb)
					append('tmdb:%s' % tmdb)
				else:
					append(tmdb)

		result = []
		for item in candidates:
			if item and item not in result:
				result.append(item)
		return result

	def _stream_urls(self, data):
		if not self.base_link: return []
		urls = []
		append = urls.append
		try:
			is_episode = 'tvshowtitle' in data
			ids = self._id_candidates(data, is_episode=is_episode)
			if not ids: return []
			if is_episode:
				season, episode = data['season'], data['episode']
				for video_id in ids:
					video_id = quote(str(video_id), safe='')
					append('%s%s' % (self.base_link, self.tvSearch_link % (video_id, season, episode)))
					append('%s%s' % (self.base_link, self.tvAnimeSearch_link % (video_id, season, episode)))
			else:
				for video_id in ids:
					video_id = quote(str(video_id), safe='')
					append('%s%s' % (self.base_link, self.movieSearch_link % video_id))
					append('%s%s' % (self.base_link, self.movieAnimeSearch_link % video_id))
		except:
			return []
		return urls

	def _get_streams(self, url):
		try:
			results = client.request(url, timeout=self.timeout)
			if not results: return []
			data = json.loads(results)
			streams = data.get('streams', []) if isinstance(data, dict) else []
			return streams if isinstance(streams, list) else []
		except:
			source_utils.scraper_error('NYAA')
			return []

	def _stream_text(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		parts = []
		for value in (
			behavior.get('filename'), stream.get('filename'), stream.get('folderName'),
			stream.get('name'), stream.get('title'), stream.get('description'),
			meta.get('title'), meta.get('name'), meta.get('originalTitle')
		):
			try:
				if value: parts.append(str(value))
			except:
				pass
		return '\n'.join(parts)

	def _release_title_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		for value in (
			behavior.get('filename'), stream.get('filename'), stream.get('folderName'),
			meta.get('originalTitle'), meta.get('title'), meta.get('name'),
			stream.get('title'), stream.get('name'), stream.get('description')
		):
			try:
				if not value: continue
				value = str(value).replace('\u2508\u27a4', '\n').strip()
				match = re.search(r'([A-Za-z0-9].*?\.(?:mkv|mp4|avi|m2ts|m4v|ts))', value, re.I)
				if match: return match.group(1).strip()
				line = value.split('\n')[0].strip()
				if line: return line
			except:
				pass
		return ''

	def _hash_from_stream(self, stream, meta=None, behavior=None, direct_url=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		for value in (
			stream.get('infoHash'), stream.get('infohash'), stream.get('info_hash'), stream.get('hash'),
			stream.get('torrentHash'), stream.get('torrent_hash'), stream.get('btih'), stream.get('magnetHash'),
			meta.get('infoHash'), meta.get('infohash'), meta.get('info_hash'), meta.get('hash'),
			meta.get('torrentHash'), meta.get('torrent_hash'), meta.get('btih'), meta.get('magnetHash'),
			behavior.get('infoHash'), behavior.get('infohash'), behavior.get('info_hash'), behavior.get('hash'),
			behavior.get('torrentHash'), behavior.get('torrent_hash'), behavior.get('btih'), behavior.get('magnetHash')
		):
			try:
				if value in ('', None): continue
				match = re.search(r'([A-Fa-f0-9]{40})', str(value))
				if match: return match.group(1).lower()
			except:
				pass
		for text in (direct_url, stream.get('url'), stream.get('externalUrl'), self._stream_text(stream, meta, behavior)):
			try:
				if not text: continue
				match = re.search(r'btih:([A-Fa-f0-9]{40})', str(text), re.I)
				if match: return match.group(1).lower()
				match = re.search(r'\b([A-Fa-f0-9]{40})\b', str(text))
				if match: return match.group(1).lower()
			except:
				pass
		return None

	def _size_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		for value in (
			meta.get('size'), behavior.get('videoSize'), behavior.get('size'),
			stream.get('size'), stream.get('videoSize'), stream.get('sizeBytes'),
			stream.get('filesize'), stream.get('fileSize')
		):
			try:
				if value in ('', None): continue
				if isinstance(value, str):
					value = value.strip()
					if re.search(r'\b(?:gb|gib|mb|mib)\b', value, re.I): return value
				value = float(value)
				if value > 0: return '%.2f GB' % (value / 1073741824)
			except:
				pass
		text = self._stream_text(stream, meta, behavior)
		try:
			match = re.search(r'(?<![A-Za-z0-9])([0-9]+(?:[\.,][0-9]+)?)\s*(GB|GiB|MB|MiB)\b', text, re.I)
			if match:
				return '%s %s' % (match.group(1).replace(',', '.'), match.group(2).upper().replace('GIB', 'GB').replace('MIB', 'MB'))
		except:
			pass
		return ''

	def _seeders_from_stream(self, stream, meta=None, behavior=None):
		meta = meta or stream.get('meta') or {}
		behavior = behavior or stream.get('behaviorHints') or {}
		for value in (
			stream.get('seeders'), stream.get('seeds'), stream.get('seed'),
			meta.get('seeders'), meta.get('seeds'), behavior.get('seeders'), behavior.get('seeds')
		):
			try:
				if value in ('', None): continue
				return int(value)
			except:
				pass
		text = self._stream_text(stream, meta, behavior)
		for pattern in (r'👤\s*(\d+)', r'\bseed(?:er)?s?\s*[:=]?\s*(\d+)\b', r'\bS\s*[:=]\s*(\d+)\b'):
			try:
				match = re.search(pattern, text, re.I)
				if match: return int(match.group(1))
			except:
				pass
		return 0

	def _is_vostfr(self, text):
		try:
			return bool(re.search(r'(?<![a-z0-9])vo\s*[.-]?\s*stfr(?![a-z0-9])|(?<![a-z0-9])vostfr(?![a-z0-9])', text, re.I))
		except:
			return False

	def _fr_rank(self, item):
		try:
			text = '%s %s %s' % (item.get('name', ''), item.get('name_info', ''), item.get('info', ''))
			if source_utils.is_french_release(text): return 0
			if self._is_vostfr(text): return 1
		except:
			pass
		return 2

	def _add_fr_info(self, info, name_info, stream_text):
		try:
			if source_utils.is_french_release('%s %s' % (name_info, stream_text)) and 'FR' not in info:
				info.insert(0, 'FR')
			elif self._is_vostfr('%s %s' % (name_info, stream_text)) and 'VOSTFR' not in info:
				info.insert(0, 'VOSTFR')
		except:
			pass
		return info

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace(':', ' ')
			title = re.sub(r'\s+', ' ', title).strip()
			year = str(data['year'])
			episode_title = data['title'] if 'tvshowtitle' in data else None
			hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year
			if 'timeout' in data: self.timeout = max(7, int(data['timeout']))
			urls = self._stream_urls(data)
			if not urls: return sources
		except:
			source_utils.scraper_error('NYAA')
			return sources

		seen = set()
		for url in urls:
			for stream in self._get_streams(url):
				try:
					if not isinstance(stream, dict): continue
					meta = stream.get('meta') or {}
					behavior = stream.get('behaviorHints') or {}
					direct_url = stream.get('url') or ''
					info_hash = self._hash_from_stream(stream, meta, behavior, direct_url)
					release_title = self._release_title_from_stream(stream, meta, behavior)
					name = source_utils.clean_name(release_title)
					if not name: continue

					stream_text = self._stream_text(stream, meta, behavior)
					name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
					language = 'fr' if (source_utils.is_french_release('%s %s' % (name_info, stream_text)) or self._is_vostfr('%s %s' % (name_info, stream_text))) else source_utils.release_language(name_info)

					use_direct = bool(direct_url) and not str(direct_url).lower().startswith('magnet:')
					if use_direct:
						final_url = direct_url
						unique_key = final_url
					else:
						if not info_hash: continue
						final_url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote(name))
						unique_key = info_hash
					if unique_key in seen: continue
					seen.add(unique_key)

					seeders = self._seeders_from_stream(stream, meta, behavior)
					if self.min_seeders > seeders: continue

					quality, info = source_utils.get_release_quality(name_info, final_url)
					info = self._add_fr_info(info, name_info, stream_text)
					dsize = 0
					try:
						size = self._size_from_stream(stream, meta, behavior)
						if size:
							dsize, isize = source_utils._size(size)
							if isize: info.insert(0, isize)
					except:
						dsize = 0
					info = ' | '.join(info)

					item = {
						'provider': 'nyaa', 'source': 'torrent' if not use_direct else 'direct',
						'seeders': seeders, 'hash': info_hash, 'name': name, 'name_info': name_info,
						'quality': quality, 'language': language, 'url': final_url, 'info': info,
						'direct': use_direct, 'debridonly': not use_direct, 'size': dsize, 'true_size': bool(dsize)
					}
					sources_append(item)
				except:
					source_utils.scraper_error('NYAA')
		try:
			sources.sort(key=lambda i: (self._fr_rank(i), -int(i.get('seeders', 0) or 0), -float(i.get('size', 0) or 0)))
		except:
			pass
		return sources
