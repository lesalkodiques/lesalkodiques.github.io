# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/tmdbh_players.py

from modules.kodi_utils import dialog, path_exists, make_directorys, copy_file, notification, ok_dialog, confirm_dialog
import xbmcvfs

SOURCE_DIR = 'special://home/addons/plugin.video.alkoflix/resources/json/'
START_DIR = 'special://profile/addon_data/'

def _clean_path(path):
	# Normalise le chemin sans convertir les chemins special://, afin de conserver la compatibilité entre les systèmes.
	if not path: return ''
	path = path.replace('\\', '/')
	return path if path.endswith('/') else '%s/' % path

def _join_path(base, name):
	return '%s%s' % (_clean_path(base), name)

def _json_files(path):
	# Retourne uniquement les fichiers JSON présents dans le dossier source des players TMDbH.
	try:
		_, files = xbmcvfs.listdir(_clean_path(path))
	except Exception:
		return []
	return [item for item in files if item.lower().endswith('.json')]

def _copy_players(destination, files):
	copied, failed = [], []
	for filename in files:
		source = _join_path(SOURCE_DIR, filename)
		target = _join_path(destination, filename)
		try:
			if copy_file(source, target): copied.append(filename)
			else: failed.append(filename)
		except Exception:
			failed.append(filename)
	return copied, failed

def install_players():
	# Ouvre l'arborescence userdata/addon_data pour laisser l'utilisateur choisir le dossier de destination.
	# Le dossier de destination n'est pas codé en dur afin de rester compatible si l'addon TMDb Helper change d'identifiant.
	source = _clean_path(SOURCE_DIR)
	start = _clean_path(START_DIR)

	if not path_exists(source):
		ok_dialog(text='Le dossier des players TMDbH est introuvable dans alkoFlix.[CR][CR]Chemin attendu :[CR]%s' % source)
		return

	files = _json_files(source)
	if not files:
		ok_dialog(text='Aucun fichier JSON de player TMDbH n’a été trouvé dans :[CR]%s' % source)
		return

	if not path_exists(start):
		make_directorys(start)

	destination = dialog.browseSingle(0, 'Sélectionner le dossier de destination', 'files', '', False, True, start)
	destination = _clean_path(destination)
	if not destination:
		return

	if not path_exists(destination):
		ok_dialog(text='Le dossier sélectionné est introuvable :[CR]%s' % destination)
		return

	existing = [filename for filename in files if path_exists(_join_path(destination, filename))]
	if existing:
		text = 'Un ou plusieurs players existent déjà dans le dossier sélectionné.[CR][CR]Voulez-vous les remplacer ?'
		if not confirm_dialog(text=text, ok_label='Remplacer', cancel_label='Annuler', top_space=True):
			return

	copied, failed = _copy_players(destination, files)
	if copied and not failed:
		notification('%d player(s) TMDbH copié(s)' % len(copied), 3000)
		return

	if copied and failed:
		ok_dialog(text='%d player(s) copié(s), mais %d fichier(s) n’ont pas pu être copiés.' % (len(copied), len(failed)))
		return

	ok_dialog(text='Les players TMDbH n’ont pas pu être copiés dans le dossier sélectionné.')
