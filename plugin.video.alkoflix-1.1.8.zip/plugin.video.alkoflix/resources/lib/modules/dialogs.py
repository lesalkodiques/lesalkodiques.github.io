# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/dialogs.py

import json
from indexers import metadata
from modules import kodi_utils, source_utils, settings
from modules.cache import clear_cache
from modules.utils import get_datetime, clean_file_name
# logger = kodi_utils.logger  # Décommenter temporairement pour diagnostiquer les menus/dialogues.

ls, build_url, media_path, select_dialog = kodi_utils.local_string, kodi_utils.build_url, kodi_utils.media_path, kodi_utils.select_dialog
show_busy_dialog, hide_busy_dialog, notification, ok_dialog = kodi_utils.show_busy_dialog, kodi_utils.hide_busy_dialog, kodi_utils.notification, kodi_utils.ok_dialog
get_property, set_property, clear_property, container_refresh = kodi_utils.get_property, kodi_utils.set_property, kodi_utils.clear_property, kodi_utils.container_refresh
execute_builtin, confirm_dialog, container_content, sleep = kodi_utils.execute_builtin, kodi_utils.confirm_dialog, kodi_utils.container_content, kodi_utils.sleep
get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting

# Ce module regroupe les choix affichés dans les dialogues Kodi :
# menus contextuels, gestionnaires Trakt/MDBList/TMDb, options de scrape, couleurs, favoris, etc.
# Les identifiants techniques (movie, tvshow, watchlist, favorite, etc.) doivent rester en anglais.

# Sélection d'une vidéo IMDb disponible pour le média.
def imdb_videos_choice(videos, poster):
	try: videos = json.loads(videos)
	except: pass
	videos.sort(key=lambda x: x['quality_rank'])
	list_items = [{'line1': i['quality'], 'icon': poster} for i in videos]
	kwargs = {'items': json.dumps(list_items), 'heading': ls(32241)}
	return select_dialog([i['url'] for i in videos], **kwargs)

# Sélection d'un mot-clé IMDb et ajout à l'historique de recherche.
def imdb_keywords_choice(media_type, imdb_id, poster):
	from indexers.imdb_api import imdb_keywords
	from menus.history import add_to_search_history
	show_busy_dialog()
	keywords_info = imdb_keywords(imdb_id)
	if len(keywords_info) == 0:
		hide_busy_dialog()
		return notification(32760, 1500)
	meta_type = 'movie' if media_type == 'movies' else 'tvshow'
	mode, action = 'build_%s_list' % meta_type, 'imdb_keywords_list_contents'
	list_items = [{'line1': i, 'icon': poster, 'list_id': i, 'media_type': media_type} for i in keywords_info]
	hide_busy_dialog()
	keyword_choice = select_dialog(
		[{'mode': mode, 'action': action, 'list_id': i, 'media_type': media_type} for i in keywords_info],
		**{'items': json.dumps(list_items), 'heading': ls(32092)}
	)
	if keyword_choice: add_to_search_history(keyword_choice['list_id'], 'imdb_keyword_%s_queries' % meta_type)
	return keyword_choice

# Normalise le type de média avant les appels TMDb.
def _tmdb_video_media_type(media_type):
	if media_type == 'movies': return 'movie'
	if media_type in ('tvshow', 'tvshows'): return 'tv'
	return media_type

# Récupère les vidéos TMDb dans une langue précise.
# Utilisé pour prioriser les bandes-annonces françaises, puis anglaises en secours.
def _tmdb_videos_by_language(media_type, tmdb_id, language):
	if not tmdb_id: return []
	try:
		from indexers import tmdb_api
		media_type = _tmdb_video_media_type(media_type)
		base_url = getattr(tmdb_api, 'base_url', 'https://api.themoviedb.org/3').rstrip('/')
		api_key = settings.tmdb_api_key()
		url = '%s/%s/%s/videos?api_key=%s&language=%s' % (base_url, media_type, tmdb_id, api_key, language)
		get_tmdb = getattr(tmdb_api, 'get_tmdb', None)
		if callable(get_tmdb): data = get_tmdb(url)
		else:
			import requests
			data = requests.get(url, timeout=10).json()
		return (data or {}).get('results') or []
	except Exception as e:
		kodi_utils.logger('erreur récupération bandes annonces TMDb', str(e))
		return []

# Garde uniquement les vidéos YouTube lisibles par plugin.video.youtube.
def _youtube_trailers(videos):
	allowed_types = ('Trailer', 'Teaser', 'Clip', 'Featurette')
	return [
		i for i in videos or []
		if i.get('key') and (i.get('site') or '').lower() == 'youtube' and i.get('type') in allowed_types
	]

# Donne priorité aux vraies bandes-annonces officielles.
def _sort_trailers(videos):
	def _key(item):
		video_type = item.get('type') or ''
		return (
			0 if video_type == 'Trailer' else 1,
			0 if item.get('official') else 1,
			item.get('published_at') or ''
		)
	return sorted(videos or [], key=_key)

# Sélectionne une bande-annonce dans la liste préparée.
def _choose_trailer(videos, poster):
	videos = _sort_trailers(videos)
	if len(videos) > 1:
		language_labels = {'fr': 'Français', 'en': 'Anglais'}
		type_labels = {'Trailer': 'Bande annonce', 'Teaser': 'Teaser', 'Clip': 'Extrait', 'Featurette': 'Bonus'}
		list_items = [
			{
				'line1': clean_file_name(i.get('name', 'Bande annonce')),
				'line2': '%s (%s) - %s' % (
					type_labels.get(i.get('type'), i.get('type') or 'Vidéo'),
					i.get('site') or 'N/A',
					language_labels.get(i.get('iso_639_1'), i.get('iso_639_1') or 'N/A')
				),
				'icon': poster
			}
			for i in videos
		]
		kwargs = {'items': json.dumps(list_items), 'heading': 'Bande annonce', 'multi_line': 'true'}
		video_id = select_dialog([i['key'] for i in videos], **kwargs)
	else: video_id = next(iter(videos), {}).get('key')
	if video_id is None: return 'canceled'
	return 'plugin://plugin.video.youtube/play/?video_id=%s' % video_id

# Sélection d'une bande-annonce.
# Si prefer_french=True, les vidéos TMDb sont cherchées en français d'abord,
# puis en anglais seulement si aucune bande-annonce française n'est disponible.
def trailer_choice(media_type, poster, tmdb_id, trailer_url, all_trailers=None, prefer_french=False):
	if prefer_french:
		all_trailers = _youtube_trailers(_tmdb_videos_by_language(media_type, tmdb_id, 'fr-FR'))
		if not all_trailers: all_trailers = _youtube_trailers(_tmdb_videos_by_language(media_type, tmdb_id, 'en-US'))
		if not all_trailers and trailer_url: return trailer_url
	elif settings.get_language() != 'en' and not trailer_url and not all_trailers:
		from indexers.tmdb_api import tmdb_media_videos
		try: all_trailers = tmdb_media_videos(media_type, tmdb_id)['results']
		except: pass
	all_trailers = _youtube_trailers(all_trailers)
	if not all_trailers: return trailer_url
	return _choose_trailer(all_trailers, poster)

# Sélection d'un genre à partir des genres déjà associés au média.
def genres_choice(media_type, genres, poster, return_genres=False):
	from modules.meta_lists import movie_genres, tvshow_genres
	def _process_dicts(genre_str, _dict):
		final_genres_list = []
		append = final_genres_list.append
		for key, value in _dict.items():
			if key in genre_str: append({'genre': key, 'value': value})
		return final_genres_list
	if media_type in ('movie', 'movies'):
		genre_action, meta_type, action = movie_genres, 'movie', 'tmdb_movies_genres'
	else: genre_action, meta_type, action = tvshow_genres, 'tvshow', 'tmdb_tv_genres'
	genre_list = _process_dicts(genres, genre_action)
	if return_genres: return genre_list
	if len(genre_list) == 0: return notification(32760, 1500)
	mode = 'build_%s_list' % meta_type
	choices = [{'mode': mode, 'action': action, 'genre_id': i['value'][0]} for i in genre_list]
	list_items = [{'line1': i['genre'], 'icon': poster} for i in genre_list]
	kwargs = {'items': json.dumps(list_items), 'heading': ls(32470)}
	return select_dialog(choices, **kwargs)

# Gestion des actions Trakt depuis le menu contextuel.
def trakt_manager_choice(params):
	if not get_setting('trakt_user', ''): return notification(32760, 3500)
	heading = ls(32198).replace('[B]', '').replace('[/B]', '')
	icon = media_path('trakt.png')
	choices = [('[B][I]%s [/I][/B]' % ls(32499), 'Collection'), ('[B][I]%s [/I][/B]' % ls(32500), 'Watchlist')]
	choices += [('%s %s...' % (ls(32602), ls(32199)), 'Add'), ('%s %s...' % (ls(32603), ls(32199)), 'Remove')]
	choices += [('Basculer l’état « Abandonné »...', 'Drop')] if params['media_type'] == 'tvshow' else []
	list_items = [{'line1': item[0], 'icon': icon} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': heading}
	choice = select_dialog([i[1] for i in choices], **kwargs)
	if choice is None: return
	from indexers import trakt_api
	choice_labels = {'Collection': ls(32499), 'Watchlist': ls(32500), 'Add': ls(32602), 'Remove': ls(32603), 'Drop': 'Abandonné'}
	choice_label = choice_labels.get(choice, choice)
	add_str, rem_str = 'Ajouter à %s ?' % choice_label, 'Retirer de %s ?' % choice_label
	if   choice == 'Collection':
		data = trakt_api.trakt_fetch_collection_watchlist('collection', params['media_type'])
		action = 'remove' if str(params['tmdb_id']) in {str(i['media_ids']['tmdb']) for i in data} else 'add'
		data = {
			i[0]: i[1] if i[0] == 'imdb' else int(i[1])
			for i in (('imdb', params.get('imdb_id')), ('tmdb', params.get('tmdb_id')), ('tvdb', params.get('tvdb_id')))
			if not i[1] in ('', 'None', None)
		}
		data = {'shows' if params['media_type'] == 'tvshow' else 'movies': [{'ids': data}]}
		if action == 'remove':
			if not confirm_dialog(text=rem_str, top_space=True): return
			trakt_api.remove_from_collection(data)
		else: trakt_api.add_to_collection(data)
	elif choice == 'Watchlist':
		data = trakt_api.trakt_fetch_collection_watchlist('watchlist', params['media_type'])
		action = 'remove' if str(params['tmdb_id']) in {str(i['media_ids']['tmdb']) for i in data} else 'add'
		data = {
			i[0]: i[1] if i[0] == 'imdb' else int(i[1])
			for i in (('imdb', params.get('imdb_id')), ('tmdb', params.get('tmdb_id')), ('tvdb', params.get('tvdb_id')))
			if not i[1] in ('', 'None', None)
		}
		data = {'shows' if params['media_type'] == 'tvshow' else 'movies': [{'ids': data}]}
		if action == 'remove':
			if not confirm_dialog(text=rem_str, top_space=True): return
			trakt_api.remove_from_watchlist(data)
		else: trakt_api.add_to_watchlist(data)
	elif choice == 'Add': trakt_api.trakt_add_to_list(params)
	elif choice == 'Remove': trakt_api.trakt_remove_from_list(params)
	else: trakt_api.hide_unhide_trakt_items(params['tmdb_id'], 'shows', params['imdb_id'], 'dropped')

# Gestion des listes MDBList depuis le menu contextuel.
def mdbl_manager_choice(params):
	if not get_setting('mdblist.token', ''): return notification(32760, 3500)
	from indexers.mdblist_api import mdbl_userlists, mdbl_list_items, mdbl_modify_list, clear_mdbl_cache
	heading = ls(32200).replace('[B]', '').replace('[/B]', '')
	icon = media_path('mdblist.png')
	choices = [(str(item['id']), item['name'], '%s éléments' % item['items']) for item in mdbl_userlists() if not item['dynamic']]
	choices += [('collection', 'Collection', ''), ('watchlist', 'Liste de suivi', ''), ('clear', 'Vider le cache des listes', '')]
	if not choices: return
	list_items = [{'line1': item[1], 'line2': item[2],'icon': icon} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'multi_line': 'true'}
	choice = select_dialog([(i[0], i[1]) for i in choices], **kwargs)
	if choice is None: return
	if choice[0] == 'clear':
		clear_mdbl_cache()
		return mdbl_manager_choice(params)
	add_str, rem_str = 'Ajouter à %s ?' % choice[1], 'Retirer de %s ?' % choice[1]
	data = mdbl_list_items(choice[0], None)
	action = False if int(params['tmdb_id']) in {i['id'] for i in data} else True
	if not action and not confirm_dialog(text=rem_str, top_space=True): return
	key = 'shows' if params['media_type'] == 'tvshow' else 'movies'
	val = [{'tmdb': int(params.get('tmdb_id')), 'imdb': params.get('imdb_id')}]
	if mdbl_modify_list(choice[0], {key: val}, action):
		clear_cache('mdblist', silent=True) if choice[0] in ('collection', 'watchlist') else clear_mdbl_cache()
		notification(32576)
		if not action: container_refresh()
	else: notification(32574)

# Gestion des listes TMDb, favoris et liste de suivi.
def tmdb_manager_choice(params):
	if not get_setting('tmdb.token', ''): return notification(32760, 3500)
	from indexers import tmdb_api
	image_resolution, tmdb_image_base = settings.get_resolution(), tmdb_api.tmdb_image_base
	heading = ls(tmdb_api.list_heading).replace('[B]', '').replace('[/B]', '')
	icon = media_path('tmdb.png')
	list_name = params.get('trakt_list_name') or params.get('mdbl_list_name') or ''
	choices = []
	choices += [
		(str(item['id']), item['name'], '%s éléments' % item['number_of_items'],
		 tmdb_image_base % (image_resolution['poster'], item['poster_path']) if item['poster_path'] else icon)
		for item in tmdb_api.user_lists_all()
	]
	if not list_name:
		watch_media_type = 'Série TV' if params['media_type'] == 'tvshow' else 'Film'
		choices += [('watchlist', 'Liste de suivi', watch_media_type, icon), ('favorite', 'Favoris', watch_media_type, icon)]
	choices += [('new', 'Créer une nouvelle liste', list_name, icon), ('clear', 'Vider le cache des listes', '', icon)]
	if not choices: return
	list_items = [{'line1': item[1], 'line2': item[2], 'icon': item[3]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'multi_line': 'true'}
	choice = select_dialog([(i[0], i[1]) for i in choices], **kwargs)
	if choice is None: return
	if 'new' in choice[0]:
		obj = tmdb_api.list_obj.copy()
		obj['name'] = kodi_utils.dialog.input('Nom de la nouvelle liste', defaultt=list_name)
		if not obj['name']: return tmdb_manager_choice(params)
		if not tmdb_api.list_create(obj)['success']: return notification(32574)
		tmdb_api.clear_tmdbl_cache()
		return tmdb_manager_choice(params)
	if 'clear' in choice[0]:
		tmdb_api.clear_tmdbl_cache()
		return tmdb_manager_choice(params)
	if 'trakt_list_id' in params or 'mdbl_list_id' in params:
		function = tmdb_api.import_trakt_list if 'trakt_list_id' in params else tmdb_api.import_mdbl_list
		return function({**params, 'list_id': choice[0]})
	add_str, rem_str = 'Ajouter à %s ?' % choice[1], 'Retirer de %s ?' % choice[1]
	params['media_type'] = 'tv' if params['media_type'] == 'tvshow' else 'movie'
	if 'watchlist' in choice[0] or 'favorite' in choice[0]:
		if 'watchlist' == choice[0]:
			list_type, data = 'watchlist', tmdb_api.all_items(tmdb_api.watchlist, params['media_type'])
		else: list_type, data = 'favorite', tmdb_api.all_items(tmdb_api.favorite, params['media_type'])
		action = False if int(params['tmdb_id']) in {i['id'] for i in data} else True
		item = {'media_type': params['media_type'], 'media_id': params['tmdb_id'], list_type: action}
		if not action and not confirm_dialog(text=rem_str, top_space=True): return
		if tmdb_api.add_to_watchlist_favorite(item, list_type)['success']:
			tmdb_api.clear_tmdbl_cache()
			if not action: container_refresh()
			return notification(32576)
		else: return notification(32574)
	items = {'items': [{'media_type': params['media_type'], 'media_id': params['tmdb_id']}]}
	status = tmdb_api.list_status(choice[0], params['media_type'], params['tmdb_id'])
	if status and status['success']:
		if not confirm_dialog(text=rem_str, top_space=True): return
		action, function = False, tmdb_api.list_remove_items
	else: action, function = True, tmdb_api.list_add_items
	if function(choice[0], items)['success']:
		tmdb_api.clear_tmdbl_cache()
		if not action: container_refresh()
		notification(32576)
	else: notification(32574)

# Lecture d'un épisode aléatoire, avec ou sans enchaînement continu.
def random_choice(choice, meta):
	tmdb_id = meta.get('tmdb_id')
	if not tmdb_id: return
	from modules.episode_tools import get_random_episode
	from modules.sources import SourceSelect
	meta, play_params = get_random_episode(tmdb_id, True if choice == 'play_random_continual' else False)
	if not play_params: return notification(32760)
	SourceSelect.factory(play_params)

# Menu de relance du scrape avec différentes options.
def playback_choice(content, poster, meta):
	items = [
		('clear_and_rescrape', ls(32014)),
		('rescrape_with_disabled', ls(32006)),
		('scrape_with_filters_ignored', ls(32807)),
		('scrape_with_custom_values', ls(32135))
	]
	list_items = [{'line1': i[1], 'icon': poster} for i in items]
	kwargs = {'items': json.dumps(list_items), 'heading': ls(32174)}
	choice = select_dialog([i[0] for i in items], **kwargs)
	if choice is None: return
	if choice == 'clear_and_rescrape': clear_and_rescrape(content, meta)
	elif choice == 'rescrape_with_disabled': rescrape_with_disabled(content, meta)
	elif choice == 'scrape_with_filters_ignored': scrape_with_filters_ignored(content, meta)
	else: scrape_with_custom_values(content, meta)

# Sélection des qualités vidéo autorisées.
def set_quality_choice(quality_setting):
	include = ls(32188)
	dl = ['%s SD' % include, '%s 720p' % include, '%s 1080p' % include, '%s 4K' % include]
	fl = ['SD', '720p', '1080p', '4K']
	try: preselect = [fl.index(i) for i in get_setting(quality_setting).split(', ')]
	except: preselect = []
	list_items = [{'line1': item} for item in dl]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix', 'multi_choice': 'true', 'preselect': preselect}
	choice = select_dialog(fl, **kwargs)
	if choice is None: return
	if choice == []:
		ok_dialog(text=32574, top_space=True)
		return set_quality_choice(quality_setting)
	set_setting(quality_setting, ', '.join(choice))

# Sélection des sous-menus affichés dans la fenêtre Extras.
def extras_lists_choice():
	fl = [2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2061, 2062]
	dl = [
		ls(32664), ls(32503), ls(32607), ls(32984), ls(32986), ls(32989), ls(32531), ls(32616), ls(32617),
		'%s %s' % (ls(32612), ls(32543)), '%s %s' % (ls(32612), ls(32470)),
		'%s %s' % (ls(32612), ls(32480)), '%s %s' % (ls(32612), ls(32499))
	]
	try: preselect = [fl.index(i) for i in settings.extras_enabled_menus()]
	except: preselect = []
	list_items = [{'line1': item} for item in dl]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix', 'multi_choice': 'true', 'preselect': preselect}
	selection = select_dialog(fl, **kwargs)
	if selection == []: return set_setting('extras.enabled_menus', 'noop')
	elif selection is None: return
	selection = [str(i) for i in selection]
	set_setting('extras.enabled_menus', ','.join(selection))

# Sélection des langues à inclure dans un filtre de recherche.
def set_language_filter_choice(filter_setting):
	from modules.meta_lists import language_choices
	lang_choices = language_choices
	lang_choices.pop('None')
	dl = list(lang_choices.keys())
	fl = list(lang_choices.values())
	try: preselect = [fl.index(i) for i in get_setting(filter_setting).split(', ')]
	except: preselect = []
	list_items = [{'line1': item} for item in dl]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix', 'multi_choice': 'true', 'preselect': preselect}
	choice = select_dialog(fl, **kwargs)
	if choice is None: return
	if choice == []: return set_setting(filter_setting, 'eng')
	set_setting(filter_setting, ', '.join(choice))

# Les dossiers locaux comme sources/scrapers ne sont plus pris en charge.
def folder_scraper_manager_choice(folder_info=None):
	notification('Les dossiers locaux ne sont plus pris en charge dans alkoFlix.', 2500)
	return

def results_sorting_choice():
	quality, provider, size = ls(32241), ls(32583), ls(32584)
	natural_order = 'Ordre naturel'
	choices = [
		(natural_order, '0'),
		('%s, %s, %s' % (quality, provider, size), '1'), ('%s, %s, %s' % (quality, size, provider), '2'),
		('%s, %s, %s' % (provider, quality, size), '3'), ('%s, %s, %s' % (provider, size, quality), '4'),
		('%s, %s, %s' % (size, quality, provider), '5'), ('%s, %s, %s' % (size, provider, quality), '6')
	]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	choice = select_dialog(choices, **kwargs)
	if choice:
		set_setting('results.sort_order_display', choice[0])
		set_setting('results.sort_order', choice[1])

# Choix du type de surbrillance dans la fenêtre des résultats.
def results_highlights_choice():
	choices = [(ls(32240), '0'), (ls(32583), '1'), (ls(32241), '2')]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	choice = select_dialog([i[1] for i in choices], **kwargs)
	if choice: return set_setting('highlight.type', choice)

# Choix de l'affichage XML des résultats.
# Les valeurs enregistrées restent en anglais, car elles correspondent aux noms techniques des layouts.
def results_layout_choice():
	xml_choices = [
		'List Default', 'List Contrast Default',
		'InfoList Default', 'InfoList Contrast Default',
		'WideList Default', 'WideList Contrast Default'
	]
	display_choices = [
		'Liste - par défaut', 'Liste - contraste',
		'InfoListe - par défaut', 'InfoListe - contraste',
		'Liste large - par défaut', 'Liste large - contraste'
	]
	list_items = [{'line1': item} for item in display_choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	choice = select_dialog(xml_choices, **kwargs)
	if choice in xml_choices: set_setting('results.xml_style', choice)

# Choix du comportement des sous-titres.
def set_subtitle_choice():
	choices = [(ls(32192), '0'), (ls(32193), '1'), (ls(32027), '2')]
	list_items = [{'line1': item[0]} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	choice = select_dialog([i[1] for i in choices], **kwargs)
	if choice: return set_setting('subtitles.subs_action', choice)

# Choix de la couleur de surbrillance des dialogues de scrapers.
def scraper_dialog_color_choice(setting):
	setting ='int_dialog_highlight' if setting == 'internal' else 'ext_dialog_highlight'
	chosen_color = color_choice()
	if chosen_color: set_setting(setting, chosen_color)

# Choix de la couleur associée aux qualités vidéo.
def scraper_quality_color_choice(setting):
	chosen_color = color_choice()
	if chosen_color: set_setting(setting, chosen_color)

# Choix de la couleur associée à un provider ou type de source.
def scraper_color_choice(setting):
	choices = [
		('aiostreams', 'provider.aiostreams_colour'),
		('aiostreams_custom', 'provider.aiostreams_custom_colour'),
		('usenetstreams', 'provider.usenetstreams_colour'),
		('custom_stremio1', 'provider.custom_stremio1_colour'),
		('custom_stremio2', 'provider.custom_stremio2_colour'),
		('easynews', 'provider.easynews_colour'),
		('debrid_cloud', 'provider.debrid_cloud_colour'),
		('folders', 'provider.folders_colour'),
		('hoster', 'hoster.identify'),
		('torrent', 'torrent.identify'),
		('rd', 'provider.rd_colour'),
		('pm', 'provider.pm_colour'),
		('ad', 'provider.ad_colour'),
		('oc', 'provider.oc_colour'),
		('tb', 'provider.tb_colour'),
		('ed', 'provider.ed_colour'),
		('free', 'provider.free_colour')
	]
	setting = [i[1] for i in choices if i[0] == setting][0]
	chosen_color = color_choice()
	if chosen_color: set_setting(setting, chosen_color)

# Sélecteur générique de couleur.
def color_choice(msg_dialog='alkoFlix', no_color=False):
	from modules.meta_lists import meta_colors
	color_chart = meta_colors
	color_display = ['[COLOR %s]%s[/COLOR]' % (i, i.capitalize()) for i in color_chart]
	if no_color:
		color_chart.insert(0, 'No Color')
		color_display.insert(0, 'Aucune couleur')
	list_items = [{'line1': item} for item in color_display]
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	choice = select_dialog(color_chart, **kwargs)
	if choice is None: return
	return choice

# Choix de la langue des métadonnées et vidage du cache associé.
def meta_language_choice():
	from modules.meta_lists import meta_languages
	langs = meta_languages
	list_items = [{'line1': i['name']} for i in langs]
	kwargs = {'items': json.dumps(list_items), 'heading': ls(32145)}
	list_choose = select_dialog(langs, **kwargs)
	if list_choose is None: return None
	chosen_language, chosen_language_display = list_choose['iso'], list_choose['name']
	set_setting('meta_language', chosen_language)
	set_setting('meta_language_display', chosen_language_display)
	clear_cache('meta', silent=True)

# Ajout, retrait ou nettoyage des favoris internes alkoFlix.
def favourites_choice(params):
	from caches.favourites_cache import favourites_cache
	icon = media_path('favourites.png')
	if params.get('cache'):
		list = [('%s %s' % (ls(32028), ls(32453)), 'movie'), ('%s %s' % (ls(32029), ls(32453)), 'tvshow')]
		list_items = [{'line1': item[0], 'icon': icon} for item in list]
		kwargs = {'items': json.dumps(list_items), 'heading': ls(32453)}
		media_type = select_dialog([item[1] for item in list], **kwargs)
		if media_type is None: return
		if not favourites_cache.clear_favourites(media_type): notification(32574)
	else:
		media_type, tmdb_id, title = params['media_type'], params['tmdb_id'], params['title']
		current_favourites = favourites_cache.get_favourites(media_type)
		if any(i['tmdb_id'] == tmdb_id for i in current_favourites): action, text = favourites_cache.remove_from_favourites, '%s alkoFlix %s?' % (ls(32603), ls(32453))
		else: action, text = favourites_cache.add_to_favourites, '%s alkoFlix %s?' % (ls(32602), ls(32453))
		if not confirm_dialog(text='%s[CR][CR]%s' % (title, text)): return
		if action(media_type, tmdb_id, title): notification(32576)
		else: notification(32574)

# Lance une bande-annonce depuis une action Kodi, sans passer par la fenêtre Extras.
# Avant la lecture, l'extension YouTube est vérifiée afin d'éviter un clic sans effet.
def play_trailer(content, meta):
	try:
		media_type = 'movie' if content == 'movie' else 'tvshow'
		poster = meta.get('poster')
		tmdb_id = meta.get('tmdb_id')
		trailer_url = meta.get('trailer') or meta.get('trailer_url') or ''
		url = trailer_choice(media_type, poster, tmdb_id, trailer_url, prefer_french=True)
		if not url or url == 'canceled': return notification(32760, 1500)
		if url.startswith('plugin://plugin.video.youtube'):
			purpose = 'Pour pouvoir lire la bande-annonce, l’extension [B]YouTube[/B] doit être installée et activée.'
			if not kodi_utils.ensure_addon_installed('plugin.video.youtube', 'YouTube', purpose): return
		return execute_builtin('PlayMedia(%s)' % url)
	except Exception as e:
		kodi_utils.logger('erreur lecture bande annonce', str(e))
		return notification(32574, 1500)

# Point d'entrée utilisé par le menu contextuel natif de Kodi.
# Les métadonnées sont relues au moment du clic pour éviter de transporter
# un gros dictionnaire JSON dans l'URL du menu contextuel.
def play_trailer_choice(params):
	try:
		media_type = params.get('media_type') or params.get('content') or 'movie'
		if media_type in ('movies', 'movie'): media_type = 'movie'
		else: media_type = 'tvshow'
		function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', params['tmdb_id'], settings.metadata_user_info(), get_datetime())
		if not meta: return notification(32760, 1500)
		return play_trailer(media_type, meta)
	except Exception as e:
		kodi_utils.logger('erreur menu contextuel bande annonce', str(e))
		return notification(32574, 1500)

# Menu contextuel principal d'un média ou d'un widget.
def options_menu(params, meta=None):
	def _builder():
		for item in listing:
			kwargs = {'line1': item[1]}
			if item[2] and item[2] != item[1]: kwargs['line2'] = item[2]
			if len(item) == 4: kwargs['icon'] = item[3]
			yield kwargs
	is_widget = params.get('is_widget', 'false').lower() == 'true'
	content = params.get('content') or container_content()[:-1]
	season, episode = params.get('season'), params.get('episode')
	if not meta:
		function = metadata.movie_meta if content == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', params['tmdb_id'], settings.metadata_user_info(), get_datetime())
	watched_indicators = settings.watched_indicators()
	on_str, off_str, currently_str, open_str, settings_str = ls(32090), ls(32027), ls(32598), ls(32641), ls(32247)
	results_xml_style_status = get_setting('results.xml_style', 'Par défaut')
	active_internal_scrapers = [i.replace('_', '') for i in settings.active_internal_scrapers()]
	uncached_torrents_status, uncached_torrents_toggle = (on_str, 'false') if settings.display_uncached_torrents() else (off_str, 'true')
	base_str1, base_str2 = '%s%s', '%s: [B]%s[/B]' % (currently_str, '%s')
	multi_line = 'true' if content in ('movie', 'episode') else 'false'
	listing = (
		('scrape_from_episode_group', "Scraper depuis le groupe d’épisodes", '', meta['poster']) if content == 'episode' else None,
		('clear_and_rescrape', ls(32014), '', meta['poster']) if multi_line == 'true' else None,
		('rescrape_with_disabled', ls(32006), '', meta['poster']) if multi_line == 'true' else None,
		('scrape_with_filters_ignored', ls(32807), '', meta['poster']) if multi_line == 'true' else None,
		('scrape_with_custom_values', ls(32135), '', meta['poster']) if multi_line == 'true' else None,
		('play_random', ls(32541), '', meta['poster']) if content in ('tvshow') and meta else None,
		('play_random_continual', ls(32542), '', meta['poster']) if content in ('tvshow') and meta else None,
		('clear_scrapers_cache', ls(32637), '') if content in ('movie', 'episode') else None,
		('open_external_scrapers_choice', ls(32118), ''),
		('toggle_torrents_display_uncached', base_str1 % ('', ls(32160)), base_str2 % uncached_torrents_status) if multi_line == 'true' and 'external' in active_internal_scrapers else None,
		('set_results_xml_display', base_str1 % ('', '%s %s' % (ls(32139), ls(32140))), base_str2 % results_xml_style_status) if multi_line == 'true' else None,
		('clear_trakt_cache', ls(32497) % ls(32037), '') if watched_indicators == 1 else None,
		('clear_mdbl_cache', ls(32497) % 'MDBList', '') if watched_indicators == 2 else None,
		('clear_media_cache', ls(32604) % (ls(32028) if content in ('movie') else ls(32029)), '', meta['poster']) if content in ('movie', 'tvshow') and meta else None,
		('open_alkoflix_settings', '%s %s %s' % (open_str, ls(32036), settings_str), ''),
		('reload_widgets', 'alkoFlix : rafraîchir les widgets', '') if is_widget else None
	)
	listing = [item for item in listing if item]
	list_items = list(_builder())
	heading = ls(32646).replace('[B]', '').replace('[/B]', '')
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'multi_line': multi_line}
	choice = select_dialog([i[0] for i in listing], **kwargs)
	if   choice in (None, 'save_and_exit'): return
	elif choice == 'clear_and_rescrape': return clear_and_rescrape(content, meta, season, episode)
	elif choice == 'rescrape_with_disabled': return rescrape_with_disabled(content, meta, season, episode)
	elif choice == 'scrape_with_filters_ignored': return scrape_with_filters_ignored(content, meta, season, episode)
	elif choice == 'scrape_with_custom_values': return scrape_with_custom_values(content, meta, season, episode)
	elif choice == 'scrape_from_episode_group': return scrape_from_episode_group(meta, season, episode)
	elif choice == 'play_random': return random_choice(choice, meta)
	elif choice == 'play_random_continual': return random_choice(choice, meta)
	elif choice == 'clear_scrapers_cache': return clear_scrapers_cache()
	elif choice == 'open_external_scrapers_choice': return source_utils.enable_disable('all')
	elif choice == 'toggle_torrents_display_uncached': set_setting('torrent.display.uncached', uncached_torrents_toggle)
	elif choice == 'set_results_xml_display': results_layout_choice()
	elif choice == 'clear_trakt_cache': return clear_cache('trakt')
	elif choice == 'clear_mdbl_cache': return clear_cache('mdblist')
	elif choice == 'clear_media_cache': return refresh_cached_meta(meta)
	elif choice == 'open_alkoflix_settings': return kodi_utils.open_settings('0.0')
	# Ancienne méthode conservée comme référence : rafraîchissement ciblé des widgets.
#	elif choice == 'reload_widgets': return kodi_utils.widget_refresh()
	elif choice == 'reload_widgets': return execute_builtin('ReloadSkin()')
	if   choice in ('clear_trakt_cache', 'clear_mdbl_cache') and content in ('movie', 'tvshow', 'season', 'episode'): container_refresh()
	show_busy_dialog()
	sleep(200)
	hide_busy_dialog()
	options_menu(params, meta=meta)

# Ouverture de la fenêtre Extras pour le média sélectionné.
def extras_menu(params):
	from windows import open_window
	function = metadata.movie_meta if params['media_type'] == 'movie' else metadata.tvshow_meta
	meta = function('tmdb_id', params['tmdb_id'], settings.metadata_user_info(), get_datetime())
	open_window(('windows.extras', 'Extras'), 'extras.xml', meta=meta, is_widget=params.get('is_widget', 'false'), is_home=params.get('is_home', 'false'))

# Rafraîchit uniquement les métadonnées en cache du média ciblé.
def refresh_cached_meta(meta):
	from caches.meta_cache import MetaCache
	try:
		media_type, tmdb_id = meta['mediatype'], meta['tmdb_id']
		MetaCache().delete(media_type, 'tmdb_id', tmdb_id, meta)
		if media_type == 'tvshow': MetaCache().delete_all_seasons_memory_cache(tmdb_id)
		notification(32576, 1500)
		container_refresh()
	except: notification(32574)

# Construction du dialogue permettant de sauter vers une page ou une lettre.
def build_navigate_to_page(params):
	use_alphabet = settings.nav_jump_use_alphabet() == 2
	icon = media_path('item_jump.png')
	media_type = params.get('media_type')
	def _builder(use_alphabet):
		for i in start_list:
			if use_alphabet: line1, line2 = i.upper(), ls(32821) % (media_type, i.upper())
			else: line1, line2 = '%s %s' % (ls(32022), i), ls(32822) % i
			yield {'line1': line1, 'line2': line2, 'icon': icon}
	if use_alphabet:
		start_list = [chr(i) for i in range(97,123)]
	else:
		start_list = [str(i) for i in range(1, int(params.get('total_pages'))+1)]
		start_list.remove(params.get('current_page'))
	list_items = list(_builder(use_alphabet))
	kwargs = {'items': json.dumps(list_items), 'heading': 'alkoFlix'}
	new_start = select_dialog(start_list, **kwargs)
	sleep(100)
	if new_start is None: return
	if use_alphabet: new_page, new_letter = '', new_start
	else: new_page, new_letter = new_start, None
	url_params = {'mode': params.get('transfer_mode', ''), 'action': params.get('transfer_action', ''), 'new_page': new_page, 'new_letter': new_letter,
				'media_type': params.get('media_type', ''), 'query': params.get('query', ''), 'actor_id': params.get('actor_id', ''),
				'user': params.get('user', ''), 'slug': params.get('slug', ''), 'list_id': params.get('list_id', ''), 'name': params.get('name', '')}
	execute_builtin('Container.Update(%s)' % build_url(url_params))

# Vide les caches des scrapers internes et externes.
def clear_scrapers_cache(silent=False):
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification(32576)

# Supprime le cache de sources du média, puis relance un scrape propre.
def clear_and_rescrape(media_type, meta, season=None, episode=None):
	from caches.providers_cache import ExternalProvidersCache
	from modules.sources import SourceSelect
	show_busy_dialog()
	deleted = ExternalProvidersCache().delete_cache_single(media_type, str(meta['tmdb_id']))
	hide_busy_dialog()
	if not deleted: return notification(32574)
	play_params = {'mode': 'play_media', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false'}
	if media_type == 'movie': play_params.update({'media_type': 'movie'})
	else: play_params.update({'media_type': 'episode', 'season': season, 'episode': episode})
	SourceSelect().playback_prep(play_params)

# Relance le scrape en incluant aussi les sources désactivées.
def rescrape_with_disabled(media_type, meta, season=None, episode=None):
	from modules.sources import SourceSelect
	play_params = {'mode': 'play_media', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'disabled_ignored': 'true', 'prescrape': 'false'}
	if media_type == 'movie': play_params.update({'media_type': 'movie'})
	else: play_params.update({'media_type': 'episode', 'season': season, 'episode': episode})
	SourceSelect().playback_prep(play_params)

# Relance le scrape en ignorant les filtres configurés.
def scrape_with_filters_ignored(media_type, meta, season=None, episode=None):
	from modules.sources import SourceSelect
	play_params = {'mode': 'play_media', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'ignore_scrape_filters': 'true'}
	if media_type == 'movie': play_params.update({'media_type': 'movie'})
	else: play_params.update({'media_type': 'episode', 'season': season, 'episode': episode})
	set_property('fs_filterless_search', 'true')
	SourceSelect().playback_prep(play_params)

# Relance le scrape avec un titre, une année, une saison ou un épisode personnalisés.
def scrape_with_custom_values(media_type, meta, season=None, episode=None):
	from windows import open_window
	from modules.sources import SourceSelect
	play_params = {'mode': 'play_media', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false'}
	if media_type in ('movie', 'movies'): play_params.update({'media_type': 'movie'})
	else: play_params.update({'media_type': 'episode', 'season': season, 'episode': episode})
	custom_title = kodi_utils.dialog.input(ls(32228), defaultt=meta['title'])
	if not custom_title: return
	play_params['custom_title'] = custom_title
	if media_type in ('movie', 'movies'):
		custom_year = kodi_utils.dialog.numeric(0, '%s (%s)' % (ls(32543), ls(32669)), defaultt=str(meta['year']))
		if custom_year: play_params.update({'custom_year': custom_year})
	else:
		custom_season = kodi_utils.dialog.numeric(0, '%s (%s)' % (ls(32537).title(), ls(32669)), defaultt=str(season))
		custom_episode = kodi_utils.dialog.numeric(0, '%s (%s)' % (ls(32203).title(), ls(32669)), defaultt=str(episode))
		if custom_season and custom_episode: play_params.update({'custom_season': custom_season, 'custom_episode': custom_episode})
	kwargs = {'meta': meta, 'enable_buttons': True, 'true_button': ls(32824), 'false_button': ls(32828), 'focus_button': 11}
	choice = open_window(('windows.sources', 'ProgressMedia'), 'progress_media.xml', text='%s?' % ls(32006), **kwargs)
	if choice is None: return
	if choice: play_params['disabled_ignored'] = 'true'
	choice = open_window(('windows.sources', 'ProgressMedia'), 'progress_media.xml', text=ls(32808), **kwargs)
	if choice is None: return
	if choice:
		play_params['ignore_scrape_filters'] = 'true'
		set_property('fs_filterless_search', 'true')
	SourceSelect().playback_prep(play_params)

# Permet de scraper un épisode selon un groupe d'épisodes TMDb alternatif.
def scrape_from_episode_group(meta, season=None, episode=None):
	from indexers.tmdb_api import episode_groups, episode_group_details
	from modules.sources import SourceSelect
	user_info = settings.metadata_user_info()
	tmdb_id, heading, poster = meta['tmdb_id'], meta['tvshowtitle'], meta['poster']
	groups = episode_groups(tmdb_id, user_info['tmdb_api'])
	choices = [
		(item['id'], '%s (%s)' % (item['name'], item['type']), '%s groupes, %s épisodes' % (item['group_count'], item['episode_count']))
		for item in groups
	]
	if not choices: return notification(32760)
	list_items = [{'line1': item[1], 'line2': item[2], 'icon': poster} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'enumerate': 'true', 'multi_line': 'true'}
	choice = select_dialog([i[0] for i in choices], **kwargs)
	if choice is None: return
	# Récupère l'épisode original afin de prépositionner la sélection autour de l'épisode courant.
	episodes_data = metadata.season_episodes_meta(season, meta, user_info)
	orig_ep = next((i for i in episodes_data if i['season'] == int(season) and i['episode'] == int(episode)), {})
	title, premiered = orig_ep.get('title', ''), orig_ep.get('premiered', '')
	episodes = episode_group_details(choice, user_info['tmdb_api'])
	if not episodes: return notification(32760)
	episodes = [
		{**episode, 'custom_episode': episode['order'] + 1, 'custom_season': group['order'],
		'custom_name': f"S{group['order']}xE{episode['order'] + 1:02d} - {episode['name']}",
		'custom_title': f"S{episode['season_number']}xE{episode['episode_number']:02d} - {episode['name']}"}
		for group in episodes for episode in group['episodes']
	]
	index = next((
		episodes.index(i) for i in episodes
		if i['season_number'] == int(season) and i['episode_number'] == int(episode)
	), None)
	if index is None: preselect = []
	else: episodes, preselect = episodes[index:] + episodes[:index], [0]
	choices = [(item['custom_season'], item['custom_episode'], item['custom_name'], item['custom_title']) for item in episodes]
	if not choices: return
	list_items = [{'line1': item[2], 'line2': item[3], 'icon': poster} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': title, 'multi_line': 'true', 'preselect': preselect}
	choice = select_dialog([(i[0], i[1]) for i in choices], **kwargs)
	if choice is None: return
	play_params = {'mode': 'play_media', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'season': season, 'episode': episode}
	play_params.update({'custom_season': choice[0], 'custom_episode': choice[1]})
	SourceSelect().playback_prep(play_params)
