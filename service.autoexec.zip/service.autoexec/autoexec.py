import xbmc

# Commande à exécuter
xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.vstream/?site=pastebin&function=refreshAllPaste",return)')


# Effectuer un "skin reload"
xbmc.executebuiltin('ReloadSkin(reload)')
