import requests
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
import os
import re
import time
import sys
import unicodedata 
import threading
from medias import TMDB
import json
from medias import Media, TMDB
import sqlite3
from util import *
try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    import xbmcgui
    import xbmcplugin

    ADDON = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
    KEYTMDB = ADDON.getSetting("apikey")
    HANDLE = int(sys.argv[1])
    BDBOOKMARK = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.sendtokodiU2P/bookmarkUptobox.db')
except: pass
NBMEDIA = 30

class RenameMedia:

    def extractInfo(self, name, typM="serie"):
        name = unquote(name)
        if typM == "movie":
            motif = r"""(?P<film>.*)([_\.\(\[ -]{1})(?P<an>19\d\d|20\d\d)([_\.\)\] -]{1})(.*)"""
            try:
                r = re.match(motif, name)
                title = r.group('film')
            except:
                title = name[:-4]
            try:
                year = int(r.group('an').replace('.', ''))
            except:
                year = 0
            if r:
                nameFinal = self.correctNom(title)
                nameFinal = nameFinal.replace(str(year), "")
            else:
                nameFinal = name

            return [nameFinal, year]
                        
        else:
            for m in ["_", " ", "[", "]", "-", "(", ")", "{", "}"]:
                name = name.replace(m, ".")
            tab_remp = [r'''-|_|iNTERNAL|MULTi|2160p|4k|1080p|720p|480p|WEB-DL|hdlight|WEB|AC3|aac|hdtv|hevc|\d\dbit|subs?\.|vos?t?|x\.?265|STEGNER|x\.?264|FRENCH|DD\+.5.1|DD\+| |SR\.?71|h264|h265|1920x1080''', '.']
            name = re.sub(tab_remp[0], tab_remp[1], name, flags=re.I)
            name = re.sub(r"\.{2,}", ".", name)
            masque = r'(?P<year>19\d\d|20\d\d)'
            r = re.search(masque, name)
            if r:
                year = r.group("year")
            else:
                year = 0
        
            if year:
                name = name.replace(year, "")
            masques = [r'[sS](?P<saison>\d?\d)\.?((?i)ep?)\.?(?P<episode>\d\d\d\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?((?i)ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'(?P<saison>\d?\d)\.?((?i)x)\.?(?P<episode>\d?\d?\d)\.',
                       r'(\.)((?i)ep?)\.?(?P<episode>\d?\d?\d)\.',
                       r'((?i)part)\.?(?P<episode>\d)\.',
                       r'((?i)dvd)\.?(?P<episode>\d)\.',
                       r'((?i)Saison)\.?(?P<saison>\d?\d)\.?((?i)Episode|e)\.?(?P<episode>\d?\d)\.',
                       r'[sS](?P<saison>\d?\d)\.?((?i)ep?)\.?(?P<episode>\d?\d?\d)',
                       r'((?i)ep?)\.?(?P<episode>[0-1][0-8]\d\d)\.',
                       r'((?i)ep?)\.?(?P<episode>\d?\d?\d)',
                       r'(?P<episode>[0-1][0-8]\d\d)',
                       r'(?P<episode>\d?\d?\d)',
                       ]
            
            for motif in masques:
                r = re.search(motif, name)
                if r:
                    try:
                        try:
                            saison = "%s" %r.group("saison").zfill(2)
                            valid = 1
                        except:
                            saison = "01"
                        try:
                            numEpisode = "S%sE%s" %(saison, r.group("episode").zfill(4))
                        except:
                            numEpisode = ""
                       
                    except Exception as e:
                        print(e)
                    nameFinal = name[:r.start()]                    
                    break
            if r:
                return [nameFinal, saison, numEpisode, year]
            else:
                return [name, "", "", year]
    
    def correctNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        tab_remp = [r'''\(.*\)|_|\[.*\]| FR |(?i)Episode| {2,}''', ' ']
        title = re.sub(tab_remp[0], tab_remp[1], title)
        for repl in tabRep:
                title = title.replace(repl[0], repl[1])
        title = re.sub(r"^ \.?", "", title)
        title = re.sub(r"\.{2,}", ".", title)
        title = re.sub(r" {2,}", " ", title)
        return title       

    def nettNom(self, title, tabRep=[]):
        title = unquote(title, encoding='latin-1', errors='replace')
        title = unicodedata.normalize('NFD', title).encode('ascii','ignore').decode("latin-1")
        for repl in tabRep:
            title = title.replace(repl[0], repl[1])
        return title     

class BookmarkUpto:

    def __init__(self, database):
        self.database = database
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS series(
          `id`    INTEGER PRIMARY KEY,
          repo TEXT,
          rep TEXT,
          nom TEXT,
          num INTEGER,
          actif INTEGER DEFAULT 1,
          UNIQUE (repo, rep))
            """)
        cnx.commit()
        cur.close()
        cnx.close

    def insertSeries(self, repo, tab):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        cur.execute("UPDATE series SET actif=0 WHERE repo=?", (repo,))
        cnx.commit()
        for t in tab:
            try:
                cur.execute("INSERT INTO series (repo, rep, nom, num) VALUES (?, ?, ?, ?)", (repo, t[0], t[1], t[2],))
            except sqlite3.Error as er:
                cur.execute("UPDATE series SET actif=1 WHERE repo=? and rep=?", (repo, t[0],))
        cnx.commit()
        cur.close()
        cnx.close    

    def getSeries(self, repo, limit, offset):
        cnx = sqlite3.connect(self.database)
        cur = cnx.cursor()
        sql = "SELECT nom, rep FROM series WHERE repo='{}' AND actif=1 ORDER BY id DESC LIMIT {} OFFSET {}".format(repo, limit, offset)
        cur.execute(sql)
        liste = cur.fetchall()
        cur.close()
        cnx.close    
        return liste                           

class Uptobox:

    def __init__(self, key=''):
        self.baseurl = "https://uptobox.com"
        self.urlFile = self.baseurl + '/api/user/files'
        self.key = key.strip()
        self.totalSize = 0
        self.tabFolder = []

    def getFileFolderPublic(self, folder="", hash="", limit=100, offset=0):
        """extract info folder upto publique""" 
        tabMedia = []
        url = self.baseurl + "/api/user/public?folder={}&hash={}&limit={}&offset={}".format(folder, hash, limit, offset)
        data = self.getDataJson(url)
        if data['data']["list"]:
            [tabMedia.append((d['file_created'], d['file_name'], d['file_code'])) for d in data['data']["list"]]
            #[tabMedia.append((d['file_name'], d['file_code'])) for d in data['data']["list"]]
        return tabMedia

    def getFileFolderPublicAll(self, folder="", hash=""):
        """extract info folder upto publique""" 
        i, j = 100, 0
        tabMedia = []
        while 1:
            try:
                url = self.baseurl + "/api/user/public?folder={}&hash={}&limit={}&offset={}".format(folder, hash, i, j)
                r = requests.get(url)
                data = r.json()
                if data['data']["list"]:
                    [tabMedia.append((d['file_created'], d['file_name'], d['file_code'])) for d in data['data']["list"]]
                    j += i
                else:
                    break
            except: break
        return [(x[1], x[2]) for x in tabMedia[::-1]]

    def singleFolder(self, rep="//", nbFile=20, offset=0):
        """extraction infos rep + fichiers"""
        if nbFile > 100:
            nbFile = 100
        tabFile = []
         
        tabFolder = []
        url = self.baseurl + "/api/user/files?token=%s&path=%s&limit=%d&offset=%d" %(self.key, rep, nbFile, offset)
        try:
            data = self.getDataJson(url)
            if data:
                for file in data['data']["files"]:
                    tabFile.append((file["file_name"], file["file_code"]))
        except Exception as e:
            sys.exit() 
        tabFolderChild = [(folder["fullPath"], folder["name"], folder["fld_id"]) for folder in data['data']["folders"]]  
        try:
            tabFolder = (rep, data['data']['currentFolder']["name"], nbFile, data['data']['currentFolder']["fld_id"], tabFile, tabFolderChild)
        except:
            tabFolder = (rep, "racine", nbFile, data['data']['currentFolder']["fld_id"], tabFile, tabFolderChild)
        return tabFolder 
    
    def singleFolderFolder(self, rep="//", nbFolder=20, offset=0):
        """extraction infos rep"""
        tabFolder = []
        url = self.baseurl + "/api/user/files?token=%s&path=%s&limit=1&offset=0" %(self.key, rep)
        try:
            data = self.getDataJson(url)
        except Exception as e:
            sys.exit() 
        
        tabFolderChild = [(folder["fullPath"], folder["name"], folder["fld_id"]) for folder in data['data']["folders"]]
        return tabFolderChild

    def nbFilesRep(self, rep="//"):
        """ renvoi le nombre de fichier dans un repertoire """
        i = 5
        j = 0 
        url = self.baseurl + "/api/user/files?token=%s&path=%s&limit=%d&offset=%d" %(self.key, rep, i, j)
        data = self.getDataJson(url)
        try:
            nbMedia = int(data['data']['currentFolder']['fileCount'])
        except Exception as e:
            sys.exit()
        return nbMedia

    def extractAll(self):
        url = self.baseurl + "/api/user/files/all?token=%s" %self.key
        data = self.getDataJson(url)
        #print(str(data.keys()).encode(sys.stdout.encoding, errors='replace'))
        if "data" in data.keys():
            tabFiles = [(x["file_name"], x['file_code']) for x in data['data']]
        else:
            tabFiles = []
        return tabFiles

    def getDataJson(self, url, nbTest=1):
        """reconnection error json"""
        headers = {'Accept': 'application/json'}
        try:
            data = requests.get(url, headers=headers).json()
        except :
            time.sleep(0.5 * nbTest)
            nbTest += 1
            if nbTest > 5:
                sys.exit()
            return self.getDataJson(url, nbTest)
        else:
            return data

    def linkDownload(self, fileCode):
        url1 = self.baseurl + "/api/link?token=%s&file_code=%s" % (self.key, fileCode)
        try:
            req = requests.get(url1)
            dict_liens = req.json()
            dlLink = dict_liens["data"]["dlLink"]
            statut = dict_liens["statusCode"]
        except Exception as e:
            dlLink = ""
            statut = "err"

        return dlLink, statut

    def file_search(self, path: str, limit: int, search: str):
        url1 = self.baseurl + "/api/user/files?token={}&path={}&limit={}&searchField=file_name&search={}".format(self.key, path, limit, search)
        request = requests.get(url1).text
        info = json.loads(request)
        files_name = [(element["file_name"], element["file_code"]) for element in info["data"]["files"]]
        return files_name

class Alldedrid:

    def __init__(self, key):
        self.key = key.strip()
        self.urlBase = "https://api.alldebrid.com"

    @property
    def extractMagnets(self):
        url = self.urlBase + "/v4/magnet/status?agent=u2p&apikey=%s" %self.key
        tx = requests.get(url)
        dictInfo = json.loads(tx.text)
        tabLinks = []
        for media in dictInfo["data"]["magnets"]:
            if media["status"] == "Ready":
                for link in media["links"]:
                    if link["filename"][-4:] in [".mp4", ".mkv", ".avi", "dixw", ".mp3"]:
                        tabLinks.append((link["filename"], link["link"].replace("https://uptobox.com/", "")))
        return tabLinks[::-1]

    def extractListe(self, t="history"):
        #history , links
        url = self.urlBase + "/v4/user/%s?agent=u2p&apikey=%s" %(t, self.key)
        tx = requests.get(url)
        dictInfo = json.loads(tx.text)
        notice(dictInfo)
        tabLinks = []
        for link in dictInfo["data"]["links"]:
            if link["filename"][-4:] in [".mp4", ".mkv", ".avi", "dixw", ".mp3"]:
                tabLinks.append((link["filename"], link["link"].replace("https://uptobox.com/", "")))
        return tabLinks

    def linkDownload(self, lien):
        dlLink = ""
        url1 = self.urlBase + "/v4/link/unlock?agent=u2p&apikey=%s&link=https://uptobox.com/%s" % (self.key , lien)
        req = requests.get(url1)
        dict_liens = req.json()
        try:
            if dict_liens["status"] == "success":
                dlLink = dict_liens['data']['link']
                statut = "success"
            else:
                statut = dict_liens["error"]["code"]
        except: 
            dlLink = ""
            statut = "err"           
        return dlLink, statut
        
#===================================================================================== fonctions ==========================================================================
def loadUpto(params):
    # par nom de folder
    rep = params["rep"]
    offset = params["offset"]
    key = ADDON.getSetting("keyUpto")
    if key:
        up = Uptobox(key=key)
        tabExtract = up.singleFolder(rep=rep, nbFile=NBMEDIA, offset=int(offset))
        medias = ventilationType(tabExtract[4])
        affUptobox("movie", [x[1:]  for x in medias], params)

def loadUptoP(params):
    #folder public
    numHash = params["hash"]
    folder = params["folder"]
    offset = int(params["offset"])
    up = Uptobox(key="123456789")
    tabExtract = up.getFileFolderPublicAll(hash=numHash, folder=folder)
    medias = ventilationType(tabExtract[offset: offset + NBMEDIA])
    affUptobox("movie", [x[1:]  for x in medias], params)

def searchUpto():
    # recherche dans le nom de fichier
    dialog = xbmcgui.Dialog()
    d = dialog.input("Texte recherche", type=xbmcgui.INPUT_ALPHANUM)
    if d:
        key = ADDON.getSetting("keyUpto")
        if key:
            up = Uptobox(key=key)
            tabFiles = up.file_search("//", NBMEDIA, d)
            medias = ventilationType(tabFiles)
            affUptobox("movie", [x[1:]  for x in medias])

def loadSeriesUpto(params):
    #extraction des dossiers serie
    rep = params["rep"]
    offset = int(params["offset"])
    key = ADDON.getSetting("keyUpto")
    if key:
        bd = BookmarkUpto(BDBOOKMARK)
        mDB = TMDB(KEYTMDB)
        if offset == 0:
            up = Uptobox(key=key)
            tabExtract = up.singleFolderFolder(rep=rep, nbFolder=NBMEDIA, offset=offset)
            bd.insertSeries(rep, tabExtract[::-1])
        liste =  bd.getSeries(rep, NBMEDIA, offset)
        for i, (nom, rep) in enumerate(liste):
            r = re.search(r"(TM)(?P<num>\d*)(TM)", nom)
            if r:
                numId = r.group("num")
                threading.Thread(name="tet", target=mDB.tvshowId, args=(nom, rep, i, numId,)).start()
            else:
                r = re.search(r"(?P<name>.*)\((?P<year>\d*)\)", nom)
                if r:
                    year = r.group("year").strip()
                    nom = r.group("name").strip()                    
                else:
                    year = 0
                threading.Thread(name="tet", target=mDB.searchTVshow, args=(nom, rep, i, int(year),)).start()
        while threading.active_count() > 1:
            time.sleep(0.1)
        medias = mDB.extractListe
        affUptoboxSeries("tvshow", [x[1:]  for x in medias], params)

def loadSaisonsUpto(params):
    typMedia = "tvshow"
    numId = params["u2p"]
    rep = params["rep"]

    mDB = TMDB(KEYTMDB)
    dictSaison = mDB.serieNumIdSaison(numId)   
    key = ADDON.getSetting("keyUpto")
    up = Uptobox(key=key)
    tabExtract = up.singleFolderFolder(rep=rep, nbFolder=NBMEDIA, offset=0)
    choixsaisons = []
    for rep, saison, num in tabExtract:
        r = re.search(r"(?P<num>\d+)", saison)
        if r: 
            numSaison = int(r.group('num'))
            infos = dictSaison[numSaison]
            choixsaisons.append((infos[0], {"action": "visuEpisodesUpto", "u2p": numId, "saison": numSaison, "rep": rep}))
    xbmcplugin.setPluginCategory(HANDLE, "Menu")
    xbmcplugin.setContent(HANDLE, 'episodes')
    categories = [("[COLOR red]Bande Annonce[/COLOR]", {"action": "ba", "u2p": numId, "typM": typMedia})] + choixsaisons + \
        [("Acteurs", {"action": "affActeurs", "u2p": numId, "typM": typMedia}),\
        ("Similaires", {"action": "suggest", "u2p": numId, "typ": "Similaires","typM": typMedia}), \
        ("Recommandations", {"action": "suggest", "u2p": numId, "typ": "Recommendations", "typM": typMedia})]
    for cat in categories:
        if "saison" in cat[1].keys(): 
            numSaison = cat[1]["saison"]
            try:
                tab = dictSaison[numSaison]
                lFinale = ["", tab[2], "", "", tab[1], "", numId, tab[1]]
            except Exception as e:
                notice(str(e))

            media = Media("menu", *lFinale)
            media.saison = numSaison
            media.typeMedia = typMedia
        else:
            media = ""        
        addDirectorySaisons(cat[0], isFolder=True, parameters=cat[1], media=media)
    xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True)


def addDirectorySaisons(name, isFolder=True, parameters={}, media="" ):
    li = xbmcgui.ListItem(label=name)
    if media:
        li.setInfo('video', {"title": media.title, 'plot': media.overview, 'genre': media.genre,
                "year": media.year, 'mediatype': media.typeMedia, "rating": media.popu})
        li.setArt({'icon': media.backdrop,
                    "thumb": media.poster,
                    'poster':media.poster,
                    'fanart': media.backdrop
                    })
        
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)

def ventilationType(tabFiles):
    # ventilation films, serie divers
    tabCorrect = [("[", "."), ("]", "."), ("{", "."), ("}", "."), (" ", "."), ("(", "."), (")", ".")]
    renam = RenameMedia()
    mDB = TMDB(KEYTMDB)
    for i, (nom, filecode) in enumerate(tabFiles):
        if nom[-4:] not in [".zip", ".rar", ".pdf", ".doc", ".xls", ".txt", ".mp3"]:
            if re.search(r"s\d\d?\d?\.?e\d\d?\d?\.", renam.nettNom(nom, tabCorrect), re.I):
                title, saison, episode, year = renam.extractInfo(nom, typM="tvshow")
                threading.Thread(name="tet", target=mDB.searchEpisode, args=(title, saison, episode, filecode, i, int(year),)).start()
            elif re.search(r"\.19\d\d\.|\.20\d\d\.", renam.nettNom(nom, tabCorrect)):
                title, year = renam.extractInfo(nom, typM="movie")
                threading.Thread(name="tet", target=mDB.searchMovie, args=(title, filecode, i, year, nom, )).start()
            else:
                mDB.tabMediaFinal.append((i, nom, "", 0, "", 0, "", "", filecode, "", 0, 0))
        else:
            mDB.tabMediaFinal.append((i, nom, "", 0, "", 0, "", "", filecode, "", 0, 0))
    while threading.active_count() > 1:
        time.sleep(0.1)
    medias = mDB.extractListe
    return sorted(medias)

def affEpisodesUpto(params):
    numId = params["u2p"]  
    saison = params["saison"]
    rep = params["rep"]
    key = ADDON.getSetting("keyUpto")
    renam = RenameMedia()
    if key:
        up = Uptobox(key=key)
        tabExtract = up.singleFolder(rep=rep, nbFile=1200, offset=0)
        liste = tabExtract[4]
        typM = "episode"
        xbmcplugin.setPluginCategory(HANDLE, "Episodes")
        xbmcplugin.setContent(HANDLE, 'episodes')
        mdb = TMDB(KEYTMDB)
        tabEpisodes = mdb.saison(numId, saison)

        for nom, filecode in sorted(liste):
            _, _, episode, _ = renam.extractInfo(nom, typM="tvshow")
            numEpisode = int(episode.split("E")[1])
            #"72879"    "Saison 05" "S05E59"    "7UM9cgSAc@TEgCpOiQtH3G#1080P"
            l = [numId, saison, episode, filecode]
            try:
                lFinale = list(l) + list([episode for episode in tabEpisodes if numEpisode == episode[-1]][0])
            except:
                lFinale = list(l) + ["Episode", "Pas de synopsis ....", "", "", "", saison, numEpisode]
            isVu = 0
            lFinale.append(isVu)
            media = Media("episode", *lFinale)
            media.typeMedia = typM
            media.numId = int(numId)
            #notice(lFinale)
            #addDirectoryEpisodes("E%d - %s" %(numEpisode, media.title), isFolder=False, parameters={"action": "playMediaUptobox", "lien": media.link, "u2p": media.numId, "episode": media.episode}, media=media)
            addDirectoryUptobox("E%d - %s" %(numEpisode, media.title), isFolder=False, \
                parameters={"action": "playMediaUptobox", "lien": media.link, "u2p": media.numId, "episode": media.episode, "saison": media.saison, "rep": rep}, media=media)
        xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True)

def affUptoboxSeries(typM, medias, params=""):
    xbmcplugin.setPluginCategory(HANDLE, typM)
    xbmcplugin.setContent(HANDLE, "tvshows")
    i = -1
    for i, media in enumerate(medias):
        try:
            med = Media("movie", *media[:-1])
        except:
            med = Media("movie", *media)
        ok = addDirectoryUptobox("%s" %(med.title), isFolder=True, parameters={"action": "affSaisonUpto", "rep": quote(med.link), "u2p": med.numId}, media=med)                
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    if i > -1:
        if i >= (NBMEDIA - 1):
            addDirNext(params)            
    xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True, cacheToDisc=True)

def magnets(params):
    offset = int(params["offset"])
    key = ADDON.getSetting("keyalldebrid")
    if key:
        up = Alldedrid(key=key)
        tabFiles = up.extractMagnets
        medias = ventilationType(tabFiles[::-1][offset: offset + NBMEDIA])
        affUptobox("movie", [x[1:]  for x in medias], params)

def listeAllded(params):
    offset = int(params["offset"])
    t = params["typeL"]
    key = ADDON.getSetting("keyalldebrid")
    if key:
        up = Alldedrid(key=key)
        tabFiles = up.extractListe(t)
        medias = ventilationType(tabFiles[::-1][offset: offset + NBMEDIA])
        affUptobox("movie", [x[1:]  for x in medias], params)

def newUpto(params):
    offset = int(params["offset"])
    key = ADDON.getSetting("keyUpto")
    if key:
        up = Uptobox(key=key)
        tabFiles = up.extractAll()
        medias = ventilationType(tabFiles[::-1][offset: offset + NBMEDIA])
        affUptobox("movie", [x[1:]  for x in medias], params)
    
def affUptobox(typM, medias, params=""):
    xbmcplugin.setPluginCategory(HANDLE, typM)
    xbmcplugin.setContent(HANDLE, 'movies')
    i = -1
    for i, media in enumerate(medias):
        try:
            media = Media(typM, *media[:-1])
        except:
            media = Media(typM, *media)
        if "*" in media.link:
            paramsIn = dict(parse_qsl(media.link.split("*")[1]))
            ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters=paramsIn, media=media)                
        else:
            if " (S" in media.title:
                ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters={"action": "playMediaUptobox", "lien": media.link, "u2p": media.numId, "typM": media.title.split(" ")[-1]}, media=media)
            else:
                ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters={"action": "playMediaUptobox", "lien": media.link, "u2p": media.numId}, media=media)                
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    if i > -1:
        if i >= (NBMEDIA - 1):
            addDirNext(params)            
    xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True, cacheToDisc=True)

def affUptoboxNews(typM, medias, params=""):
    xbmcplugin.setPluginCategory(HANDLE, typM)
    xbmcplugin.setContent(HANDLE, 'movies')
    i = -1
    for i, media in enumerate(medias):
        try:
            media = Media(typM, *media[:-1])
        except:
            media = Media(typM, *media)
        if "*" in media.link:
            paramsIn = dict(parse_qsl(media.link.split("*")[1]))
            ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters=paramsIn, media=media)                
        else:
            if " (S" in media.title:
                ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters={"action": "playHK", "lien": media.link, "u2p": media.numId, "typM": media.title.split(" ")[-1]}, media=media)
            else:
                ok = addDirectoryUptobox("%s" %(media.title), isFolder=False, parameters={"action": "playHK", "lien": media.link, "u2p": media.numId}, media=media)                
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    if i > -1:
        if i >= (NBMEDIA - 1):
            addDirNext(params)            
    xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True, cacheToDisc=True)

def addDirectoryEpisodes(name, isFolder=True, parameters={}, media="" ):
    ''' Add a list item to the XBMC UI.'''
    li = xbmcgui.ListItem(label=("%s" %(name)))
    li.setInfo('video', {"title": media.title, 'plot': media.overview, 'genre': media.genre, 'playcount': media.vu, "dbid": media.numId + 500000,
        "year": media.year, 'mediatype': media.typeMedia, "rating": media.popu, "episode": media.episode, "season": media.saison})
    
    li.setArt({'icon': media.backdrop,
              "fanart": media.backdrop})
    li.setProperty('IsPlayable', 'true')
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)
 

def addDirectoryUptobox(name, isFolder=True, parameters={}, media="" ):
    ''' Add a list item to the XBMC UI.'''
    li = xbmcgui.ListItem(label=name)
    li.setUniqueIDs({ 'tmdb' : media.numId }, "tmdb")
    li.setInfo('video', {"title": media.title, 'plot': media.overview, 'genre': media.genre, "dbid": media.numId + 500000,
            "year": media.year, 'mediatype': media.typeMedia, "rating": media.popu, "duration": media.duration * 60 })
    
    li.setArt({'icon': media.backdrop,
            'thumb': media.poster,
            'poster': media.poster,
            'fanart': media.backdrop})
    if media.clearlogo :
        li.setArt({'clearlogo': media.clearlogo})
    if media.clearart :
        li.setArt({'clearart': media.clearart})
    li.setProperty('IsPlayable', 'true')    
    url = sys.argv[0] + '?' + urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=isFolder)

def debridLien(link):    
    ApikeyUpto = ADDON.getSetting("keyUpto")
    if ApikeyUpto:
        up = Uptobox(key=ApikeyUpto)
        url, statut = up.linkDownload(link)
        return url, statut
    key = ADDON.getSetting("keyalldebrid")
    if key:
        up = Alldedrid(key=key)
        url, statut = up.linkDownload(link)
        return url, statut
    return "", "pas de key debrid"

def playMediaUptobox(params):
    link =params['lien']
    url, statut = debridLien(link)
    if url:
        result = {"url": url, "title": unquote(url.split("/")[-1])}
        if result and "url" in result.keys():
            listIt = createListItemFromVideo(result)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=listIt)

def addDirNext(params):
    isFolder = True
    li = xbmcgui.ListItem(label="[COLOR red]Page Suivante[/COLOR]")
    li.setInfo('video', {"title": "     ", 'plot': "", 'genre': "", "dbid": 500000, 
            "year": "", 'mediatype': "movies", "rating": 0.0})
    li.setArt({
              'thumb': 'special://home/addons/plugin.video.sendtokodiU2P/resources/png/next.png',
              'icon': ADDON.getAddonInfo('icon'),
              'fanart': ADDON.getAddonInfo('fanart'),
              })
    try:
        params["offset"] = str(int(params["offset"]) + NBMEDIA)
    except: pass
    url = sys.argv[0] + '?' + urlencode(params)
    return xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=isFolder)

def getHistoUpto(bd):
    cnx2 = sqlite3.connect(bd)
    cur2 = cnx2.cursor()
    cur2.execute("SELECT (SELECT f.strFilename FROM files as f WHERE b.idFile=f.idFile) FROM bookmark as b")
    bookmark = [x[0] for x in cur2.fetchall() if "playMediaUptobox" in x[0]]    
    cur2.close()
    cnx2.close()
    mDB = TMDB(KEYTMDB)
    for i, media in enumerate(bookmark):
        params = dict(parse_qsl(media.split("?")[1])) 
        notice(params)
        numId = params["u2p"]
        link = params["lien"]
        if "rep" in params.keys():
            threading.Thread(name="tet", target=mDB.tvshowId, args=(" (S%sE%s)" %(params["saison"], params["episode"]), link, i, numId, media.split("?")[1])).start()
        elif "typM" in params.keys():
            threading.Thread(name="tet", target=mDB.tvshowId, args=(" %s" %(params["typM"]), link, i, numId, media.split("?")[1])).start()
        else:
            threading.Thread(name="tet", target=mDB.movieNumId, args=(link, i, numId,)).start()
    while threading.active_count() > 1:
        time.sleep(0.1)
    medias = mDB.extractListe
    affUptobox("movie", [x[1:]  for x in medias], params)
        
if __name__ == '__main__':
    pass
    