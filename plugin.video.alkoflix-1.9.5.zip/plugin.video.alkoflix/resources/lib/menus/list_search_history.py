import sys
from datetime import timedelta
from urllib.parse import unquote

from caches.main_cache import MainCache
from modules import kodi_utils

ls, build_url, make_listitem = kodi_utils.local_string, kodi_utils.build_url, kodi_utils.make_listitem
remove_str, hist_str = ls(32786), ls(32486)
new_search_str = 'Nouvelle recherche...'
default_icon = kodi_utils.media_path('search.png')
history_icon = kodi_utils.media_path('recent.png')


def _clean_query(query):
	try:
		query = unquote(str(query or '')).strip()
	except:
		query = str(query or '').strip()
	return query


def _copy_common_params(params):
	url_params = {}
	try:
		for key in ('media_filter', 'name'):
			value = params.get(key)
			if value: url_params[key] = value
	except: pass
	return url_params


def add_to_history(query, cache_key):
	try:
		query = _clean_query(query)
		if not query: return
		maincache = MainCache()
		result = maincache.get(cache_key) or []
		if query in result: result.remove(query)
		result.insert(0, query)
		maincache.set(cache_key, result[:50], expiration=timedelta(days=365))
	except: pass


def prompt_and_update(params, mode, cache_key):
	try:
		kodi_utils.close_all_dialog()
	except: pass
	query = _clean_query(kodi_utils.dialog.input('alkoFlix'))
	if not query: return
	add_to_history(query, cache_key)
	url_params = _copy_common_params(params)
	url_params.update({'mode': mode, 'search_title': query})
	return kodi_utils.execute_builtin('Container.Update(%s)' % build_url(url_params))


def show_history(params, mode, cache_key, heading='Recherche de listes', iconImage=None):
	def _builder():
		for query in contents:
			try:
				url_params = _copy_common_params(params)
				url_params.update({'mode': mode, 'search_title': query})
				url = build_url(url_params)
				listitem = make_listitem()
				listitem.setLabel('[B]%s :[/B] %s' % (hist_str, query))
				listitem.setArt({'icon': history_icon, 'poster': history_icon, 'thumb': history_icon, 'fanart': '', 'banner': history_icon})
				listitem.addContextMenuItems([(remove_str, 'RunPlugin(%s)' % build_url({'mode': 'remove_from_history', 'setting_id': cache_key, 'query': query}))])
				yield (url, listitem, True)
			except: pass
	__handle__ = int(sys.argv[1])
	new_params = _copy_common_params(params)
	new_params.update({'mode': mode, 'new_search': 'true'})
	kodi_utils.add_dir(__handle__, new_params, new_search_str, iconImage=default_icon, isFolder=False)
	contents = MainCache().get(cache_key) or []
	if contents: kodi_utils.add_items(__handle__, list(_builder()))
	kodi_utils.set_category(__handle__, heading or params.get('name') or 'Recherche de listes')
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.main')
