# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/source_result_utils.py

import re

try:
	from modules.source_objects import PERSONAL_EXTERNAL_PROVIDERS
except Exception:
	PERSONAL_EXTERNAL_PROVIDERS = ('aiostreams', 'aiostreams_custom', 'custom_1', 'custom_2', 'custom_stremio1', 'custom_stremio2')

PERSONAL_SOURCE_FLAGS = ('aiostreams_direct', 'custom_stremio1_direct', 'custom_stremio2_direct')
DIRECT_SOURCE_FLAGS = PERSONAL_SOURCE_FLAGS + ('usenetstreams_direct',)

QUALITY_RANKS = {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}
FRENCH_MULTI_PATTERN = (
	r'(^|[^a-z0-9])('
	r'fr|fra|fre|frn|french|truefrench|true\.french|true-french|'
	r'vf|vfi|vff|vfq|vf2|vof|vf-fr|vf-fq|vf-i|'
	r'multi'
	r')([^a-z0-9]|$)'
)
VOSTFR_PATTERN = r'(^|[^a-z0-9])(vostfr|vo\.?stfr|subfrench|french\.?sub|fr\.?sub)([^a-z0-9]|$)'

PERSONAL_PROVIDER_ORDER = {
	'aiostreams': 0,
	'aiostreams_custom': 0,
	'custom_1': 1,
	'custom_stremio1': 1,
	'custom_2': 2,
	'custom_stremio2': 2
}

SOURCE_RESULT_DEFAULTS = {
	'provider': '',
	'provider_name': '',
	'debrid': '',
	'cache_provider': '',
	'source': '',
	'scrape_provider': '',
	'quality': 'SD',
	'language': '',
	'extraInfo': '',
	'name': '',
	'URLName': '',
	'name_info': '',
	'size': 0.0,
	'size_label': ''
}

SOURCE_DEBUG_FIELDS = ('provider', 'debrid', 'cache_provider', 'source', 'scrape_provider', 'quality', 'size', 'size_label', 'hash', 'name', 'URLName')

BLANK_DISPLAY_VALUES = ('', 'none', 'null', 'false')

def display_value(value, default='N/A'):
	# Valeur destinée aux logs/debug uniquement : n'altère jamais les champs métier.
	try:
		if value is None: return default
		if isinstance(value, (int, float)):
			return default if value == 0 else str(value)
		value = str(value).strip()
		return default if value.lower() in BLANK_DISPLAY_VALUES else value
	except Exception:
		return default

def source_debug_value(item, key, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		debug_key = '_debug_%s' % key
		if debug_key in item: return display_value(item.get(debug_key), default)
		return display_value(item.get(key), default)
	except Exception:
		return default

def source_debug_file(item, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		return display_value(item.get('_debug_file') or item.get('name') or item.get('URLName') or item.get('name_info'), default)
	except Exception:
		return default

def source_debug_size(item, default='N/A'):
	try:
		if not isinstance(item, dict): return default
		value = display_value(item.get('size_label'), None)
		if value: return value
		value = display_value(item.get('_debug_size'), None)
		if value: return value
		return display_value(item.get('size'), default)
	except Exception:
		return default


CUSTOM_PROVIDER_KEYS = ('custom_1', 'custom_2', 'custom_stremio1', 'custom_stremio2')

def upper_display(value, default='N/A'):
	try:
		value = display_value(value, default)
		return str(value).upper() if value != default else default
	except Exception:
		return default

def selector_custom_source_label(item):
	# Libellé UI court pour les sources personnalisées.
	# Ne modifie pas les champs métier : cache_provider reste disponible pour le tri/cache.
	try:
		if not isinstance(item, dict): return ''
		provider_key = _clean_key(item.get('provider'))
		if item.get('custom_stremio1_direct'): provider_key = 'custom_stremio1'
		elif item.get('custom_stremio2_direct'): provider_key = 'custom_stremio2'
		if provider_key not in CUSTOM_PROVIDER_KEYS: return ''
		label = item.get('provider_name') or item.get('display_name') or ''
		return upper_display(label, '')
	except Exception:
		return ''

def selector_cache_status_label(item, pack=False):
	# Libellé court strictement visuel pour la colonne type/source du sélecteur.
	try:
		cache_provider = str((item or {}).get('cache_provider') or '')
		if 'Unchecked' in cache_provider: status = 'N/A'
		elif 'Uncached' in cache_provider: status = 'UNCACHED'
		else: status = 'CACHED'
		if pack and status == 'CACHED':
			package = upper_display((item or {}).get('package'), '')
			return '%s %s' % (status, package) if package else status
		return status
	except Exception:
		return 'N/A'

def selector_source_type_label(item, source=None, pack=False):
	# Priorité UI : nom custom court > état cache court > source brute.
	try:
		custom_label = selector_custom_source_label(item)
		if custom_label: return custom_label
		if isinstance(item, dict) and 'cache_provider' in item:
			return selector_cache_status_label(item, pack=pack)
		return upper_display(source if source is not None else (item or {}).get('source'), 'N/A')
	except Exception:
		return 'N/A'

def source_progress_line1(item):
	# Libellé court pour les fenêtres de progression : évite les champs vides et les textes cache trop longs.
	try:
		if not isinstance(item, dict): return 'N/A'
		custom_label = selector_custom_source_label(item)
		parts = []
		scrape_provider = item.get('scrape_provider')
		if scrape_provider and scrape_provider != 'external': parts.append(scrape_provider)
		if custom_label: parts.append(custom_label)
		elif item.get('cache_provider'): parts.append(selector_cache_status_label(item, pack=item.get('package') in ('true', 'show', 'season')))
		provider = item.get('provider')
		if provider and provider != 'external' and not custom_label: parts.append(provider)
		parts = [upper_display(p, '') for p in parts if display_value(p, '')]
		return ' | '.join(parts) if parts else 'N/A'
	except Exception:
		return 'N/A'

def _clean_key(value):
	try: return str(value or '').strip().lower()
	except Exception: return ''

def is_personal_result(item):
	try:
		if not isinstance(item, dict): return False
		if item.get('personal_source'): return True
		if any(item.get(flag) for flag in PERSONAL_SOURCE_FLAGS): return True
		for key in ('provider', 'debrid', 'source'):
			if _clean_key(item.get(key)) in PERSONAL_EXTERNAL_PROVIDERS: return True
	except Exception:
		pass
	return False

def is_direct_source_result(item):
	try: return any(item.get(flag) for flag in DIRECT_SOURCE_FLAGS)
	except Exception: return False

def personal_result_order(item):
	try:
		if item.get('aiostreams_direct'): return 0
		if item.get('custom_stremio1_direct'): return 1
		if item.get('custom_stremio2_direct'): return 2
		for key in ('provider', 'debrid', 'source'):
			provider = _clean_key(item.get(key))
			if provider in PERSONAL_PROVIDER_ORDER: return PERSONAL_PROVIDER_ORDER[provider]
	except Exception:
		pass
	return 99

def sort_personal_results(results):
	try: return sorted(results, key=personal_result_order)
	except Exception: return results

def get_provider_rank(item, provider_sort_ranks=None, default=11):
	try:
		provider = item.get('scrape_provider') or item.get('provider') or ''
		debrid = item.get('debrid') or ''
		account_type = str(debrid if provider == 'external' else provider).lower()
		return (provider_sort_ranks or {}).get(account_type, default)
	except Exception:
		return default

def get_quality_rank(quality, default=99):
	try: return QUALITY_RANKS.get(str(quality or 'SD'), default)
	except Exception: return default

def set_sort_ranks(results, provider_sort_ranks=None):
	try:
		for item in results or []:
			item['provider_rank'] = get_provider_rank(item, provider_sort_ranks)
			item['quality_rank'] = get_quality_rank(item.get('quality', 'SD'))
	except Exception:
		pass
	return results

def release_text(item):
	try: return ' '.join(str(item.get(k) or '') for k in ('name_info', 'name', 'URLName', 'extraInfo')).lower()
	except Exception: return ''

def is_french_multi_result(item):
	try:
		if str(item.get('language') or '').lower() == 'fr': return True
		return bool(re.search(FRENCH_MULTI_PATTERN, release_text(item), re.I))
	except Exception:
		return False

def is_vostfr_result(item):
	try: return bool(re.search(VOSTFR_PATTERN, release_text(item), re.I))
	except Exception: return False

def sort_french_streaming_priority(results):
	# Tri stable : FR/MULTI en premier, VOSTFR ensuite, puis le reste.
	try:
		french_multi = [i for i in results if is_french_multi_result(i)]
		vostfr = [i for i in results if i not in french_multi and is_vostfr_result(i)]
		others = [i for i in results if i not in french_multi and i not in vostfr]
		return french_multi + vostfr + others
	except Exception:
		return results

def sort_uncached_torrents(results, display_uncached=False, filterless_search=False):
	try:
		results.sort(key=lambda k: 'Unchecked' in k.get('cache_provider', ''), reverse=False)
		if display_uncached or filterless_search:
			results.sort(key=lambda k: 'Uncached' in k.get('cache_provider', ''), reverse=False)
			return results
		return [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
	except Exception:
		return results

def source_passes_result_filters(item, quality_filter, include_3d=True, size_filter=0, include_unknown_size=True, max_size=None):
	try:
		if item.get('bypass_filter'): return True
		if item.get('quality') not in quality_filter: return False
		if not include_3d and '3D' in item.get('extraInfo', ''): return False
		if not size_filter: return True
		if item.get('scrape_provider', '').startswith('folder'): return True
		size = item.get('size', 0)
		try: size = float(size or 0)
		except Exception: size = 0
		if include_unknown_size: return size <= max_size
		return 0.01 < size <= max_size
	except Exception:
		return False

def apply_source_special_filter(results, key, enable_setting, autoplay=False, hybrid_allowed=False, hdr_key='[B]HDR[/B]', uncached_label='Uncached'):
	try:
		if enable_setting == 1:
			if 'D/VISION' in key and hybrid_allowed:
				return [
					i for i in results
					if i.get('bypass_filter') or all(x in i.get('extraInfo', '') for x in (key, hdr_key)) or key not in i.get('extraInfo', '')
				]
			return [i for i in results if i.get('bypass_filter') or key not in i.get('extraInfo', '')]
		if enable_setting == 2 and autoplay:
			priority_list = [i for i in results if not i.get('bypass_filter') and key in i.get('extraInfo', '')]
			remainder_list = [i for i in results if i not in priority_list]
			return priority_list + remainder_list
		if enable_setting == 3:
			priority_key = lambda k: not k.get('bypass_filter') and key in k.get('extraInfo', '') and uncached_label not in k.get('cache_provider', '')
			results.sort(key=priority_key, reverse=True)
			return results
	except Exception:
		pass
	return results

def normalize_source_result(item):
	# Normalisation défensive et légère : ne modifie pas les valeurs métier existantes,
	# mais garantit les champs de base consommés par le tri, les filtres, le debug et les fenêtres.
	if not isinstance(item, dict): return None
	try:
		result = dict(item)
		original_result = dict(result)
	except Exception: return None
	for key, value in SOURCE_RESULT_DEFAULTS.items():
		if result.get(key) is None: result[key] = value
		elif key not in result: result[key] = value
	try:
		if not result.get('scrape_provider'):
			result['scrape_provider'] = result.get('provider') or result.get('source') or ''
	except Exception:
		pass
	try:
		if not isinstance(result.get('size'), (int, float)):
			result['size'] = float(result.get('size') or 0)
	except Exception:
		result['size'] = 0.0
	try:
		if not result.get('name') and result.get('URLName'):
			result['name'] = result.get('URLName')
		if not result.get('URLName') and result.get('name'):
			result['URLName'] = result.get('name')
	except Exception:
		pass
	try:
		# Champs de debug prêts à afficher : les valeurs vides deviennent N/A sans toucher aux valeurs métier.
		# Ils se basent sur le résultat original pour éviter qu'une valeur interne par défaut
		# comme quality=SD ne donne une fausse impression dans le diagnostic.
		for key in SOURCE_DEBUG_FIELDS:
			result['_debug_%s' % key] = display_value(original_result.get(key))
		result['_debug_file'] = source_debug_file(result)
		result['_debug_size'] = source_debug_size(result)
	except Exception:
		pass
	return result

def normalize_source_results(results):
	normalized = []
	for item in results or []:
		item = normalize_source_result(item)
		if item is not None: normalized.append(item)
	return normalized
