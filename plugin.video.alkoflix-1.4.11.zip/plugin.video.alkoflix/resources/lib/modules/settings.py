# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/modules/settings.py

from modules import kodi_utils
# from modules.kodi_utils import logger

ls, translate_path, get_setting, set_setting = kodi_utils.local_string, kodi_utils.translate_path, kodi_utils.get_setting, kodi_utils.set_setting

# Raccourcis utilisés partout dans ce module pour éviter de répéter kodi_utils.

# ---------------------------------------------------------------------------
# Apparence et chemins de base
# ---------------------------------------------------------------------------

def addon_fanart(fallback='alkoflix_fanart.jpg'):
	fanart = get_setting('fanart_image', fallback)
	# Compatibilité : les profils WIP peuvent contenir le nom PNG transparent.
	# Dans ce cas, on retourne toujours le fanart officiel déclaré dans addon.xml,
	# de nouveau basé sur l'image JPG alkoFlix.
	if fanart in ('alkoflix_fanart.jpg', 'alkoflix_fanart.png'): return kodi_utils.get_addoninfo('fanart')
	return translate_path(fanart)

# ---------------------------------------------------------------------------
# Lecture automatique, reprise et épisode suivant
# ---------------------------------------------------------------------------

def auto_resume(media_type):
	auto_resume = get_setting('auto_resume_%s' % media_type)
	if auto_resume == '1': return True
	if auto_resume == '2' and auto_play(media_type): return True
	else: return False

def auto_play(media_type):
	return get_setting('auto_play_%s' % media_type) == 'true'

def media_click_action():
	# false/0 = afficher les liens, true/1 = ouvrir la fenêtre d'information.
	value = get_setting('media.click_action', 'false')
	if value in ('true', '1'): return 1
	return 0


def media_click_opens_info():
	return media_click_action() == 1


def use_upnext_episode():
	# Un seul réglage visible contrôle maintenant Up Next pour les deux modes.
	return get_setting('autoplay_next_episode', 'true') == 'true'

def autoplay_next_episode():
	# Mode lecture automatique : Up Next enchaîne directement l’épisode suivant.
	return auto_play('episode') and use_upnext_episode()

def autoplay_next_check_threshold():
	return int(get_setting('autoplay_next_check_threshold', '3'))

def autoplay_next_show_window():
	# Le plugin Up Next gère maintenant l'affichage de la fenêtre.
	# Les anciens réglages masqués ne doivent plus empêcher son déclenchement.
	return True

def autoplay_next_window_time():
	return int(get_setting('autoplay_next_window_time', '40'))

def autoplay_next_window_percentage():
	# Conservé pour compatibilité avec l'ancien retour de configuration.
	return int(get_setting('autoplay_next_window_percentage', '95'))

def autoplay_next_window_timer_method():
	# Mode fixe : temps restant. Le mode pourcentage est volontairement ignoré.
	return 'time'

def autoplay_next_settings():
	# Regroupe les réglages nécessaires à l'enchaînement automatique des épisodes.
	scraper_time = int(get_setting('scrapers.timeout.1', '60')) + 20
	threshold = autoplay_next_check_threshold()
	run_popup = autoplay_next_show_window()
	timer_method = autoplay_next_window_timer_method()
	window_time = autoplay_next_window_time() + 1
	window_percentage = 100 - autoplay_next_window_percentage()
	autoscrape_time = int(get_setting('autoscrape_next_window_time', '20'))
	return {
		'scraper_time': scraper_time, 'threshold': threshold, 'run_popup': run_popup,
		'timer_method': timer_method, 'window_time': window_time, 'window_percentage': window_percentage,
		'autoscrape_next_window_time': autoscrape_time
	}


# ---------------------------------------------------------------------------
# Calendrier, menus contextuels et affichage général
# ---------------------------------------------------------------------------

def autoscrape_next_episode():
	# Mode sélection de source : le même réglage Up Next ouvre le choix des liens.
	return not auto_play('episode') and use_upnext_episode()

def calendar_focus_today():
	return get_setting('trakt.calendar_focus_today') == 'true'

def calendar_sort_order():
	return int(get_setting('trakt.calendar_sort_order', '0'))

def context_menu_sort():
	# Ordre automatique du menu contextuel natif.
	# Les anciens réglages context.* ne sont plus lus : les entrées visibles
	# sont déterminées par les services réellement autorisés.
	return {
		'options': 10,
		'extras': 20,
		'mark': 30,
		'trakt': 40,
		'mdblist': 50,
		'tmdblist': 60,
		'rating': 70,
		'favourites': 21,
		'exit': 100
	}


def service_active(service):
	# État d'autorisation des services utilisés dans les menus contextuels.
	if service == 'trakt': return bool(get_setting('trakt_user', ''))
	if service == 'mdblist': return bool(get_setting('mdblist.token', '') or get_setting('mdblist_user', ''))
	if service in ('tmdb', 'tmdblist'): return bool(get_setting('tmdb.token', ''))
	return False


def context_menu_services():
	return {
		'trakt': service_active('trakt'),
		'mdblist': service_active('mdblist'),
		'tmdblist': service_active('tmdb')
	}


def context_rating_enabled(media_type='movie'):
	provider = max(0, min(ratings_provider(), 2))
	# TMDb ne permet pas de noter une saison individuellement.
	if media_type == 'season' and provider == 2: return False
	return (service_active('trakt'), service_active('mdblist'), service_active('tmdb'))[provider]


def context_favourites_enabled():
	# Les favoris alkoFlix sont toujours locaux.
	# Le fournisseur sélectionné sert uniquement de sauvegarde externe films/séries.
	return True

def date_offset():
	return int(get_setting('datetime.offset', '0')) + 5

def default_all_episodes():
	return int(get_setting('default_all_episodes'))

def display_sleep_time():
	return 100

def display_uncached_torrents():
	return get_setting('torrent.display.uncached', 'false') == 'true'

# ---------------------------------------------------------------------------
# Répertoires et services externes
# ---------------------------------------------------------------------------

def download_directory(media_type):
	if media_type == 'movie': setting = 'movie_download_directory'
	elif media_type == 'episode': setting = 'tvshow_download_directory'
	elif media_type in ('thumb_url', 'image_url', 'image'): setting = 'image_download_directory'
	else: setting = 'premium_download_directory'
	if get_setting(setting) != '': return translate_path(get_setting(setting))
	else: return False

def easynews_active():
	# EasyNews n'est plus proposé par alkoFlix.
	return False

def easynews_language_filter():
	# Retourne l'état du filtre de langue Easynews et la liste des langues ciblées.
	enabled = get_setting('easynews.filter_lang') == 'true'
	filters = get_setting('easynews.lang_filters').split(', ') if enabled else []
	return enabled, filters

def enabled_debrids_check(debrid_service):
	# Un service de débridage est considéré actif seulement s'il est activé et authentifié.
	enabled = get_setting('%s.enabled' % debrid_service) == 'true'
	if not enabled: return False
	authed = get_setting('%s.token' % debrid_service)
	if authed in ('', None): return False
	return True


# ---------------------------------------------------------------------------
# Réglages des extras
# ---------------------------------------------------------------------------

def extras_enable_scrollbars():
	return get_setting('extras.enable_scrollbars', 'true')

def extras_exclude_non_acting():
	return get_setting('extras.exclude_non_acting_roles', 'true') == 'true'

def extras_enabled_menus():
	# La fenêtre Info & Extra moderne doit rester utile même si l'ancien réglage
	# extras.enabled_menus n'existe pas dans le profil utilisateur.
	# Par défaut, on affiche les deux sections visibles de cette fenêtre :
	# Distribution (2050) et recommandations (2051).
	setting = get_setting('extras.enabled_menus')
	if setting in ('', None, 'noop', []): setting = '2050,2051'
	return [int(i) for i in setting.split(',') if str(i).strip()]

def extras_open_action(media_type):
	# Ancien réglage neutralisé : les Extras passent maintenant par la fenêtre d'information native du skin.
	return False


def info_extra_window():
	# false/0 = fenêtre d'information du skin, true/1 = fenêtre d'information alkoFlix.
	value = get_setting('info_extra.window', 'true')
	if value in ('true', '1'): return 1
	return 0


def use_alkoflix_info_window():
	return info_extra_window() == 1


# ---------------------------------------------------------------------------
# Métadonnées, images et filtres
# ---------------------------------------------------------------------------

def fanarttv_client_key():
	default_key = get_setting('fanart_client_key', '30006d06f4d124007f5de4f568bd7bca')
	if get_setting('fanarttv.use_own_key') == 'true':
		return get_setting('fanart_client_key_user') or default_key
	return default_key

def filter_by_name(scraper):
	return get_setting('%s.title_filter' % scraper, 'false') == 'true'

def filter_status(filter_type):
	return int(get_setting('filter_%s' % filter_type, '0'))

def get_art_provider():
	# Détermine l'ordre de priorité entre TMDb et Fanart.tv selon les réglages.
	if not get_fanart_data(): return ('poster', 'poster2', 'fanart', 'fanart2')
	return {
		True: ('poster2', 'poster', 'fanart2', 'fanart'),
		False: ('poster', 'poster2', 'fanart', 'fanart2')
	}[get_setting('fanarttv.default') == 'true']

# Retourne True si Fanart.tv est activé et défini comme fournisseur principal.
def fanarttv_default():
	return get_fanart_data() and get_setting('fanarttv.default') == 'true'

# Résout le poster final selon la logique choisie par l'utilisateur.
# Si Fanart.tv est prioritaire, on tente d'abord ses visuels textuels,
# puis TMDb textuel, avant de retomber sur les variantes sans texte.
def resolve_poster_art(meta, fallback=''):
	if fanarttv_default():
		return meta.get('poster2_text') or meta.get('poster_text') or meta.get('poster2') or meta.get('poster') or fallback
	return meta.get('poster') or meta.get('poster2') or fallback

# Résout l'image landscape finale selon la même logique.
def resolve_landscape_art(meta, fallback=''):
	if fanarttv_default():
		return meta.get('landscape_text') or meta.get('landscape_tmdb_text') or meta.get('landscape') or meta.get('landscape_tmdb') or fallback
	return meta.get('landscape_tmdb') or meta.get('landscape') or fallback

def get_fanart_data():
	return get_setting('get_fanart_data') == 'true'

def get_language():
	# Langue des métadonnées TMDb. alkoFlix expose uniquement français et anglais.
	# Les anciennes installations peuvent encore contenir "fr", "fr-CA" ou une autre langue.
	# Tout ce qui n'est pas anglais est ramené sécuritairement vers fr-FR.
	language = get_setting('meta_language', 'fr-FR') or 'fr-FR'
	normalized = {
		'fr': 'fr-FR', 'fr-CA': 'fr-FR', 'fr_CA': 'fr-FR', 'fr-ca': 'fr-FR',
		'en-US': 'en', 'en_GB': 'en', 'en-GB': 'en'
	}.get(language, language)
	if normalized not in ('fr-FR', 'en'):
		normalized = 'fr-FR'
	if normalized != language:
		set_setting('meta_language', normalized)
		set_setting('meta_language_display', 'Anglais' if normalized == 'en' else 'Français')
	return normalized

def get_image_language():
	# Langue prioritaire des images TMDb. Seuls français et anglais sont exposés
	# dans les réglages afin de garder un comportement simple et prévisible.
	language = (get_setting('image_language', 'fr') or 'fr').lower()
	if language not in ('fr', 'en'):
		language = 'fr'
		set_setting('image_language', language)
		set_setting('image_language_display', 'Français')
	return language

def image_language_query():
	# TMDb retourne uniquement les langues demandées avec include_image_language.
	# Ordre voulu : langue choisie, fallback anglais/français, puis neutre.
	primary = get_image_language()
	fallback = 'en' if primary == 'fr' else 'fr'
	return '%s,%s,null' % (primary, fallback)

def certification_country():
	# Pays utilisé pour récupérer les classifications d'âge TMDb (MPAA, CSA, BBFC, etc.).
	# Accepte les anciens index numériques ET les codes pays directs (FR, CA, US...).
	countries = ('US', 'CA', 'FR', 'GB', 'DE', 'ES', 'IT', 'AU', 'BR')
	labels = (33203, 33204, 33205, 33206, 33207, 33208, 33209, 33210, 33211)
	value = (get_setting('certification.country', 'FR') or 'FR').strip()
	if value.upper() in countries:
		index = countries.index(value.upper())
	else:
		try: index = int(value)
		except: index = 2
		if index < 0 or index >= len(countries): index = 2
	try:
		display = ls(labels[index])
		if get_setting('certification.country_display', '') != display:
			set_setting('certification.country_display', display)
		if get_setting('parental.certification_country_display', '') != display:
			set_setting('parental.certification_country_display', display)
	except: pass
	return countries[index]

def get_resolution():
	return (
		{'poster': 'w185', 'fanart': 'w300', 'still': 'w185', 'profile': 'w185'},
		{'poster': 'w342', 'fanart': 'w780', 'still': 'w300', 'profile': 'w342'},
		{'poster': 'w780', 'fanart': 'w1280', 'still': 'original', 'profile': 'h632'},
		{'poster': 'original', 'fanart': 'original', 'still': 'original', 'profile': 'original'}
	)[int(get_setting('image_resolutions', '2'))]

def get_rpdb_data():
	return get_setting('get_rpdb_movies') == 'true', get_setting('get_rpdb_series') == 'true'

def ignore_articles():
	return get_setting('ignore_articles', 'true') == 'true'

def ignore_results_filter():
	return get_setting('ignore_results_filter') == 'true'

def include_prerelease_3d_results():
	return get_setting('include_prerelease_results') == 'true', get_setting('include_3d_results') == 'true'

def include_year_in_title(media_type):
	settings_dict = {'movie': (1, 3), 'tvshow': (2, 3)}
	setting = int(get_setting('include_year_in_title', '0'))
	return setting in settings_dict[media_type]

def lists_sort_order(setting):
	defaults = {'progress': '1', 'watched': '1', 'collection': '0', 'watchlist': '1', 'favorites': '2'}
	try: selected = int(get_setting('sort.%s' % setting, defaults.get(setting, '0')))
	except: selected = int(defaults.get(setting, '0'))
	if setting == 'favorites':
		# UI favoris : 0 = Titre, 1 = Date de sortie, 2 = Date d'ajout.
		# Les fonctions de tri existantes attendent : 0 = Titre, 1 = Date d'ajout, 2 = Date de sortie.
		return {0: 0, 1: 2, 2: 1}.get(selected, 1)
	return selected

def lists_sort_reverse(setting):
	if setting == 'collection':
		# Nouvelle option UI : 0 = Ascendant, 1 = Descendant.
		# Si le réglage n'existe pas encore dans le profil Kodi, on conserve
		# l'ancien comportement : titre A-Z, dates en ordre décroissant.
		raw_value = get_setting('sort.collection.order', '')
		if raw_value == '':
			return get_setting('sort.collection', '0') != '0'
		try: return int(raw_value) == 1
		except: return False
	default_value = '1' if setting in ('favorites', 'watchlist') else '0'
	try:
		value = int(get_setting('sort.%s.order' % setting, default_value))
	except:
		value = int(default_value)
	if setting in ('favorites', 'watchlist'):
		# UI favoris/watchlist : 0 = Ascendant, 1 = Descendant.
		return value == 1
	# Anciens tris : 0 = décroissant, 1 = croissant.
	return value == 0

def metadata_user_info():
	# Prépare le bloc de configuration transmis aux modules de métadonnées.
	tmdb_api = tmdb_api_key()
	image_resolution = get_resolution()
	meta_language = get_language()
	image_language = get_image_language()
	hide_watched = widget_hide_watched()
	fanart_client_key = fanarttv_client_key()
	if fanart_client_key: extra_fanart_enabled = get_fanart_data()
	else: extra_fanart_enabled = False
	rpdb_api = rpdb_api_key()
	if rpdb_api: extra_rpdb_movies, extra_rpdb_series = get_rpdb_data()
	else: extra_rpdb_movies, extra_rpdb_series = False, False
	return {
		'image_resolution': image_resolution , 'language': meta_language, 'image_language': image_language, 'widget_hide_watched': hide_watched,
		'tmdb_api': tmdb_api, 'fanart_client_key': fanart_client_key, 'extra_fanart_enabled': extra_fanart_enabled,
		'certification_country': certification_country(),
		'rpdb_api_key': rpdb_api, 'extra_rpdb_movies': extra_rpdb_movies, 'extra_rpdb_series': extra_rpdb_series
	}

def movies_directory():
	return translate_path(get_setting('movies_directory'))

def nav_jump_use_alphabet():
	# Réglage retiré : l'accès direct à une page se fait maintenant depuis le menu contextuel de "Page suivante".
	# On retourne toujours 0 pour ignorer sans risque les anciennes valeurs stockées dans les profils existants.
	return 0


# ---------------------------------------------------------------------------
# Réglages Next Episode / widgets
# ---------------------------------------------------------------------------

def nextep_content_settings():
	include_unaired = get_setting('nextep.include_unaired') == 'true'
	include_unwatched = False # Ancien réglage désactivé volontairement : get_setting('nextep.include_unwatched') == 'true'
	sort_type = int(get_setting('nextep.sort_type'))
	sort_order = int(get_setting('nextep.sort_order'))
	sort_direction = sort_order == 0
	sort_key = 'alkoflix_last_played' if sort_type == 0 else 'alkoflix_first_aired' if sort_type == 1 else 'alkoflix_name'
	sort_airing_today_to_top = get_setting('nextep.sort_airing_today_to_top', 'false') == 'true'
	return {
		'include_unaired': include_unaired, 'include_unwatched': include_unwatched,
		'sort_type': sort_type, 'sort_order': sort_order, 'sort_direction': sort_direction, 'sort_key': sort_key,
		'sort_airing_today_to_top': sort_airing_today_to_top
	}

def nextep_display_settings():
	include_airdate = get_setting('nextep.include_airdate') == 'true'
	return {'unaired_color': 'cyan', 'unwatched_color': 'darkgoldenrod', 'include_airdate': include_airdate}

def paginate():
	return get_setting('paginate.lists', 'true') == 'true'

def page_limit():
	return int(get_setting('page_limit', '20'))


# ---------------------------------------------------------------------------
# Tri et affichage des résultats
# ---------------------------------------------------------------------------

def quality_filter(setting):
	return get_setting(setting).split(', ')

def results_sort_order():
	# Les choix de tri commencent à 1. Les anciennes valeurs 0 sont migrées
	# vers le premier tri disponible pour éviter un affichage non trié invisible.
	try:
		sort_order = int(get_setting('results.sort_order', '1'))
	except:
		sort_order = 1
	if sort_order < 1 or sort_order > 6:
		sort_order = 1
		set_setting('results.sort_order', '1')

	direction = 1 if get_setting('results.sort_size') == '1' else -1
	return (
		lambda k: (k['quality_rank'], k['provider_rank'], direction*k['size']), # 1 - Qualité, fournisseur, taille
		lambda k: (k['quality_rank'], direction*k['size'], k['provider_rank']), # 2 - Qualité, taille, fournisseur
		lambda k: (k['provider_rank'], k['quality_rank'], direction*k['size']), # 3 - Fournisseur, qualité, taille
		lambda k: (k['provider_rank'], direction*k['size'], k['quality_rank']), # 4 - Fournisseur, taille, qualité
		lambda k: (direction*k['size'], k['quality_rank'], k['provider_rank']), # 5 - Taille, qualité, fournisseur
		lambda k: (direction*k['size'], k['provider_rank'], k['quality_rank'])  # 6 - Taille, fournisseur, qualité
	)[sort_order - 1]

RESULTS_XML_STYLE_MAP = {
	'list default': ('List Default', 'Liste'),
	'list contrast default': ('List Default', 'Liste'),
	'liste': ('List Default', 'Liste'),
	'liste par défaut': ('List Default', 'Liste'),
	'infolist default': ('InfoList Default', 'InfoListe'),
	'infolist contrast default': ('InfoList Default', 'InfoListe'),
	'infoliste': ('InfoList Default', 'InfoListe'),
	'infoliste par défaut': ('InfoList Default', 'InfoListe'),
	'widelist default': ('WideList Default', 'Liste large'),
	'widelist contrast default': ('WideList Default', 'Liste large'),
	'liste large': ('WideList Default', 'Liste large'),
	'liste large par défaut': ('WideList Default', 'Liste large')
}


def _results_xml_style_pair(value=None):
	style = str(value if value not in (None, '') else get_setting('results.xml_style', 'Liste large')).strip()
	return RESULTS_XML_STYLE_MAP.get(style.lower(), ('WideList Default', 'Liste large'))


def normalize_results_xml_style_display():
	current = get_setting('results.xml_style', 'Liste large')
	display = _results_xml_style_pair(current)[1]
	if current != display:
		set_setting('results.xml_style', display)
	return display


def results_xml_style():
	return _results_xml_style_pair()[0].lower()

def results_xml_window_number(window_style=None):
	if not window_style: window_style = results_xml_style()
	return {'list': 2000, 'infolist': 2001, 'widelist': 2002}[window_style.split(' ')[0]]

def favourites_import_source():
	# Ancienne compatibilité : le sélecteur a été retiré de l'interface.
	# Les actions dédiées transmettent maintenant directement le fournisseur voulu.
	try: selected = int(get_setting('favourites.import_service', '0'))
	except: selected = 0
	return {0: 4, 1: 1, 2: 3}.get(selected, 4)

def favourites_sync_source():
	# La synchronisation des favoris alkoFlix passe uniquement par alkoPastes.
	return 4

def root_favourites_source():
	# Les ajouts/retraits mettent à jour uniquement le backup alkoPastes.
	return 4

def ratings_provider():
	# 0 = Trakt, 1 = MDBList, 2 = TMDb.
	try: return int(get_setting('ratings.provider', '0'))
	except: return 0

def rpdb_api_key():
	return get_setting('rpdb_api_key')


# ---------------------------------------------------------------------------
# Stockage cloud, dossiers et indicateurs de lecture
# ---------------------------------------------------------------------------

def store_resolved_torrent_to_cloud(debrid_service):
	return get_setting('store_torrent.%s' % debrid_service.lower()) == 'true'

def store_resolved_usenet_to_cloud(debrid_service):
	return get_setting('store_usenet.%s' % debrid_service.lower()) == 'true'

def show_specials():
	return get_setting('show_specials') == 'true'

def show_unaired():
	return get_setting('show_unaired') == 'true'

def show_unaired_watchlist():
	return get_setting('show_unaired_watchlist', 'false') == 'true'

def single_ep_display_title():
	return int(get_setting('single_ep_display', '0'))

def single_ep_format():
	return {0: '%d-%m-%Y', 1: '%Y-%m-%d', 2: '%m-%d-%Y'}[int(get_setting('single_ep_format', '0'))]

def source_folders_directory(media_type, source):
	# Les dossiers locaux comme sources ne sont plus pris en charge par alkoFlix.
	# Retourne toujours False afin d'ignorer les anciens réglages conservés dans le profil Kodi.
	return False

def sync_kodi_library_watchstatus():
	return get_setting('sync_kodi_library_watchstatus') == 'true'

def thumb_fanart():
	return get_setting('thumb_fanart') == 'true'

def tmdb_api_key():
	default_key = get_setting('tmdb_api', '14e469d80e2ff91a051f769dbd936757')
	if get_setting('tmdb.use_own_key') == 'true':
		return get_setting('tmdb_api_user') or default_key
	return default_key

def trakt_sync_interval():
	setting = get_setting('trakt.sync_interval', '25')
	interval = int(setting) * 60
	return setting, interval

def trakt_sync_refresh_widgets():
	return get_setting('trakt.sync_refresh_widgets') == 'true'

def trakt_token():
	return get_setting('trakt.token')

def tv_show_directory():
	return translate_path(get_setting('tv_shows_directory'))

def use_season_title():
	return get_setting('use_season_title') == 'true'

def watched_indicators():
	if get_setting('trakt_user') == '' and get_setting('mdblist_user') == '': return 0
	return int(get_setting('watched_indicators', '0'))

def widget_hide_watched():
	return get_setting('widget_hide_watched') == 'true'


# ---------------------------------------------------------------------------
# Scrapers internes et services de débridage
# ---------------------------------------------------------------------------

default_internal_scrapers, cloud_scrapers = (
	'ad_cloud', 'rd_cloud', 'tb_cloud'
), ('ad_cloud', 'rd_cloud', 'tb_cloud')

def active_internal_scrapers():
	# Le système de sources alkoFlix est maintenant toujours disponible.
	# Sécurité : si un ancien profil avait désactivé provider.external, on le remet à true
	# sans dépendre d'une option visible dans les réglages.
	try:
		if get_setting('provider.external') != 'true': set_setting('provider.external', 'true')
	except: pass
	active = ['external']
	settings = [item[1] for item in (
		('ad', 'provider.ad_cloud'),
		('rd', 'provider.rd_cloud'),
		('tb', 'provider.tb_cloud')
	) if enabled_debrids_check(item[0])]
	active.extend(i.split('.')[1] for i in settings if get_setting(i) == 'true')
	return active

def check_prescrape_sources(scraper, media_type):
	# Indique si une source doit être vérifiée avant le scrape principal.
	if scraper in default_internal_scrapers: return get_setting('check.%s' % scraper) == 'true'
	if get_setting('check.%s' % scraper) == 'true' and get_setting('auto_play_%s' % media_type) != 'true': return True
	else: return False

def provider_sort_ranks():
	# Plus le rang est bas, plus le fournisseur remonte dans les résultats triés.
	ad_priority = int(get_setting('ad.priority', '9'))
	tb_priority = int(get_setting('tb.priority', '9'))
	rd_priority = int(get_setting('rd.priority', '10'))
	return {
		'alldebrid': ad_priority, 'ad_cloud': ad_priority,
		'real-debrid': rd_priority, 'rd_cloud': rd_priority,
		'torbox': tb_priority, 'tb_cloud': tb_priority,
		'folders': 0
	}

def sort_to_top(provider):
	return get_setting({
		'ad_cloud': 'results.sort_adcloud_first',
		'rd_cloud': 'results.sort_rdcloud_first',
		'tb_cloud': 'results.sort_tbcloud_first',
		'folders': 'results.sort_folders_first'
	}[provider]) == 'true'


# ---------------------------------------------------------------------------
# Couleurs et icônes des résultats
# ---------------------------------------------------------------------------

def scraping_settings():
	def provider_color(provider, fallback):
		# Récupère la couleur personnalisée d'un fournisseur, avec une valeur de secours.
		return get_setting('provider.%s_colour' % provider, fallback)
	highlight_type = int(get_setting('highlight.type', '0'))
	hoster_highlight, torrent_highlight = '', ''
	easynews_highlight, debrid_cloud_highlight, folders_highlight = '', '', ''
	ad_highlight, rd_highlight, tb_highlight = '', '', ''
	aiostreams_highlight = ''
	custom_1_highlight, custom_2_highlight = '', ''
	highlight_4K, highlight_1080P, highlight_720P, highlight_SD = '', '', '', ''
	if highlight_type in (0, 1):
		# Modes 0 et 1 : coloration par type de source ou par fournisseur.
		if highlight_type == 0:
			hoster_highlight = get_setting('hoster.identify', 'dodgerblue')
			torrent_highlight = get_setting('torrent.identify', 'fuchsia')
		else:
			ad_highlight = provider_color('ad', 'goldenrod')
			rd_highlight = provider_color('rd', 'seagreen')
			tb_highlight = provider_color('tb', 'darkseagreen')
			aiostreams_highlight = provider_color('aiostreams', 'magenta')
			custom_1_highlight = provider_color('custom_1', 'mediumorchid')
			custom_2_highlight = provider_color('custom_2', 'fuchsia')
		easynews_highlight = provider_color('easynews', 'limegreen')
		debrid_cloud_highlight = provider_color('debrid_cloud', 'darkviolet')
		folders_highlight = provider_color('folders', 'darkgoldenrod')
	else:
		# Autre mode : coloration selon la qualité vidéo détectée.
		highlight_4K = get_setting('scraper_4k_highlight', 'fuchsia')
		highlight_1080P = get_setting('scraper_1080p_highlight', 'lawngreen')
		highlight_720P = get_setting('scraper_720p_highlight', 'gold')
		highlight_SD = get_setting('scraper_SD_highlight', 'lightsaltegray')
	return {
		'alldebrid': ad_highlight, 'ad_cloud': debrid_cloud_highlight,
		'real-debrid': rd_highlight, 'rd_cloud': debrid_cloud_highlight,
		'torbox': tb_highlight, 'tb_cloud': debrid_cloud_highlight,
		'aiostreams': aiostreams_highlight, 'aiostreams_custom': aiostreams_highlight,
		'custom_1': custom_1_highlight, 'custom_2': custom_2_highlight,
		'custom_stremio1': custom_1_highlight, 'custom_stremio2': custom_2_highlight,
		'uncached': 'dimgray', 'highlight_type': highlight_type, 'folders': folders_highlight,
		'hoster_highlight': hoster_highlight, 'torrent_highlight': torrent_highlight,
		'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P,
		'sd': highlight_SD, 'cam': highlight_SD, 'tele': highlight_SD, 'scr': highlight_SD,
	}

def info_icons():
	# Associe chaque type de source ou de qualité à son icône d'affichage.
	return (
		('alldebrid', 'alldebrid.png'), ('ad_cloud', 'alldebrid.png'),
		('real-debrid', 'realdebrid.png'), ('rd_cloud', 'realdebrid.png'),
		('torbox', 'torbox.png'), ('tb_cloud', 'torbox.png'),
		('folders', 'myfolder.png'),
		('4k', 'flag4k.png'), ('1080p', 'flag1080p.png'), ('720p', 'flag720p.png'),
		('sd', 'flagSD.png'), ('cam', 'flagSD.png'), ('tele', 'flagSD.png'), ('scr', 'flagSD.png')
	)
