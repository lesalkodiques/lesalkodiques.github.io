# -*- coding: utf-8 -*-
# plugin.video.alkoflix
# resources/lib/menus/tvshows.py

import sys
from threading import Thread
from indexers.trakt_api import trakt_get_hidden_items
from indexers.metadata import tvshow_meta, rpdb_get
from caches.watched_cache import get_watched_info_tv, get_watched_status_tvshow
from caches.favourites_cache import favourites_context_label, favourite_type_from_context
from modules import kodi_utils, settings, user_ratings, parental_control
#from modules.utils import manual_function_import, get_datetime, make_thread_list_enumerate
from modules.utils import manual_function_import, get_datetime, TaskPool, chunks
# logger = kodi_utils.logger

# Alias locaux pour éviter les accès répétés aux modules pendant la construction des listes.
tv_meta_function, get_datetime_function = tvshow_meta, get_datetime
get_watched_function, get_watched_info_function = get_watched_status_tvshow, get_watched_info_tv
KODI_VERSION, make_cast_list = kodi_utils.get_kodi_version(), kodi_utils.make_cast_list
string, ls, build_url, get_infolabel = str, kodi_utils.local_string, kodi_utils.build_url, kodi_utils.get_infolabel
remove_meta_keys, dict_removals = kodi_utils.remove_meta_keys, kodi_utils.tvshow_dict_removals
run_plugin, container_refresh, container_update = 'RunPlugin(%s)', 'Container.Refresh(%s)', 'Container.Update(%s)'
fanart_empty = kodi_utils.get_addoninfo('fanart')
poster_empty = kodi_utils.media_path('box_office.png')
item_jump = kodi_utils.media_path('item_jump.png')
item_next = kodi_utils.media_path('item_next.png')
watched_str, unwatched_str, traktmanager_str, tmdbmanager_str, mdblmanager_str = ls(32642), ls(32643), ls(32198), 'Gestion des listes TMDb', ls(32200)
favmanager_str, extras_str, options_str, recomm_str = 'Favoris (alkoFlix)', 'Info & Extra', 'Options de lecture', '%s...' % ls(32503)
trailer_str = 'Bande annonce'
random_str, browse_str = ls(32611), ls(32652)
nextpage_str, switchjump_str, jumpto_str = ls(32799), ls(32784), ls(32964)

ANIMATION_GENRE_NAMES = ('animation', 'dessin animé', 'dessins animés')

def _meta_has_animation_genre(genre):
	try:
		if isinstance(genre, (list, tuple)): values = genre
		else: values = str(genre or '').split(',')
		return any(str(item or '').strip().lower() in ANIMATION_GENRE_NAMES for item in values)
	except: return False

def _exclude_animation_for_action(action, params):
	if str(params.get('exclude_animation', '')).lower() == 'true': return True
	# Les listes issues du menu Famille / Chaînes jeunesse doivent conserver
	# l'animation. Ces entrées utilisent parfois l'action générique
	# tmdb_tv_networks, donc se fier seulement au préfixe de l'action viderait
	# des réseaux comme Cartoon Network.
	family_type = str(params.get('family_type', '') or '').lower()
	fav_type = str(params.get('fav_type', '') or '').lower()
	if family_type in ('series_family', 'series_family_kids', 'series_animation') or fav_type in ('tv_family', 'tv_animation'):
		return False
	action = str(action or '')
	if not action: return False
	if action.startswith(('tmdb_tvanime_', 'trakt_tvanime_', 'tmdb_tv_family_', 'tmdb_tv_documentary_', 'tmdb_tv_reality_', 'tmdb_tv_talkshow_', 'tmdb_tv_news_')): return False
	if action in ('tmdb_tv_search',): return False
	if action.startswith(('tmdb_tv_', 'trakt_tv_')): return True
	return False


def _favourite_type_for_action(action, params, meta=None):
	# Contexte du menu d'abord, puis fallback genres TMDb pour les widgets de skin.
	return favourite_type_from_context('tvshow', params, action, meta)


# Appelle les endpoints TMDb avec un tri contextuel optionnel, tout en gardant
# les signatures existantes intactes pour les dossiers qui ne supportent pas encore
# ce mode. Le fallback évite de casser un menu entier si une fonction n'a pas été
# prévue pour le tri régional strict.
def _tmdb_context_filter_page(data, context_sort=''):
	if not context_sort: return data
	try:
		from indexers.tmdb_api import _tmdb_filter_context_results, _tmdb_context_sort_results
		data = _tmdb_filter_context_results(data or {}, 'tv', context_sort)
		if isinstance(data, dict):
			data = dict(data)
			data['results'] = _tmdb_context_sort_results(data.get('results', []) or [], context_sort, 'tv')
		return data
	except: return data


def _call_tmdb_page_function(function, page_no, context_sort=''):
	if context_sort:
		try: return function(page_no, context_sort)
		except TypeError: pass
	return _tmdb_context_filter_page(function(page_no), context_sort)


def _call_tmdb_special_function(function, function_var, page_no, context_sort='', provider_region=None, is_provider=False):
	# Les fonctions de plateformes/diffuseurs qui acceptent une région ont la
	# signature (id, page, region, tri). Même si region est vide, il faut passer
	# le 4e argument, sinon le tri se retrouve accidentellement dans region.
	if context_sort:
		if is_provider:
			try: return function(function_var, page_no, provider_region, context_sort) or {}
			except TypeError: pass
		try: return function(function_var, page_no, context_sort) or {}
		except TypeError: pass
	if is_provider and provider_region not in ('', None):
		try: return _tmdb_context_filter_page(function(function_var, page_no, provider_region) or {}, context_sort)
		except TypeError: pass
	return _tmdb_context_filter_page(function(function_var, page_no) or {}, context_sort)


def _normal_text(value):
	try:
		return str(value or '').strip().lower()
	except:
		return ''


def _normalize_favourites_action(action, params):
	# Filet de sécurité pour les anciennes URL Kodi/cache : si une entrée de
	# favoris séries transporte un contexte spécialisé mais appelle encore
	# l'action globale, on force l'action spécialisée avant le routage.
	# Sans cela, favourites_tvshows/favourites_tvshows_all lit le panier tvshow.
	action = _normal_text(action)
	if action not in ('favourites_tvshows', 'favourites_tvshows_all'):
		return action
	params = params or {}
	fav_type = _normal_text(params.get('fav_type') or params.get('favourite_type') or params.get('favorite_type') or params.get('parent_fav_type') or params.get('series_fav_type') or params.get('tv_fav_type'))
	family_type = _normal_text(params.get('family_type'))
	documentary_type = _normal_text(params.get('documentary_type'))
	native_type = _normal_text(params.get('native_type'))
	fav_group = _normal_text(params.get('fav_group') or params.get('group'))
	if fav_type == 'tv_family' or family_type in ('series_family', 'series_family_kids') or fav_group in ('family', 'series_family'):
		return 'favourites_tv_family'
	if fav_type == 'tv_animation' or family_type == 'series_animation' or fav_group in ('animation', 'series_animation'):
		return 'favourites_tv_animation'
	if fav_type == 'anime_tv' or native_type in ('anime_series', 'anime_tv') or fav_group in ('anime', 'series_anime'):
		return 'favourites_anime_tv'
	if fav_type in ('tv_documentary', 'tv_reality', 'tv_talkshow', 'tv_news') or documentary_type.startswith(('series', 'tv')) or fav_group in ('documentary', 'series_documentary'):
		return 'favourites_tv_documentary'
	return action

class TVShows:
	def __init__(self, params):
		self.params = params
		self.items, self.new_page, self.total_pages = [], {}, None
		self.id_type, self.list, self.action, self.exit_list_params = (
			self.params.get('id_type', 'tmdb_id'),
			self.params.get('list', []),
			self.params.get('action'),
			self.params.get('exit_list_params')
		)
		self.action = _normalize_favourites_action(self.action, self.params)
		self.params['action'] = self.action
		self.append = self.items.append
		self.current_date = get_datetime_function()
		# Paramètres utilisés pour récupérer les métadonnées et les images selon la configuration utilisateur.
		self.meta_user_info = settings.metadata_user_info()
		try: self.watched_indicators = int(self.params.get('watched_indicators', settings.watched_indicators()))
		except: self.watched_indicators = settings.watched_indicators()
		self.watched_info = get_watched_info_function(self.watched_indicators)
		self.all_episodes = settings.default_all_episodes()
		self.include_year_in_title = settings.include_year_in_title('tvshow')
		# Si demandé, le clic sur une pochette de série ouvre la fenêtre d'information.
		self.media_click_opens_info = settings.media_click_opens_info()
		# Info & Extra utilise la fenêtre d'information native du skin.
		self.open_extras = False
		# Menu contextuel natif : ordre fixe, entrées externes selon services autorisés.
		self.cm_sort = settings.context_menu_sort()
		self.cm_services = settings.context_menu_services()
		self.is_folder = True
		self.rpdb_enabled = self.meta_user_info['extra_rpdb_series']
		# Conserve l'identifiant brut du catalogue Stremio pendant la navigation.
		# Sans cela, les épisodes repassent par TMDb/IMDb et certains manifests
		# (French Stream -> Baguettio/AIOStreams) ne retrouvent plus leurs liens.
		self.catalogue_id = self.params.get('catalogue_id') or self.params.get('catalog_id') or ''
		self.fanart_enabled = self.meta_user_info['extra_fanart_enabled']
		self.is_widget = kodi_utils.external_browse()
		self.widget_hide_watched = self.is_widget and self.meta_user_info['widget_hide_watched']
		self.hide_watched_items = self.params.get('hide_watched_items', 'false') == 'true'
		if not self.exit_list_params: self.exit_list_params = get_infolabel('Container.FolderPath')
		self.watched_title = ('alkoFlix', 'Trakt', 'MDBList')[self.watched_indicators]
		self.poster_main, self.poster_backup, self.fanart_main, self.fanart_backup = settings.get_art_provider()
		self.user_ratings = user_ratings.get_active_ratings_index()
		self.parental_blocked = False
		self.exclude_animation_content = _exclude_animation_for_action(self.action, self.params)

	def _carry_context_to_next_page(self, params_get):
		# Les dossiers thématiques (Famille, Docus, Animation, Anime, Sagas)
		# doivent garder leur contexte quand Kodi ajoute « Page suivante ».
		# Sans ces clés, les favoris ajoutés depuis une page suivante peuvent
		# retomber dans les favoris globaux movie/tvshow.
		for key in ('fav_type', 'family_type', 'documentary_type', 'native_type', 'saga_type', 'catalogue_id', 'catalog_id', 'exclude_animation', 'provider_region', 'hide_watched_items', 'watched_indicators', 'genre_sort'):
			value = params_get(key)
			if value not in ('', None) and key not in self.new_page:
				self.new_page[key] = value

	def build_tvshow_content(self, _position, _id):
		try:
			# Récupère les métadonnées de la série avant de construire l'item Kodi.
			meta = tv_meta_function(self.id_type, _id, self.meta_user_info, self.current_date)
			meta_get = meta.get
			if not meta or meta_get('blank_entry', False): return
			if self.exclude_animation_content and _meta_has_animation_genre(meta_get('genre')): return
			if not parental_control.meta_allowed(meta, self.action, 'tvshow'):
				self.parental_blocked = True
				return
			playcount, overlay, total_watched, total_unwatched = get_watched_function(self.watched_info, string(meta['tmdb_id']), meta.get('total_aired_eps'))
			# Dans les widgets, on peut masquer les séries déjà vues selon le réglage utilisateur.
			if self.widget_hide_watched and playcount: return
			meta.update({'playcount': playcount, 'overlay': overlay})
			sort = _id.get('sort', _position) if self.id_type == 'trakt_dict' else _position
			props = {'alkoflix_sort_order': string(sort)}
			cm = []
			cm_append = cm.append
			rootname, title, year = meta_get('rootname'), meta_get('title'), meta_get('year')
			tmdb_id, tvdb_id, imdb_id = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id')
			user_rating = user_ratings.get_user_rating(self.user_ratings, 'tvshow', tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id)
			if user_rating: meta['userrating'] = user_rating
			total_seasons, total_aired_eps = meta_get('total_seasons'), meta_get('total_aired_eps')
			poster = settings.resolve_poster_art(meta, poster_empty)
			media_fanart = meta_get(self.fanart_main) or meta_get(self.fanart_backup)
			fanart = media_fanart or fanart_empty
			clearlogo = meta_get('clearlogo') or meta_get('tmdblogo') or ''
			if self.rpdb_enabled:
				rpdb_data = rpdb_get('series', imdb_id or str(tmdb_id), self.meta_user_info['rpdb_api_key'])
				poster = rpdb_data.get('rpdb') or poster
			# Les images supplémentaires Fanart.tv restent optionnelles, mais l'image
			# landscape doit toujours respecter le choix de langue TMDb quand disponible.
			if self.fanart_enabled:
				banner, clearart = meta_get('banner'), meta_get('clearart')
				landscape = settings.resolve_landscape_art(meta, media_fanart or poster)
			else:
				banner, clearart = '', ''
				landscape = meta_get('landscape_tmdb') or media_fanart or poster
			if self.hide_watched_items:
				url_data = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all', 'hide_watched_items': 'true', 'watched_indicators': string(self.watched_indicators)}
			elif self.all_episodes:
				if self.all_episodes == 1 and total_seasons > 1:
					url_data = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
				else:
					url_data = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all'}
			else:
				url_data = {'mode': 'build_season_list', 'tmdb_id': tmdb_id}
			if self.catalogue_id: url_data['catalogue_id'] = self.catalogue_id
			fav_type = _favourite_type_for_action(self.action, self.params, meta)
			if fav_type: url_data['parent_fav_type'] = fav_type
			url_params = build_url(url_data)
			options_params = build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': self.is_widget})
			recommended_params = build_url({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_recommendations', 'tmdb_id': tmdb_id})
			trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			tmdb_manager_params = build_url({'mode': 'tmdb_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			mdbl_manager_params = build_url({'mode': 'mdbl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow'})
			rating_params = build_url({'mode': 'rating_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title})
			fav_manager_label = favourites_context_label(fav_type, tmdb_id)
			fav_payload = {'mode': 'favourites_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title, 'fav_type': fav_type, 'action': self.action}
			# Conserve le contexte du menu d'origine dans l'action Favoris.
			# C'est indispensable pour les séries Famille : si l'item est ouvert depuis
			# une liste ou un cache sans fav_type fiable, favourites_choice peut alors
			# reconstruire le panier spécialisé (tv_family) au lieu de retomber sur tvshow.
			for ctx_key in ('family_type', 'documentary_type', 'native_type'):
				ctx_value = self.params.get(ctx_key)
				if ctx_value not in ('', None): fav_payload[ctx_key] = ctx_value
			fav_manager_params = build_url(fav_payload)
			trailer_params = build_url({'mode': 'play_trailer_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id})
			info_extra_params = build_url({'mode': 'info_extra_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'is_widget': string(self.is_widget).lower()})
			if self.media_click_opens_info:
				url_params = info_extra_params
				item_is_folder = False
			else:
				item_is_folder = self.is_folder
			# Menu contextuel natif : Info & Extra ouvre la fiche info du skin.
			cm_append((self.cm_sort['options'], options_str, run_plugin % options_params))
			cm_append((self.cm_sort['options'], trailer_str, run_plugin % trailer_params))
			cm_append((self.cm_sort['extras'], extras_str, run_plugin % info_extra_params))
			if self.cm_services['trakt']: cm_append((self.cm_sort['trakt'], traktmanager_str, run_plugin % trakt_manager_params))
			if self.cm_services['mdblist']: cm_append((self.cm_sort['mdblist'], mdblmanager_str, run_plugin % mdbl_manager_params))
			if self.cm_services['tmdblist']: cm_append((self.cm_sort['tmdblist'], tmdbmanager_str, run_plugin % tmdb_manager_params))
			if settings.context_rating_enabled('tvshow'): cm_append((self.cm_sort['rating'], ls(33136), run_plugin % rating_params))
			if settings.context_favourites_enabled(): cm_append((self.cm_sort['favourites'], fav_manager_label, run_plugin % fav_manager_params))
			if not playcount: cm_append((self.cm_sort['mark'], watched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_tvshow', 'action': 'mark_as_watched', 'year': year,
				'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title
			})))
			if total_watched: cm_append((self.cm_sort['mark'], unwatched_str % self.watched_title, run_plugin % build_url({
				'mode': 'mark_as_watched_unwatched_tvshow', 'action': 'mark_as_unwatched', 'year': year,
				'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'title': title
			})))
			# Trie les entrées du menu contextuel selon l'ordre automatique.
			cm.sort(key=lambda k: k[0])
			cm = [v for k, *v in cm if k]
			props['unwatchedepisodes'] = string(total_unwatched)
			props['totalepisodes'] = string(total_aired_eps)
			props['totalseasons'] = string(total_seasons)
			listitem = kodi_utils.make_listitem()
			listitem.addContextMenuItems(cm)
			listitem.setProperties(props)
			listitem.setLabel(rootname if self.include_year_in_title else title)
#			listitem.setContentLookup(False)
			# Les vues horizontales de certains skins utilisent thumb/tvshow.thumb
			# en priorité. On fournit donc un fallback explicite pour éviter les
			# tuiles grises lorsque landscape ou thumb n'est pas encore résolu.
			thumb = landscape or fanart or poster
			listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'thumb': thumb, 'banner': banner, 'clearart': clearart, 'clearlogo': clearlogo, 'landscape': landscape or thumb,
							'tvshow.poster': poster, 'tvshow.thumb': thumb, 'tvshow.clearart': clearart, 'tvshow.clearlogo': clearlogo, 'tvshow.landscape': landscape or thumb, 'tvshow.banner': banner})
			if KODI_VERSION < 20:
				listitem.setCast(meta_get('cast', []))
				listitem.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id), 'tvdb': string(tvdb_id)})
				listitem.setInfo('video', remove_meta_keys(meta, dict_removals))
				listitem.setProperty('watchedepisodes', string(total_watched))
			else:
				if total_watched > 0: listitem.setProperty('watchedepisodes', string(total_watched))
				if total_aired_eps > 0: listitem.setProperty('watchedprogress', string(int(total_watched / total_aired_eps * 100)))
				videoinfo = listitem.getVideoInfoTag(offscreen=True)
				videoinfo.setCast(make_cast_list(meta_get('cast', [])))
				videoinfo.setUniqueIDs({'imdb': imdb_id, 'tmdb': string(tmdb_id), 'tvdb': string(tvdb_id)})
				videoinfo.setCountries(meta_get('country'))
				videoinfo.setDirectors(meta_get('director').split(', '))
				videoinfo.setDuration(meta_get('duration'))
				videoinfo.setGenres(meta_get('genre').split(', '))
				videoinfo.setIMDBNumber(imdb_id)
				videoinfo.setMediaType('tvshow')
				videoinfo.setMpaa(meta_get('mpaa'))
				videoinfo.setPlaycount(playcount)
				videoinfo.setPlot(meta_get('plot'))
				videoinfo.setPremiered(meta_get('premiered'))
				videoinfo.setRating(meta_get('rating'))
				user_ratings.apply_user_rating_to_listitem(listitem, user_rating, videoinfo)
				videoinfo.setStudios((meta_get('studio'),))
				videoinfo.setTagLine(meta_get('tagline'))
				videoinfo.setTitle(rootname if self.include_year_in_title else title)
				videoinfo.setTrailer(meta_get('trailer'))
				videoinfo.setTvShowStatus(meta_get('status'))
				videoinfo.setTvShowTitle(title)
				videoinfo.setVotes(meta_get('votes'))
				videoinfo.setWriters(meta_get('writer').split(', '))
				videoinfo.setYear(int(year))
			self.append((url_params, listitem, item_is_folder))
		except: pass

	def worker(self):
		if not self.list: return []
#		threads = list(make_thread_list_enumerate(self.build_tvshow_content, self.list, Thread))
		# Construction multi-threadée pour accélérer les longues listes de séries.
		for i in TaskPool().tasks_enumerate(self.build_tvshow_content, self.list, Thread): i.join()
		self.items.sort(key=lambda k: int(k[1].getProperty('alkoflix_sort_order')))
		return self.items

class Menu(TVShows):
	tmdb_main, trakt_main, tmdb_special_key_dict = (
		'tmdb_tv_popular', 'tmdb_tv_trending', 'tmdb_tv_random', 'tmdb_tv_top_rated', 'tmdb_tv_airing_today', 'tmdb_tv_airing_this_week', 'tmdb_tv_premieres', 'tmdb_tv_upcoming',
		'tmdb_tvanime_popular', 'tmdb_tvanime_random', 'tmdb_tvanime_premieres',
		'tmdb_tv_family_popular', 'tmdb_tv_family_random', 'tmdb_tv_family_airing_this_week',
		'tmdb_tv_family_animation_popular', 'tmdb_tv_family_animation_random', 'tmdb_tv_family_animation_airing_this_week',
		'tmdb_tv_documentary_popular', 'tmdb_tv_documentary_random', 'tmdb_tv_documentary_trending', 'tmdb_tv_documentary_airing_this_week', 'tmdb_tv_documentary_premieres',
		'tmdb_tv_reality_popular', 'tmdb_tv_reality_random', 'tmdb_tv_reality_trending', 'tmdb_tv_reality_airing_this_week', 'tmdb_tv_reality_premieres',
		'tmdb_tv_talkshow_popular', 'tmdb_tv_talkshow_random', 'tmdb_tv_talkshow_trending', 'tmdb_tv_talkshow_airing_this_week', 'tmdb_tv_talkshow_premieres',
		'tmdb_tv_news_popular', 'tmdb_tv_news_random', 'tmdb_tv_news_trending', 'tmdb_tv_news_airing_this_week', 'tmdb_tv_news_premieres'
	), (
		'trakt_tv_trending', 'trakt_tv_trending_recent', 'trakt_tv_most_watched',
		'trakt_tvanime_trending', 'trakt_tvanime_most_watched'
	), {
		'tmdb_tv_networks': 'network_id', 'tmdb_tv_year': 'year', 'tmdb_tvanime_year': 'year',
		'tmdb_tv_language': 'language_code', 'tmdb_tv_watch_provider': 'provider_id',
		'tmdb_tvanime_language': 'language_code', 'tmdb_tvanime_watch_provider': 'provider_id',
		'tmdb_tv_family_year': 'year', 'tmdb_tv_family_watch_provider': 'provider_id', 'tmdb_tv_family_kids_watch_provider': 'provider_id', 'tmdb_tv_family_genres': 'genre_id',
		'tmdb_tv_family_animation_year': 'year', 'tmdb_tv_family_animation_watch_provider': 'provider_id', 'tmdb_tv_family_animation_genres': 'genre_id',
		'tmdb_tv_documentary_year': 'year', 'tmdb_tv_documentary_language': 'language_code', 'tmdb_tv_documentary_watch_provider': 'provider_id', 'tmdb_tv_documentary_networks': 'network_id', 'tmdb_tv_documentary_genres': 'genre_id',
		'tmdb_tv_reality_year': 'year', 'tmdb_tv_reality_language': 'language_code', 'tmdb_tv_reality_watch_provider': 'provider_id', 'tmdb_tv_reality_networks': 'network_id', 'tmdb_tv_reality_genres': 'genre_id',
		'tmdb_tv_talkshow_year': 'year', 'tmdb_tv_talkshow_language': 'language_code', 'tmdb_tv_talkshow_watch_provider': 'provider_id', 'tmdb_tv_talkshow_networks': 'network_id', 'tmdb_tv_talkshow_genres': 'genre_id',
		'tmdb_tv_news_year': 'year', 'tmdb_tv_news_language': 'language_code', 'tmdb_tv_news_watch_provider': 'provider_id', 'tmdb_tv_news_networks': 'network_id', 'tmdb_tv_news_genres': 'genre_id',
		'tmdb_tv_keyword': 'keyword_id'
	}
	tmdb_personal = ('tmdb_watchlist', 'tmdb_favorite', 'tmdb_recommendations')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_favorites', 'trakt_collection_lists', 'trakt_droplist')
	mdblist_personal = ('mdblist_collection', 'mdblist_watchlist', 'mdblist_favorites')
	imdb_personal = ('imdb_watchlist', 'imdb_user_list_contents')
	similar = ('tmdb_tv_similar', 'tmdb_tv_recommendations')
	personal_dict = {
		'in_progress_tvshows': ('caches.watched_cache', 'get_in_progress_tvshows'),
		'trakt_in_progress_tvshows': ('caches.watched_cache', 'get_in_progress_unwatched_tvshows'),
		'favourites_tvshows': ('caches.favourites_cache', 'get_favourites'),
		'favourites_tvshows_all': ('caches.favourites_cache', 'get_favourites_tvshows_all'),
		'favourites_tv_family': ('caches.favourites_cache', 'get_favourites_tv_family'),
		'favourites_tv_animation': ('caches.favourites_cache', 'get_favourites_tv_animation'),
		'favourites_anime_tv': ('caches.favourites_cache', 'get_favourites_anime_tv'),
		'favourites_tv_documentary': ('caches.favourites_cache', 'get_favourites_tv_documentary'),
		'favourites_tv_reality': ('caches.favourites_cache', 'get_favourites_tv_reality'),
		'favourites_tv_talkshow': ('caches.favourites_cache', 'get_favourites_tv_talkshow'),
		'favourites_tv_news': ('caches.favourites_cache', 'get_favourites_tv_news'),
		'favourites_custom_tvshows': ('caches.favourites_cache', 'get_favourites_custom'),
		'watched_tvshows': ('caches.watched_cache', 'get_watched_items')
	}

	def run(self):
		try:
			params_get = self.params.get
			self.handle = int(sys.argv[1])
			view_type, content_type = 'view.tvshows', 'tvshows'
			mode = params_get('mode')
			try: page_no = int(params_get('new_page', '1'))
			except ValueError: page_no = params_get('new_page')
			letter = params_get('new_letter', 'None')
			if self.action in Menu.personal_dict: var_module, import_function = Menu.personal_dict[self.action]
			else: var_module, import_function = 'indexers.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			if self.action in Menu.tmdb_main:
				context_sort = params_get('genre_sort', '')
				data = _call_tmdb_page_function(function, page_no, context_sort) or {}
				self.list = [i.get('id') for i in data.get('results', []) if isinstance(i, dict) and i.get('id')]
				total_pages = data.get('total_pages', page_no)
				if context_sort:
					try: total_pages = min(int(total_pages), 4)
					except: total_pages = 4
				if total_pages > page_no:
					self.new_page = {'new_page': string(data.get('page', page_no) + 1)}
					if context_sort: self.new_page['genre_sort'] = context_sort
			elif self.action in Menu.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				self.list = [i['show']['ids'] for i in data]
				self.new_page = {'new_page': string(page_no + 1)}
			elif self.action in Menu.tmdb_personal:
				data, total_pages = function('tv', page_no, letter)
				self.list = [i['id'] for i in data]
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.trakt_personal:
				self.id_type = 'trakt_dict'
				data, total_pages = function('shows', page_no, letter)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
				except: pass
			elif self.action in Menu.mdblist_personal:
				self.id_type = 'trakt_dict'
				data, total_pages = function('shows', page_no, letter)
				self.list = [{'imdb': i['imdb_id'], 'tmdb': i['id']} for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
				except: pass
			elif self.action in Menu.imdb_personal:
				self.id_type = 'imdb_id'
				list_id = params_get('list_id')
				data, next_page = function('tvshow', list_id, page_no)
				self.list = [i['imdb_id'] for i in data]
				if next_page: self.new_page = {'list_id': list_id, 'new_page': string(page_no + 1), 'new_letter': letter}
			elif self.action in Menu.personal_dict:
				forced_watched_indicators = params_get('watched_indicators')
				# Sans indicateur forcé, les dossiers de suivi utilisent le choix actif de l'utilisateur :
				# alkoFlix local, Trakt ou MDBList. Dans les sous-dossiers Trakt/MDBList,
				# l'indicateur est forcé par le navigateur du service concerné.
				if self.action in ('in_progress_tvshows', 'trakt_in_progress_tvshows') and forced_watched_indicators not in (None, ''):
					data, total_pages = function('tvshow', page_no, letter, watched_indicators=int(forced_watched_indicators))
				else:
					favourite_query_type = params_get('fav_type') if self.action == 'favourites_custom_tvshows' else 'tvshow'
					data, total_pages = function(favourite_query_type, page_no, letter)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'new_letter': letter}
				if self.watched_indicators == 1:
					try:
						hidden_data = trakt_get_hidden_items('dropped')
						self.list = [i for i in self.list if not int(i) in hidden_data]
					except: pass
			elif self.action in Menu.similar:
				tmdb_id = self.params['tmdb_id']
				data = function(tmdb_id, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['page'] < data['total_pages']: self.new_page = {'new_page': string(data['page'] + 1), 'tmdb_id': tmdb_id}
			elif self.action in Menu.tmdb_special_key_dict:
				key = Menu.tmdb_special_key_dict[self.action]
				function_var = params_get(key)
				if not function_var: return
				provider_region = params_get('provider_region')
				context_sort = params_get('genre_sort', '')
				if key == 'language_code' and str(function_var).lower() not in ('fr', 'en'):
					context_sort = ''
				data = _call_tmdb_special_function(function, function_var, page_no, context_sort, provider_region if self.action.endswith('_watch_provider') else None, self.action.endswith('_watch_provider'))
				results = data.get('results', []) if isinstance(data, dict) else []
				self.list = [i.get('id') for i in results if isinstance(i, dict) and i.get('id')]
				if self.action.endswith('_watch_provider') and not self.list:
					kodi_utils.logger('catalogue provider empty', '%s | provider_id=%s | region=%s | page=%s' % (self.action, function_var, provider_region or 'settings', page_no))
				if isinstance(data, dict):
					current_page = data.get('page', page_no)
					total_pages = data.get('total_pages', page_no)
					if context_sort:
						try: total_pages = min(int(total_pages), 4)
						except: total_pages = 4
					if current_page < total_pages:
						self.new_page = {'new_page': string(current_page + 1), key: function_var}
						if provider_region: self.new_page['provider_region'] = provider_region
						if context_sort: self.new_page['genre_sort'] = context_sort
			elif self.action == 'tmdb_person_tvshows':
				from menus.people import person_credit_ids, _person_credits_debug
				actor_id = params_get('actor_id')
				credit_ids = person_credit_ids(actor_id, 'tvshow')
				credit_pages = list(chunks(credit_ids, 40))
				try: self.list = credit_pages[page_no - 1]
				except: self.list = []
				_person_credits_debug('menu page build', actor_id, 'tvshow', len(self.list), 'page=%s/%s | prepared=%s | prepared_count=%s' % (page_no, len(credit_pages), params_get('person_credit_prepared', 'false'), params_get('person_credit_count', 'N/A')))
				if len(credit_pages) > page_no:
					self.new_page = {'actor_id': actor_id, 'new_page': string(page_no + 1), 'person_credit_prepared': params_get('person_credit_prepared', 'false'), 'person_credit_type': 'tvshow'}
			elif self.action == 'tmdb_tv_discover':
				from menus.discover import set_history
				name = self.params['name']
				query = self.params['query']
				if page_no == 1: set_history('tvshow', name, query)
				data = function(query, page_no)
				self.list = [i['id'] for i in data['results']]
				if data['page'] < data['total_pages']: self.new_page = {'query': query, 'name': name, 'new_page': string(data['page'] + 1)}
			elif self.action in ('tmdb_tv_genres', 'tmdb_tvanime_genres'):
				genre_id = self.params['genre_id']
				genre_sort = params_get('genre_sort', '')
				if not genre_id: return
				data = function(genre_id, page_no, genre_sort) if genre_sort else function(genre_id, page_no)
				data = data or {}
				results = data.get('results', []) if isinstance(data, dict) else []
				self.list = [i.get('id') for i in results if isinstance(i, dict) and i.get('id')]
				if isinstance(data, dict):
					current_page = data.get('page', page_no)
					total_pages = data.get('total_pages', page_no)
					if genre_sort:
						try: total_pages = min(int(total_pages), 4)
						except: total_pages = 4
					if current_page < total_pages:
						self.new_page = {'new_page': string(current_page + 1), 'genre_id': genre_id}
						if genre_sort: self.new_page['genre_sort'] = genre_sort
			elif self.action == 'tmdb_tv_search':
				query = self.params['query']
				data = function(query, page_no)
				self.list = [i['id'] for i in data['results']]
				total_pages = data['total_pages']
				if total_pages > page_no: self.new_page = {'new_page': string(page_no + 1), 'query': query}
			elif self.action == 'trakt_tv_certifications':
				self.id_type = 'trakt_dict'
				data = function(self.params['certification'], page_no)
				self.list = [i['show']['ids'] for i in data]
				self.new_page = {'new_page': string(page_no + 1), 'certification': self.params['certification']}
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('shows')
				self.list = [i['ids'] for i in data]
			# Ajoute l'entrée de navigation rapide seulement dans les listes complètes, pas dans les widgets.
			if self.total_pages and not self.is_widget and settings.nav_jump_use_alphabet():
				url_params = {
					'mode': 'build_navigate_to_page', 'current_page': page_no, 'total_pages': self.total_pages,
					'query': params_get('search_name', ''), 'actor_id': params_get('actor_id', ''),
					'transfer_mode': mode, 'transfer_action': self.action, 'media_type': 'Séries'
				}
				kodi_utils.add_dir(self.handle, url_params, jumpto_str, item_jump, isFolder=False)
			kodi_utils.add_items(self.handle, self.worker())
			if self.new_page:
				self._carry_context_to_next_page(params_get)
				self.new_page.update({'mode': mode, 'action': self.action, 'exit_list_params': self.exit_list_params, 'name': ls(params_get('name'))})
				kodi_utils.add_dir(self.handle, self.new_page, nextpage_str, item_next)
		except: pass
		kodi_utils.set_category(self.handle, ls(params_get('name')))
		kodi_utils.set_sort_method(self.handle, content_type)
		kodi_utils.set_content(self.handle, content_type)
		kodi_utils.end_directory(self.handle, False if self.is_widget else None)
		kodi_utils.set_view_mode(view_type, content_type)

